<html>
<?php

error_reporting(0);
set_time_limit(0);
session_start();

if(!file_exists("usuarios.txt")){
  $fopen = fopen("usuarios.txt" , "a+");
  fclose($fopen);
}
if(isset($_SESSION['usuario']) and isset($_SESSION['senha'])){
  session_destroy();
  session_start();
}

?>



<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from colorlib.com/polygon/srtdash/login.html by HTTrack Website Copier/3.x [XR&CO'2017], Sun, 04 Nov 2018 17:03:28 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Login - FLASH</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <!--nao te interessa otario-->
    <link rel="stylesheet" href="../../../www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <!-- others css -->
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!--belaza do site-->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
    <!--[AKI É FLASH PORRA>
            <p class="KIBA MEU PAU NO SEU CU">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![porra de end If caralho se fode porra]-->
    <!--desliga o httracker caralho -->
    <div id="preloader">
        <div class="loader"></div>
        
    </div>
    <!-- preloader area end -->
    <!-- login area start -->
    
    <?php
    if(isset($_POST['usuario']) and isset($_POST['senha'])){
    $usuario = $_POST['usuario'];
    $senha = $_POST['senha'];
    $get = file_get_contents("usuarios.txt");
    $array = file("usuarios.txt");
    
    
    
    if($usuario == "" or $senha == "" ){
    echo "<script>swal('erro' , 'Usuario ou senha Invalidos' , 'error');</script>";
    
    }else{
    
    $logado = false;
    for($i=0;$i<count($array); $i++)
    {
    
    
    
    
    
    
    
    $explode = explode("|" , $array[$i]);
    
    if($explode[0] == $usuario and $explode[1] == $senha){
    $_SESSION['usuario'] = $usuario;
    $_SESSION['senha'] = $senha;
    $_SESSION['rank'] = $explode[2];
    $_SESSION['nome'] = $explode[3];
    $_SESSION['saldo'] = $explode[5];
    $_SESSION['expira'] = $explode[6];
    $logado = true;
    }
    
    }
    if($logado){
    echo "<script>alert alert-success alert-dismissable('Sucesso!' , 'Logado Com Sucesso' , 'success');</script>";
    echo '<meta http-equiv="refresh" content="0;url=painel/verificatabela.php">';
    }else{
    echo '<div class="alert alert-danger" role="alert"><strong>Atenção:</strong> O login ou senha inseridos são inválidos!</div>';
    }
    
    
    }
    
    }
    ?>
    
    
    
  
    
    <div class="login-area">
    
        <div class="container">
        
            <div class="login-box ptb--100">
               
               
               
               
               
               
                <form name="form" method="POST" autocomplete="off" class="form-horizontal">
                
                    <div class="login-form-head">
                        <h4>CENTRAL FLASH</h4>
                        <p></p>
                    </div>
                    <div class="login-form-body">
                        <div class="form-gp">
                            <label for="exampleInputEmail1">Usuário</label>
                            <input name="usuario" type="text" id="exampleInputEmail1">
                            <i class="ti-email"></i>
                        </div>
                        <div class="form-gp">
                            <label name="senha" for="exampleInputPassword1">Senha</label>
                            <input name="senha" type="password" id="exampleInputPassword1">
                            <i class="ti-lock"></i>
                        </div>
                        <div class="row mb-4 rmber-area">
                            <div class="col-6">
                                <div class="custom-control custom-checkbox mr-sm-2">
                                    <input type="checkbox" class="custom-control-input" id="customControlAutosizing">
                                    <label class="custom-control-label" for="customControlAutosizing">Lembrar-me</label>
                                </div>
                            </div>
                            <div class="col-6 text-right">
                                <a href="">Esqueceu a senha?</a>
                                <a href="#"></a>
                            </div>
                        </div>
                        <div class="submit-btn-area">
                            <button id="form_submit" type="submit">Entrar<i class="ti-arrow-right"></i></button>
                            <div class="login-other row mt-4">
                                <div class="col-6">
                                    <a class="fb-login" href="#">Login Com<i class="fa fa-facebook"></i></a>
                                </div>
                                <div class="col-6">
                                    <a class="google-login" href="#">Login Com<i class="fa fa-google"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="form-footer text-center mt-5">
                            <p class="text-muted">Conhece os valores aqui<a href="prices.html">Planos</a></p>
                        <p class="text-muted">Cadastre com key<a href="register4.php"> Registre-se</a></p>
                        
                        
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    
    
    
    
  
    
    
    
    
    
    <!-- login area end -->

    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>

    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="../../../external.html?link=https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
</body>


<!-- Mirrored from colorlib.com/polygon/srtdash/login.html by HTTrack Website Copier/3.x [XR&CO'2017], Sun, 04 Nov 2018 17:03:28 GMT -->
</html>