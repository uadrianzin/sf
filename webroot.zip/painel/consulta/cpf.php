<?php 
error_reporting(0);
set_time_limit(0);
session_start();



extract($_POST);

if($_SESSION['rank'] !== "Revendedor"){
    die("PAGINA INEXISTENTE");
}





if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){
echo '<script language= "JavaScript">location.href="/"</script><br>';
  die();
}

$array_usuarios = file("../usuarios.txt");
$total_usuarios_registrados = count($array_usuarios);

$continuar = false;
for($i=0;$i<count($array_usuarios);$i++){
  $explode = explode("|" , $array_usuarios[$i]);
  if($_SESSION['usuario'] == $explode[0]){

date_default_timezone_set('America/Sao_Paulo');
$datinha = date('H:i');
$data_dia = date ("Y-m-d");
$ramdom_key = substr(str_shuffle(str_repeat("0123456789", 16)), 0, 16);
$data_auxilio_form = date ('d/m/Y');
$usuario = $_SESSION['usuario'];
$senha = $_SESSION['senha'];
$rank = $_SESSION['rank'];
$nome = $_SESSION['nome'];
$ip = $_SERVER['REMOTE_ADDR'];

    $_SESSION['senha'] = $explode[1];
    $_SESSION['rank'] = $explode[2];
    $_SESSION['nome'] = $explode[3];
    $_SESSION['foto'] = $explode[4];
    $continuar = true;
  }
}

if(!$continuar){
echo '<script language= "JavaScript">location.href="/"</script><br>';
die();
}





?>

<!DOCTYPE html>
<html>

<head>
  <title> - Consultor de CPF [CADSUS] - </title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="https://bootswatch.com/4/cosmo/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://bootswatch.com/4/cosmo/bootstrap.css">

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<body>
  <div align="center">
<h1>Consultor de CPF [CADSUS]</h1>

  <form method="post" action="">
    <div align="center"><input name="cpf" rows="1" class="form-control" placeholder="000.000.000-00" autocomplete="off" style="width:20%" value=""/><p><p>
    <input type="submit" id="enviar" name="enviar" class="btn btn-primary" value="Consultar"/><br><br>
  </div>
  </form>

  <table class="table table-striped" id="tabAprovadas" name="tabAprovadas">
    <thead>
      <tr>
        <th><center>Nome</center></th>
        <th><center>CPF</center></th>
        <th><center>CNS</center></th>
        <th><center>Data de Nascimento</center></th>
        <th><center>Raça</center></th>
        <th><center>Mãe</center></th>
        <th><center>Pai</center></th>
        <th><center>Cidade</center></th>
        <th><center>Bairro</center></th>
        <th><center>Rua</center></th>
        <th><center>Complemento</center></th>
        <th><center>N° da casa</center></th>
        <th><center>CEP</center></th>
      </tr>
    </thead>
    <tbody>

      <tr>
        <th><center><?php echo $nome; ?></center></th>
        <th><center><?php echo $cpf; ?></center></th>
        <th><center><?php echo $cns; ?></center></th>
        <th><center><?php echo $nasc; ?></center></th>
        <th><center><?php echo $raca; ?></center></th>
        <th><center><?php echo $nomeMae; ?></center></th>
        <th><center><?php echo $nomePai; ?></center></th>
        <th><center><?php echo $municipioNascimento; ?></center></th>
        <th><center><?php echo $bairro; ?></center></th>
        <th><center><?php echo $endereco; ?></center></th>
        <th><center><?php echo $complemento; ?></center></th>
        <th><center><?php echo $numerocasa; ?></center></th>
        <th><center><?php echo $cep; ?></center></th>
      </tr>
    </tbody>
  </table>


  <h2>Resultados para Documentos</h2>


  <table class="table table-striped" id="tabAprovadas" name="tabAprovadas">
    <thead>
      <tr>
        <th><center>RG</center></th>
        <th><center>Orgão Emissor</center></th>
        <th><center>Data Emissão</center></th>
        <th><center>UF</center></th>
      </tr>
    </thead>
    <tbody>

      <tr>
        <th><center><?php echo $rg; ?></center></th>
        <th><center><?php echo $org; ?></center></th>
        <th><center><?php echo $rgdata; ?></center></th>
        <th><center><?php echo $rguf; ?></center></th>
      </tr>
    </tbody>
  </table>


    <h2>Resultados para Telefones</h2>


  <table class="table table-striped" id="tabAprovadas" name="tabAprovadas">
    <thead>
      <tr>
        <th><center>Telefone</center></th>
      </tr>
    </thead>
    <tbody>

      <tr>
        <th><center><?php echo $ddd; ?> <?php echo $telefone; ?></center></th>
      </tr>
    </tbody>
  </table>
</form>
</div>
</body>
</html>