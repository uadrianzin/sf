<?php


session_start();
error_reporting(0);
if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){
	echo "<script>location.href='/'</script>";
  die();
}


?>
<!DOCTYPE html>
<html>     
    <head>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
        <meta charset="utf-8">
        <title>Spotify Checker</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Kartage">
        <meta name="author" content="Kartage">
        <link rel="stylesheet" href="https://bootswatch.com/flatly/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Quicksand">
        <link rel="stylesheet" href="../files/estilo.css">
        <link rel="shortcut icon" href="https://lh3.googleusercontent.com/UrY7BAZ-XfXGpfkeWg0zCCeo-7ras4DCoRalC_WXXWTK9q5b0Iw7B0YQMsVxZaNB7DM=w300" type="image/png">
        <style>
            h1  {
                font-family: 'Quicksand', sans-serif;
            }
            body  {
                font-family: 'Quicksand', sans-serif;
            }
        </style>
    </head>
    <body style="background-color:#2c3338;">
    <center>
        <br>
        <font color="white"><h2>Checker Spotify</h2></font>
        <br>
        <br>
        <textarea class="form-control" name="text" id="text" rows="8" placeholder="Lista de email e senha" style="resize: none; width:800px;height:200px;"></textarea>
        <br>
        <div>
            <font color="white">Status: <span id="demo" style="color:blue;">Aguardando Início</span> - Aprovadas : <span id="CLIVE"style="color:green;">0</span> - Reprovadas : <span id="CDIE"style="color:red;">0</span> - Testadas: <span id="testado"style="color:blue;">0</span> - Total : <span id="carregada"style="color:purple;">0</span></font></div>
        <br>
        <div class="form-inline animated bounceInUp">
            <font color="white">Separador:</font> <input value="|" maxlength="1" class="form-control" style="height: 35px; width: 60px; text-align: center;" name="separador" id="separador" placeholder="|">
        </div>
        <br>
        <br>
        <button class="btn btn-success" id="testar" style="width:200px;">Iniciar</button><br><br>
    </center>

    <center>
        <div id="aprovadasdiv" class="panel panel-success">
            <div class="panel-heading">
                <h3 class="panel-title"><b style="text-shadow: 0 0 3px black;color:black">Aprovadas <i class="fa fa-check"></i></b></h3>
            </div>
            <div style="width: 100%;" class="panel-body">
                <textarea style="resize: none; width: 100%;" rows="6" id="aprovadas"></textarea>
            </div>
        </div>
        <div style="width: 100%;" id="reprovadasdiv"  class="panel panel-danger">
            <div class="panel-heading">
                <h3 class="panel-title">
                    <b style="text-shadow: 0 0 3px black;color:black;">Reprovadas <i class="fa fa-times"></i></b></h3> 
            </div>
            <div contenteditable class="panel-body">
                <textarea  style="resize: none; width: 100%;" rows="6" id="reprovadas"></textarea>
            </div>

        </div>
    </center>
	
    <script>
        var atual_1 = 0;
        var lives = 0;
        var totals = 0;
        var dies = 0;
        var t = 0;
        var looper;
        function q(data) {
            var old = document.getElementById("aprovadas").value;
            var q = data;
            totals++;
            $("#testado").html("" + totals);
            if (q == "FALIDO") {
                document.getElementById("demo").style = "color: purple;";
                $("#demo").html("Sem Moedas");
                clearInterval(looper);
                return;
            }
            if (q.includes("1LOGADO")) {
                lives++;
                $("#CLIVE").html("" + lives);
                var user = q.split("|")[1];
                var senha = q.split("|")[2];
                var status = q.split("|")[3];
                document.getElementById("aprovadas").value = user + " | " + senha + " | " + status + "\n" + old;
            } else {
                dies++;
                $("#CDIE").html("" + dies);
                var user = q.split("|")[1];
                var senha = q.split("|")[2];
                var t_old = document.getElementById("reprovadas").value;
                document.getElementById("reprovadas").value = user + " | " + senha + "\n" + t_old;
            }

            atual_1++;
            if (atual_1 >= t) {
                document.getElementById("testar").disabled = false;
                document.getElementById("text").disabled = false;
                document.getElementById("separador").disabled = false;
            }

        }

        $(document).ready(function ()
        {
            $("#testar").click(function (e) {
                document.getElementById("testar").disabled = true;
                document.getElementById("text").disabled = true;
                document.getElementById("separador").disabled = true;
                lives = 0;
                totals = 0;
                dies = 0;
                atual_1 = 0;
                var lista = $("#text").val();
                var split = lista.split("\n");
                var total = split.length;
                $("#carregada").html("" + total);
                var atual = 0;
                t = total;


                looper = setInterval(function () {

                    document.getElementById("demo").style = "color: lime;";
                    $("#demo").html("Testando");
                    if (atual >= total)
                    {
                        clearInterval(looper);
                        document.getElementById("demo").style = "color: red;";
                        $("#demo").html("Parado");
                        return;
                    }
                    var login = split[atual];
                    var user = login.split("|")[0];
                    var senha = login.split("|")[1];
                    $("#por").serialize();
                    $("#f").serialize();
                    jQuery.ajax({
                        type: "GET",
                        url: "apinaotoloko.php?email=" + user + "&senha=" + senha,
                        success: function (data)
                        {
                            q(data);
                        }
                    });

                    ++atual;
                }, 100);






            });


        });
    </script>				
</body>
</html>
