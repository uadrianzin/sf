<?php 
error_reporting(0);
set_time_limit(0);
session_start();


if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){
echo '<script language= "JavaScript">location.href="/"</script><br>';
  die();
}

$array_usuarios = file("../usuarios.txt");
$total_usuarios_registrados = count($array_usuarios);

$continuar = false;
for($i=0;$i<count($array_usuarios);$i++){
  $explode = explode("|" , $array_usuarios[$i]);
  if($_SESSION['usuario'] == $explode[0]){







date_default_timezone_set('America/Sao_Paulo');
$data_atual = date('Y-m-d H:i');
$usuario = $_SESSION['usuario'];
$senha = $_SESSION['senha'];
$rank = $_SESSION['rank'];
$nome = $_SESSION['nome'];
$key = $_SESSION['key'];
$saldo = $_SESSION['saldo'];
$expira = $_SESSION['expira'];
$ip = $_SERVER['REMOTE_ADDR'];


    $_SESSION['rank'] = $explode[2];
    $_SESSION['nome'] = $explode[3];
    $_SESSION['key'] = $explode[4];
    $_SESSION['saldo'] = $explode[5];
    $_SESSION['expira'] = $explode[6];
    $continuar = true;
  }
}

if(!$continuar){
echo '<script language= "JavaScript">location.href="/"</script><br>';
die();
}

        



$totalconsultaveis = count( file( '../../total_ccs.txt' ) );



$linhas = count(file("../../total_ccs.txt"));
 

if($data_atual >= $expira){
$filename = '../usuarios.txt';
$lines = file($filename); 
$output = '';
foreach ($lines as $line) {
if (!strstr($line, $key)) {
$output .= $line;
} 
}
file_put_contents($filename, $output);
echo '<meta http-equiv="refresh" content="0;url=401.html">';
exit;

}

?>




<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from colorlib.com/polygon/srtdash/index.html by HTTrack Website Copier/3.x [XR&CO'2017], Sun, 04 Nov 2018 17:00:47 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo $data_atual ?> - FlashReverso</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/fav.icon">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <!-- amchart css -->
    <link rel="stylesheet" href="../../../www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <!-- others css -->
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- modernizr css -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- page container area start -->
    <div class="page-container">
        <!-- sidebar menu area start -->
        <div class="sidebar-menu">
            <div class="sidebar-header">
                <div class="logo">
                    <p>FLASHREVERSO<p>
                </div>
            </div>
            <div class="main-menu">
                <div class="menu-inner">
                    <nav>
                        <ul class="metismenu" id="menu">
                            <li class="active">
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-dashboard"></i><span>Cartoes</span></a>
                                <ul class="collapse">
                                    <li><a class="fa fa-address-card" href="checkers/bb">BB</a></li>
                                    <li><a href="checkers/hipercard">HiperCard</a></li>
                                    <li><a href="checkers/Full">FULL</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>LOJAS
                                        
                                    </span></a>
                                <ul class="collapse">
                                    <li><a href="loja/skyonline">
                                    Sky</a></li>
                                    <li>
                                    <a href="loja/carrefour">carrefour</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-pie-chart"></i><span>SALDOS</span></a>
                                <ul class="collapse">
                                    <li><a href="saldo/bitcoin">BitCoin</a></li>
                                    <li><a href="saldo/cielo">Cielo</a></li>

                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-palette"></i><span>MUSICAS</span></a>
                                <ul class="collapse">
                                    <li><a href="musicas/spotify">SPOTIFY</a></li>
                                    
                                    <li><a href="musicas/deezer">Dezzer</a></li>
                                    
                                   
                                    
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-slice"></i><span>LOGINS</span></a>
                                <ul class="collapse">
                                    <li><a href="logins/netflix">NETFLIX OFF</a></li>
                                    <li><a href="logins/Eiplus">Eiplus</a></li>
                                    
                                    <li><a href="logins/sendspace">sendspace</a></li>
                                    
                                    <li><a href="logins/4shared">4shared</a></li>
                                    
                                    <li><a href="logins/Sky">Sky</a></li>
                                    
                                    <li><a href="logins/uolhost">UolHost</a></li>
                                    
                                    <li><a href="logins/centauro">Centauro</a></li>
                                    
                                    <li><a href="logins/hostgator">HostGator</a></li>
                                    
                                    <li><a href="logins/facebook">Facebook</a></li>
   </ul>
                            </li>
                            <li>
                                <a                                 href="javascript:void(0)" aria-expanded="true"><i class="ti-slice"></i><span>FERRAMENTAS</span></a>
                                <ul class="collapse">
                                    <li><a href="ferramentas/Capturador-WorldPay">capturador WordPlay</a></li>
                                    
                                    <li><a href="ferramentas/Capturador-Dorks">Capturar dorks</a></li>
                                    
                                    <li><a href="ferramentas/Capturador-Classy">Capturador-Classy</a></li>
                                    
                                    <li><a href="ferramentas/GeradorUS">GeradorUS</a></li>
                                    
                                    <li><a href="ferramentas/Spammer">Spammer</a></li>
                                    
                                                                    </ul>
                            </li>
                            <li>
                                <a                                 href="javascript:void(0)" aria-expanded="true"><i class="ti-slice"></i><span>HOSPEDAGEM</span></a>
                                <ul class="collapse">
                                    <li><a href="web/0">000 WEBHOST</a></li>
                                    
                                    <li><a href="web/bhost">B Host</a></li>
                                                      
<li><a href="web/bluehost">BlueHost</a></li>                            
                                </ul>
                            </li>
                            <li><a>
                                </ul>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <!-- sidebar menu area end -->
        <!-- main content area start -->
        <div class="main-content">
            <!-- header area start -->
            <div class="header-area">
                <div class="row align-items-center">
                    <!-- nav and search button -->
                    <div class="col-md-6 col-sm-8 clearfix">
                        <div class="nav-btn pull-left">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div class="search-box pull-left">
                            <form action="#">
                                <input type="text" name="search" placeholder="Search..." required>
                                <i class="ti-search"></i>
                                
                          
                                
                            </form>
                        </div>
                    </div>
                    <!-- profile info & task notification -->
                    
                  
                    
                   
                    
                    
                </div>
            </div>
            <!-- header area end -->
            <!-- page title area start -->
            
            
            
            <div class="page-title-area">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="breadcrumbs-area clearfix">
                            <h4 class="page-title pull-left">Controle</h4>
                            <ul class="breadcrumbs pull-left">
                                <li><a href="index.php">Início</a></li>
                                <li><span>Painel</span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 clearfix">
                        <div class="user-profile pull-right">
                            <img class="avatar user-thumb" src="assets/images/author/avatar.png" alt="avatar">
                            <h4 class="user-name dropdown-toggle" data-toggle="dropdown">ola, <?php echo $usuario ?> <i class="fa fa-angle-down"></i></h4>
                            <div class="dropdown-menu">
                                <a class="dropdown-item" href="tabela.php">Admin</a>
                               <a class="dropdown-item" href="revendedor.php">Revendedor</a>
                                <a
                 
                                                
                       class="dropdown-item" href="invoice.php">dados</a>
                                <a
                          
                          class="dropdown-item" href="renovar.php">RENOVAR LOGN</a>
                                <a class="dropdown-item" href="../">Deslogar</a>
                        
                        <a class="dropdown-item" href="chat">Chat</a>
                                
                        
                        
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- page title area end -->
            
            
         
         
         <div class="main-content-inner">
         <div class="row">
         <!-- seo fact area start -->
         <div class="col-lg-8">
         <div class="row">
         <div class="col-md-6 mt-5 mb-3">
         <div class="card">
         <div class="seo-fact sbg1">
         <div class="p-4 d-flex justify-content-between align-items-center">
         <div class="seofct-icon"><i class="fa fa-cart-plus"></i>Logins lives</div>
         <h2>0</h2>
         </div>
         <canvas id="seolinechart1" height="50"></canvas>
         </div>
         </div>
         </div>
         <div class="col-md-6 mt-md-5 mb-3">
         <div class="card">
         <div class="seo-fact sbg2">
         <div class="p-4 d-flex justify-content-between align-items-center">
         <div class="seofct-icon"><i class="fa fa-credit-card"></i>Cartões aprovados</div>
         <h2><?php echo $linhas;    ?></h2>
         </div>
         <canvas id="seolinechart2" height="50"></canvas>
         </div>
         </div>
         </div>
         <div class="col-md-6 mt-md-5 mb-3">
         <div class="card">
         <div class="seo-fact sbg3">
         <div class="p-4 d-flex justify-content-between align-items-center">
         <div class="seofct-icon"><i class="fa fa-wrench"></i>Total de checkers</div>
         <h2>5</h2>
         </div>
         <canvas id="seolinechart2" height="50"></canvas>
         </div>
         </div>
         </div>
         <div class="col-md-6 mt-md-5 mb-3">
         <div class="card">
         <div class="seo-fact sbg4">
         <div class="p-4 d-flex justify-content-between align-items-center">
         <div class="seofct-icon"><i class="fa fa-users"></i>Total de usuários</div>
         <h2><?php echo $total_usuarios_registrados;    ?></h2>
         </div>
         <canvas id="seolinechart2" height="50"></canvas>
         </div>
         </div>
         </div>
         
         
         
         
         
         
         
         
         <div class="col-lg-6 mt-5">
         <div class="card">
         <div class="card-body">
         <h4 class="header-title">Informações</h4>
         <div class="single-table">
         <div class="table-responsive">
         <table class="table text-center">
         <thead class="text-uppercase bg-primary">
         <tr class="text-white">
         <th scope="col">IP</th>
         <th scope="col">Usuário</th>
         <th scope="col">Senha</th>
         <th scope="col">Nome</th>
         <th scope="col">Rank</th>
         <th scope="col">Saldo</th>
         <th scope="col">expira:</th>
         </tr>
         </thead>
         <tbody>
         <tr>
         <th scope="row"><?php echo $ip; ?></th>
         <th scope="row"><?php echo $usuario; ?></th>
        <th scope="row"><?php echo $senha; ?></th>
         <th scope="row"><?php echo $nome; ?></th>
         <th scope="row"><?php echo $rank; ?></th>
         <th scope="row"><?php echo $key; ?></th>
         <th scope="row"><?php echo $saldo; ?></th>
         <th scope="row"><?php echo $expira; ?></th>
         </tr>
         
         
         
         
         
         </tbody>
         </table>
         </div>
         </div>
         </div>
         </div>
         </div>
         
         
         
         
         
         
         <!-- seo fact area end -->
         <!-- Social Campain area start -->
   
         <!-- sales area end -->
         <!-- timeline area start -->
         
         <!-- timeline area end -->
         <!-- map area start -->
         
         <!-- map area end -->
         <!-- testimonial area start -->
         <div class="col-xl-7 col-lg-12 mt-5">
         <div class="card">
         <div class="card-body bg1">
         <h4 class="header-title text-white">NOTIFICACOES </h4>
         <div class="testimonial-carousel owl-carousel">
         <div class="tst-item">
         <div class="tstu-img">
         <a href="#"><img src="assets/images/icon/logo.png" alt="logo"></a>
         </div>
         <div class="tstu-content">
         <h4 class="tstu-name">FlashReverso</h4>
         <span class="profsn">Bem Vindos</span>
         <p>Seja todos Bem. Vindos  a CENTRAL FLASH moderna e simplesmente segura voce tera acesso total a sua area !</p>
         </div>
         </div>
         <div class="tst-item">
         <div class="tstu-img">
         <a href="#"><img src="assets/images/icon/logo.png" alt="logo"></a>
         </div>
         <div class="tstu-content">
         <h4 class="tstu-name">Programadores</h4>
         <span class="profsn">Donos e ajudantes</span>
         <p>Dono:FLASH</p>
         </div>
         </div>
         </div>
         </div>
         </div>
         </div>
         <!-- testimonial area end -->
         </div>
         </div>
         
         
         
         
      
            
            
            
            
            
            
            
        </div>
        <!-- main content area end -->
        <!-- footer area start-->
        <footer>
            <div class="footer-area">
                <p>© Copyright 2020. Todos os direitos reservados. By <a href="../.">FLASH</a>.</p>
            </div>
        </footer>
        <!-- footer area end-->
    </div>
    <!-- page container area end -->
    <!-- offset area start -->
    <div class="offset-area">
        <div class="offset-close"><i class="ti-close"></i></div>
        <ul class="nav offset-menu-tab">
            <li><a class="active" data-toggle="tab" href="#activity">Activity</a></li>
            <li><a data-toggle="tab" href="#settings">Settings</a></li>
        </ul>
        <div class="offset-content tab-content">
            <div id="activity" class="tab-pane fade in show active">
                <div class="recent-activity">
                    <div class="timeline-task">
                        <div class="icon bg1">
                            <i class="fa fa-envelope"></i>
                        </div>
                        <div class="tm-title">
                            <h4>Rashed sent you an email</h4>
                            <span class="time"><i class="ti-time"></i>09:35</span>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                        </p>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg2">
                            <i class="fa fa-check"></i>
                        </div>
                        <div class="tm-title">
                            <h4>Added</h4>
                            <span class="time"><i class="ti-time"></i>7 Minutes Ago</span>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur.
                        </p>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg2">
                            <i class="fa fa-exclamation-triangle"></i>
                        </div>
                        <div class="tm-title">
                            <h4>You missed you Password!</h4>
                            <span class="time"><i class="ti-time"></i>09:20 Am</span>
                        </div>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg3">
                            <i class="fa fa-bomb"></i>
                        </div>
                        <div class="tm-title">
                            <h4>Member waiting for you Attention</h4>
                            <span class="time"><i class="ti-time"></i>09:35</span>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                        </p>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg3">
                            <i class="ti-signal"></i>
                        </div>
                        <div class="tm-title">
                            <h4>You Added Kaji Patha few minutes ago</h4>
                            <span class="time"><i class="ti-time"></i>01 minutes ago</span>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                        </p>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg1">
                            <i class="fa fa-envelope"></i>
                        </div>
                        <div class="tm-title">
                            <h4>Ratul Hamba sent you an email</h4>
                            <span class="time"><i class="ti-time"></i>09:35</span>
                        </div>
                        <p>Hello sir , where are you, i am egerly waiting for you.
                        </p>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg2">
                            <i class="fa fa-exclamation-triangle"></i>
                        </div>
                        <div class="tm-title">
                            <h4>Rashed sent you an email</h4>
                            <span class="time"><i class="ti-time"></i>09:35</span>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                        </p>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg2">
                            <i class="fa fa-exclamation-triangle"></i>
                        </div>
                        <div class="tm-title">
                            <h4>Rashed sent you an email</h4>
                            <span class="time"><i class="ti-time"></i>09:35</span>
                        </div>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg3">
                            <i class="fa fa-bomb"></i>
                        </div>
                        <div class="tm-title">
                            <h4>Rashed sent you an email</h4>
                            <span class="time"><i class="ti-time"></i>09:35</span>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                        </p>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg3">
                            <i class="ti-signal"></i>
                        </div>
                        <div class="tm-title">
                            <h4>Rashed sent you an email</h4>
                            <span class="time"><i class="ti-time"></i>09:35</span>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                        </p>
                    </div>
                </div>
            </div>
            <div id="settings" class="tab-pane fade">
                <div class="offset-settings">
                    <h4>General Settings</h4>
                    <div class="settings-list">
                        <div class="s-settings">
                            <div class="s-sw-title">
                                <h5>Notifications</h5>
                                <div class="s-swtich">
                                    <input type="checkbox" id="switch1" />
                                    <label for="switch1">Toggle</label>
                                </div>
                            </div>
                            <p>Keep it 'On' When you want to get all the notification.</p>
                        </div>
                        <div class="s-settings">
                            <div class="s-sw-title">
                                <h5>Show recent activity</h5>
                                <div class="s-swtich">
                                    <input type="checkbox" id="switch2" />
                                    <label for="switch2">Toggle</label>
                                </div>
                            </div>
                            <p>The for attribute is necessary to bind our custom checkbox with the input.</p>
                        </div>
                        <div class="s-settings">
                            <div class="s-sw-title">
                                <h5>Show your emails</h5>
                                <div class="s-swtich">
                                    <input type="checkbox" id="switch3" />
                                    <label for="switch3">Toggle</label>
                                </div>
                            </div>
                            <p>Show email so that easily find you.</p>
                        </div>
                        <div class="s-settings">
                            <div class="s-sw-title">
                                <h5>Show Task statistics</h5>
                                <div class="s-swtich">
                                    <input type="checkbox" id="switch4" />
                                    <label for="switch4">Toggle</label>
                                </div>
                            </div>
                            <p>The for attribute is necessary to bind our custom checkbox with the input.</p>
                        </div>
                        <div class="s-settings">
                            <div class="s-sw-title">
                                <h5>Notifications</h5>
                                <div class="s-swtich">
                                    <input type="checkbox" id="switch5" />
                                    <label for="switch5">Toggle</label>
                                </div>
                            </div>
                            <p>Use checkboxes when looking for yes or no answers.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- offset area end -->
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>

    <!-- start chart js -->
    <script src="../../../cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js"></script>
    <!-- start highcharts js -->
    <script src="../../../code.highcharts.com/highcharts.js"></script>
    <!-- start zingchart js -->
    <script src="../../../cdn.zingchart.com/zingchart.min.js"></script>
    <script>
    zingchart.MODULESDIR = "../../../external.html?link=https://cdn.zingchart.com/modules/";
    ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9", "ee6b7db5b51705a13dc2339db3edaf6d"];
    </script>
    <!-- all line chart activation -->
    <script src="assets/js/line-chart.js"></script>
    <!-- all pie chart -->
    <script src="assets/js/pie-chart.js"></script>
    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="../../../external.html?link=https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
</body>


<!-- Mirrored from colorlib.com/polygon/srtdash/index.html by HTTrack Website Copier/3.x [XR&CO'2017], Sun, 04 Nov 2018 17:02:23 GMT -->
</html>