<?php


session_start();
error_reporting(0);
if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){
	echo "<script>location.href='/'</script>";
  die();
}


?>


<html><head>

<DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />





    <script type="text/javascript">
        function pushPaypalDie(str){
            document.getElementById(\'listPaypalDie\').innerHTML += \'<div>\' + str + \'</div>\';
        }
        function pushPaypal(str){

            document.getElementById(\'listPaypal\').innerHTML += \'<div>\' + str + \'</div>\';

        }

        function pushWrongFormat(str){

            document.getElementById(\'listWrongFormat\').innerHTML += \'<div>\' + str + \'</div>\';

        }



    </script>

	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">

</head>

<br>
<a>

  <font size="4" color="#2175ff">VALIDADE  AO LOGIN</font><br>

<body><center>
  <table class="table">
    <thead>
      <tr>
        <th>VALIDADE</th>
        <th>Preço (REAL)</th>
      </tr>
    </thead>
    <tbody>
      <tr class="success">
        <td>+ 1 MÊS </td>
        <td>POR: R$ 25,00</td>
      </tr>
      
            </div>
      <tr class="info">
        <td>+ 2 Meses</td>
        <td>POR: R$ 70,00</td>
      </tr>
      <tr class="success">
        <td>+ 3 Meses</td>
        <td>POR: R$ 120,00</td>
      </tr>
      <tr class="info">
        <td>+ 7 Meses </td>
        <td>POR: R$ 550,00</td>
        
        
      </tr>
    </tbody>
  </table>
</div>
<a>
<a>

</head>
<a>
<a>

 <font size="4" color="#2175ff">VENDAS DE CREDITOS</font><br>


<body><center>
  <table class="table">
    <thead>
      <tr>
        <th>CREDITOS</th>
        <th>Preço (REAL)</th>
      </tr>
    </thead>
    <tbody>
      <tr class="success">
        <td>960$ CREDITOS</td>
        <td>POR: R$ 40,00</td>
      </tr>
      <tr class="info">
        <td>100 CREDITOS</td>
        <td>POR: R$ 70,00</td>
      </tr>
      <tr class="success">
        <td>2900 CREDITOS</td>
        <td>POR: R$ 120,00</td>
      </tr>
      <tr class="info">
        <td>760.00 CREDITOS</td>
        <td>POR: R$ 550,00</td>
      </tr>
    </tbody>
  </table>
</div>


<a href="contato
              ">ADQUIRIR</a>
            </div>