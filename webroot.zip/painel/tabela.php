<?php 
error_reporting(0);
set_time_limit(0);
session_start();



extract($_POST);

if($_SESSION['rank'] !== "Administrador"){
    die("PAGINA INEXISTENTE");
}





if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){
echo '<script language= "JavaScript">location.href="/"</script><br>';
  die();
}

$array_usuarios = file("../usuarios.txt");
$total_usuarios_registrados = count($array_usuarios);

$continuar = false;
for($i=0;$i<count($array_usuarios);$i++){
  $explode = explode("|" , $array_usuarios[$i]);
  if($_SESSION['usuario'] == $explode[0]){

date_default_timezone_set('America/Sao_Paulo');
$datinha = date('H:i');
$data_dia = date ("Y-m-d");
$ramdom_key = substr(str_shuffle(str_repeat("0123456789", 16)), 0, 16);
$data_auxilio_form = date ('d/m/Y');
$usuario = $_SESSION['usuario'];
$senha = $_SESSION['senha'];
$rank = $_SESSION['rank'];
$nome = $_SESSION['nome'];
$ip = $_SERVER['REMOTE_ADDR'];

    $_SESSION['senha'] = $explode[1];
    $_SESSION['rank'] = $explode[2];
    $_SESSION['nome'] = $explode[3];
    $_SESSION['foto'] = $explode[4];
    $continuar = true;
  }
}

if(!$continuar){
echo '<script language= "JavaScript">location.href="/"</script><br>';
die();
}





?>

<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from colorlib.com/polygon/srtdash/table-basic.html by HTTrack Website Copier/3.x [XR&CO'2017], Sun, 04 Nov 2018 17:03:14 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo $data_auxilio_form  ?> Gerenciamento de usuários</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <!-- amchart css -->
    <link rel="stylesheet" href="../../../www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <!-- others css -->
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- modernizr css -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- page container area start -->
    
        <!-- sidebar menu area end -->
        
                      
                            
                            
                            
                            
                            
                            
                            
 
            <!-- page title area end -->
            
            
            
            
            
            <div class="main-content-inner">
                
                    
                    
                    
                    <!-- table primary end -->
                    <!-- table success start -->
                    <div class="col-lg-6 mt-5">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">PAGINA ADMIN GERAL</h4>
                                <div class="single-table">
                                    <div class="table-responsive">
                                        <table class="table text-center">
                                            <thead class="text-uppercase bg-success">
                                                <tr class="text-white">
                                                    <th scope="col">Usuário</th>
                                                    <th scope="col">Senha</th>
                                                    <th scope="col">Rank</th>
                                                    <th scope="col">Nome</th>
                                                    <th scope="col">Key</th>
                                                    <th scope="col">Saldo</th>
                                                    <th scope="col">Data de Reg.</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            
                                            
                                            
                                            
                                            

<tr><th scope="row">lotter</th><td>lotter</td><td></td><td>lotter</td><td>ADMINISTRADOR</td><td></td><td>2019-12-25 19:30</td></tr>

<tr><th scope="row">uaqtzvrr@mailart.top</th><td>88980865</td><td></td><td>Professor Ferreira</td><td></td><td></td><td>2019-12-25 14:18</td></tr>

<tr><th scope="row">lotter</th><td>lotter</td><td></td><td>lotter</td><td>ADMIN</td><td></td><td>2019-12-25 14:02</td></tr>

<tr><th scope="row">lotter</th><td>lotter</td><td></td><td>lotter</td><td>key</td><td></td><td>2019-12-25 14:00</td></tr>







                                            

<tr><th scope="row">990</th><td>990</td><td>Administrador</td><td>Total Xanarchy♨️</td><td>6457079046948319</td><td>99999</td><td>2030-11-16 16:44</td></tr>


                                  
                                            </tbody>
                                            </table>
                                        
                                        
                                        
                                       
                                        
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- table success end -->
                    <!-- table info start -->
                    
                    <div class="main-content-inner">
                    <div class="row">
                    <!-- table primary start -->
                    <div class="col-lg-6 mt-5">
                    <div class="card">
                    <div class="card-body">
                    <h4 class="header-title">FlashReverso - Adicionar permissão de registro</h4>
                    <div class="single-table">
                    <div class="table-responsive">
                    <table class="table text-center">
                    <thead class="text-uppercase bg-primary">
                    <tr class="text-white">
                    <th scope="col">Key</th>
                    <th scope="col">Rank</th>
                    <th scope="col">Vence:</th>
                    <th scope="col">Saldo</th>
                    <th scope="col">Expira:</th>
                    <th scope="col">Ação</th>
            
            
            
            <form id="login-form" method="post">
            <form>
            
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                    
                    
                    <td><div class="form-gp">
                    <label for="key"></label>
                    <input type="tel" class="key" id="key" name="key" value="<?php echo $random_key; ?>" maxlength=16>
                    </div></td>
                    
                    
                    <td>
                         
                         
                         <div class="form-gp">
                    
                    
                    <style>
                    .div {
                    width: 200px;
                    margin: 50px auto;                                                                                                                                                       
                    }
                    select.menu {
                    width: 200px;
                    height: 35px;
                    background: #f5f5f5;
                    border: 0;
                    }
                    </style>
                    <div class="form-gp">
                    
                    <select style="border-radius: 10px;" name="rank" class="menu">Selecione o seu ranking:<option>Selecione o seu rank:</option><option>Premier</option><option>Diamond</option><option>Platina</option><option>TotalXanarchy</option><option>Administrador</option><option>Revendedor</option></select>
                    
                    
                    </div>
                    </td>
                    
                    
                    <td>
                    
                    
                    <div class="form-gp">
                    <label for="example-date-input" class="col-form-label"></label>
                    <input style="background: #f5f5f5; border-radius: 10px; border: 0; height: 35px;" class="menu" name="expira" type="date" value="<?php echo $data_dia ?>" id="example-date-input">
                    </div>
                    
                    
                    
                    
                    </td>
                    
                    
                    
                    <td>
                    <div class="form-gp">
                    <label for="saldo"></label>
                    <input type="tel" id="saldo" name="saldo" maxlength=5>
                    </div>
                    </td>
                    
                    
                    <td>
                  
                      
                      
                      <div class="form-gp">
                      <label for="time"></label>
                      <input style="background: #f5f5f5; border-radius: 10px; border: 0; height: 35px;" class="menu" type="time" id="time" name="time" value="<?php echo $datinha; ?>">
                      </div>
                      </td>
                      
                    
                    
                    <td>
                    
                    
                    <button id="form_submit" type="submit" class="btn btn-rounded btn-primary mb-3">Salvar</button>
                    
                    <a href="../usuarios.txt">Observa usuarios</a>
            </div>
                    
                    
                    
                    </td>
                    
                    
                    
                    
                    
                    
                    
                    
                    </tr>
                    
                    
                    
                    
                    
                    
                    
                    
                    </tbody>
                    </table>
                   
                    </div>
                    </div>
                    </div>
                    </div>
                    
                    
                    </form>
                    
                    
                    
                    
                    
                    
                    <?php
                    
                    
                    
                    $datinha = date('H:i:s');
                    
                    if(isset($_POST['key'])){
                    $rank = trim(htmlspecialchars($_POST['rank']));
                    $key = trim(htmlspecialchars($_POST['key']));
                    $saldo = trim(htmlspecialchars($_POST['saldo']));
                    $expira = trim(htmlspecialchars($_POST['expira']));
                    date_default_timezone_set('America/Sao_Paulo');
                    $time = trim(htmlspecialchars($_POST['time']));
                    $saldo2 = $_POST['saldo'];
                    
                    
                    
                    
                    
                    
                    if($saldo !== $saldo2){
                    echo "<script>swal('erro' , 'Senha de confirmação incorreta' , 'error');</script>";
                    }else{
                    if(strpos($key , '|') !== false or strpos($saldo , '|') !== false){
                    echo "<script>swal('erro' , 'Usuario ou Senha Contem um caracter não permitido' , 'error');</script>";
                    }else{
                    
                    
                    
                    
                    
                    $continuar = true;
                    for($i=0;$i<count($array); $i++)
                    {
                    $explode = explode("|" , $array[$i]);
                    if($explode[0] == $key){
                    $continuar = false;
                    }
                    }
                    
                    
                    
                    
                    if(!$continuar){
                    echo "<script>swal('erro' , 'Key já existe' , 'error');</script>";
                    }else{
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    $arquivo_keys = './keys.txt';
                    if (file_exists($arquivo_keys)) {
                    echo "Error_reporting_0 Keys indisponíveis no momento, por favor aguarde a utilização da Key atual";
                    echo '<meta http-equiv="refresh" content="2;url=tabela.php">';
                    exit;
                    } else {
                    echo "sucess";
                   
                    }
                    $fp = fopen("../keys.txt" , "a+");
                    $escreve =  fwrite($fp, ''.$key.'');
                    fclose($fp);
                    
                    
                    $fp = fopen("../saldo.txt" , "a+");
                    $escreve =  fwrite($fp, ''.$saldo.'');
                    fclose($fp);
                    
                    
                    
                    $fp = fopen("../expira.txt" , "a+");
                    $escreve =  fwrite($fp, ''.$expira.' '.$time.'');
                    fclose($fp);
                    
                    
                    $fp = fopen("../rank.txt" , "a+");
                    $escreve =  fwrite($fp, ''.$rank.'');
                    fclose($fp);
                    
                    
                    
                    echo '<meta http-equiv="refresh" content="2;url=invoice.php">';
                    }
                    
                    }
                    
                    
                    
                    ////
                    
                    
                    }
                    }
                    
                    ?>
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                  
                  
                  
                  
                    </div>
                
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>

    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="../../../external.html?link=https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
</body>










</html>