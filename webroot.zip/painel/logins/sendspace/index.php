<?php


session_start();
error_reporting(0);
if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){
	echo "<script>location.href='/'</script>";
  die();
}


?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Checker Sendspace</title>
 
<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>

	<style>
	html {
         font-size: 16px;
         background-color: #212121;
         color: #1ABB9C;
         font-family: 'Aldrich', sans-serif;

     }
     body {    
     	background-color: #212121;
     }
     .lista {
       width: 750px;
       height: 230px;
       text-align: center;
       resize: none;
       background-color: #424242;
       color: #69F0AE;
       font-size: 17px;
       border: 2px solid #69F0AE;
       border-radius: 3px;
       overflow: hidden;
     }
     .lista:focus {
     	outline: none;
     }
     .afs {
     	font-weight: bold;
     }
     .green {
     	background-color: #4caf50;
        color: rgba(255, 255, 255, 0.87);
        padding: 0.25em 0.5em;
        border-radius: 2px;
     }
     .red {
        background-color: #f44336;
        color: rgba(255, 255, 255, 0.87);
        padding: 0.25em 0.5em;
        border-radius: 2px;
     }
     .check {
     	background-color: #FFAB00;
     	color: rgba(255, 255, 255, 0.87);
        padding: 0.25em 0.5em;
        border-radius: 2px;
     }
     .botao {
     	margin-top: 10px;
     	width: 150px;
     	height: 50px;
     	background-color: #2C3A48;
     	border-radius: 5px;
     	border: none;
     	color: rgba(255, 255, 255, 0.87);
     	cursor: pointer;
     	    -webkit-appearance: button;
     	    transition: all .2s ease-in-out;
          font-family: 'Aldrich', sans-serif;
     }
     .botao:hover {
     	background-color: rgba(255, 255, 255, 0.87);
     	color: #2C3A48;
     }
     .botao:focus {
     	outline: none;
     }
     .test {
       resize: none;
       background-color: #2C3A48;
       color: #fff;
       border: none;
       text-align: center;
       width: 660px;
       height: 200px;
     }
    .test:focus {
       outline: none;
    }
    .back {
     color: #1ABB9C;
     text-decoration: none;
    }
    .back:hover {
      text-shadow: 1px 1px 1px #1ABB9C;
    }
    .panel{
      border-radius: 3px;
      background-color: #424242;
      width: 700px;
      height: 200px;
      border-right: 1px solid #00bc8c;
      border-left: 1px solid #00bc8c;
      border-bottom: 1px solid #00bc8c;
    }
    .panel-title{
      width: 700px;
      height: 25px;
      background-color: #00bc8c;
      border-bottom: 3px solid transparent;
    }
    .panelm{
      border-radius: 3px;
      background-color: #424242;
      width: 700px;
      height: 200px;
      border-right: 1px solid #e74c3c;
      border-left: 1px solid #e74c3c;
      border-bottom: 1px solid #e74c3c;
    }
    .panelm-title{
      width: 700px;
      height: 25px;
      background-color: #e74c3c;
      border-bottom: 3px solid transparent;
    }
	</style>
<script>

function start()
{
  var i;
  var tudo =$('#text').val();
  var linha = tudo.split("\n");
  var separador= "|"
  //alert(cc.length);
  for (i = 0; i < linha.length; i++) {
    //alert(cc[i]);
    var separado = linha[i];
    var id = i;
    check(separado, separador, id);
    //setTimeout(function() { alert(j) }, 100, i);check(cc2, separador, id);
  }
}
var aps = 0;
var rps = 0;
var testadas = 0;
function check(separado, separador, id){
  setTimeout(function() {
    $.ajax({
      type:   'GET',
      url:  'net.php',
      dataType: 'html',
      data: { 'linha':separado },
      success: function(msg)
      {
        ++testadas;
document.getElementById('testado').innerText = testadas;
                            if(msg.indexOf("DIE") >= 0){
                                var reprovadas2 = $("#resultado2").val();
                                ++rps;
                                document.getElementById('reprovada_conta').innerText = rps;
                                $("#resultado2").val(reprovadas2 + msg + "\n")
                            }else{
                                var reprovadas = $("#resultado").val();
                                ++aps;
                                document.getElementById('aprovada_conta').innerText = aps;
                                $("#resultado").val(reprovadas + msg + "\n")
                            }
        //





      }
    });
  }, id * 1000);
}
</script>
</head>
<body>
  <center>
   <font size="7">Checker  Sendspace</font> <br />
   <br /><br />
      <textarea class="panel panel-primary" cols="90" rows="10" id="text" name="text" placeholder=" Email|Senha "></textarea>
      <br /><div class="afs">
           <font size="2">
                      <span id="status" class="cyan">Aprovadas : <span id="aprovada_conta" class="green">0</span> - Reprovadas : <span id="reprovada_conta" class="red">0</span> -Testadas : <span id="testado" class="check">0</span>             <br /><br />
            <button type="submit" id="x" name="x" class="btn btn-success" onclick="start()">Testar</button>
            <button type="submit" id="x" name="x" class="btn btn-danger" onclick="stop()">Parar</button>
<font></font>
 <br /><br />

 <textarea class="panel panel-primary" id="resultado" style="width: 527px; height: 195px;"></textarea>
 <textarea class="panel panel-primary" id="resultado2" style="width: 527px; height: 195px;"></textarea>
</center>
</body>
</html>
