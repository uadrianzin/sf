<?php 'doador@hotmail.com|ASADELTA SEM PRODUTOS' ?>
<?php 'yurimoura77@gmail.com|deus0709 SEM PRODUTOS' ?>
<?php 'lhuis@uol.com.br|dani2411 SEM PRODUTOS' ?>
<?php 'japnja@gmail.com|joaupi01 SKY LIGHT HD 2015 - P' ?>
<?php 'felixmanara@hotmail.com|egito2010 SKY PRÉ PAGO POP 12M' ?>
<?php 'marcello.rio@ig.com.br|270894 SEM PRODUTOS' ?>
<?php 'edigcmagal@gmail.com|sofia24 SEM PRODUTOS' ?>
<?php 'ariel-wicca@hotmail.com|magic666 COMBO PLUS CINEMA HD 2017 - A' ?>
<?php 'adilson_dsp@yahoo.com.br|1422 SEM PRODUTOS' ?>
<?php 'domingues.56@terra.com.br|050667 NEW SKY LIGHT 2013 II S - P' ?>
<?php 'psicoricardo@gmail.com|019780 SKY LIVRE TURBO' ?>
<?php 'elys_f@hotmail.com|sunset77. SKY FIT PRÉ PAGO 12M' ?>
<?php 'carlabuhatem@elo.com.br|rosa2006 COMBO FULL TOP HD 2018 - P' ?>
<?php 'li_rs@terra.com.br|300108 SKY PRÉ PAGO FLEX C' ?>
<?php 'pcarvalho.se@gmail.com|dehop@09 SEM PRODUTOS' ?>
<?php 'jorgeeescobar@gmail.com|79104830 SEM PRODUTOS' ?>
<?php 'claudiaflorais@gmail.com|nascentes144 NEW MASTER II 2017 - A' ?>
<?php 'marcos.frederico@gmail.com|mffs0170 COMBO FULL FUTEBOL HD 2018 - A' ?>
<?php 'solsetembro@gmail.com|e2014Mari Sky Modelo Zapper' ?>
<?php 'eng.marlenefreitas@terra.com.br|Lenzop42 COMBO FULL CINEMA HD 2018 - A' ?>
<?php 'p_m_farias@hotmail.com|livraria SEM PRODUTOS' ?>
<?php 'framcosta@hotmail.com|260581 SKY PRÉ PAGO FLEX C' ?>
<?php 'luizrossi@uol.com.br|verdes SEM PRODUTOS' ?>
<?php 'llumoraes@hotmail.com|18461828 NEW MASTER II 2017 - A' ?>
<?php 'gfneto@uai.com.br|gabi0000 SEM PRODUTOS' ?>
<?php 'lolo.paredes@hotmail.com|9876543210v SEM PRODUTOS' ?>
<?php 'wladimirguitte@ig.com.br|369010 SEM PRODUTOS' ?>
<?php 'nelynearaujo@gmail.com|UNI88part SEM PRODUTOS' ?>
<?php 'hsfirri@hotmail.com|mhsc6054 SEM PRODUTOS' ?>
<?php 'tonicotta@ig.com.br|GGA0103 SEM PRODUTOS' ?>
<?php 'corbani.filo@gmail.com|130309 SEM PRODUTOS' ?>
<?php 'analia.na@hotmail.com|pe19bo20 SKY DIGITAL 2013' ?>
<?php 'marceloalexandrevalle@yahoo.com.br|teologo1972 SEM PRODUTOS' ?>
<?php 'julio80nobre@gmail.com|julio123 SEM PRODUTOS' ?>
<?php 'valmirpinheiro@hotmail.com|rak33234 Equipamento' ?>
