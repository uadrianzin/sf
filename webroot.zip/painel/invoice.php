<?php 
error_reporting(0);
set_time_limit(0);
session_start();



extract($_POST);







if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){
echo '<script language= "JavaScript">location.href="/"</script><br>';
  die();
}

$array_usuarios = file("../usuarios.txt");
$total_usuarios_registrados = count($array_usuarios);

$continuar = false;
for($i=0;$i<count($array_usuarios);$i++){
  $explode = explode("|" , $array_usuarios[$i]);
  if($_SESSION['usuario'] == $explode[0]){

date_default_timezone_set('America/Sao_Paulo');
$datinha = date('H:i');
$data_dia = date ("Y-m-d");
$ramdom_key = substr(str_shuffle(str_repeat("0123456789", 16)), 0, 16);
$data_auxilio_form = date ('d/m/Y');
$usuario = $_SESSION['usuario'];
$senha = $_SESSION['senha'];
$rank = $_SESSION['rank'];
$nome = $_SESSION['nome'];
$key = $_SESSION['key'];
$ip = $_SERVER['REMOTE_ADDR'];


    $_SESSION['senha'] = $explode[1];
    $_SESSION['rank'] = $explode[2];
    $_SESSION['nome'] = $explode[3];
    $_SESSION['foto'] = $explode[4];
    $continuar = true;
  }
}

if(!$continuar){
echo '<script language= "JavaScript">location.href="/"</script><br>';
die();
}





?>



<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from colorlib.com/polygon/srtdash/invoice.html by HTTrack Website Copier/3.x [XR&CO'2017], Sun, 04 Nov 2018 17:03:28 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Invoice - FlashReverso</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <!-- amchart css -->
    <link rel="stylesheet" href="../../../www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <!-- others css -->
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- modernizr css -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- page container area start -->
    <div class="page-container">
        <!-- sidebar menu area start -->
        
        
        
        <!-- sidebar menu area end -->
        <!-- main content area start -->
        <div class="main-content">
            <!-- header area start -->
            
            
            
     
            <!-- header area end -->
            <!-- page title area start -->
            
            
            
            
            
            
            <?php
            
                        if(!file_exists("../keys.txt")){
            echo '<meta http-equiv="refresh" content="0;url=560.html">';

            exit;
            }
            $arquivo_key = file("../keys.txt");
            foreach($arquivo_key as $key_kiwi)
            
            $arquivo_rank = file("../rank.txt");
            foreach($arquivo_rank as $rank_kiwi)
            
            
            $arquivo_expira = file("../expira.txt");
            foreach($arquivo_expira as $expira_kiwi)
            
            $arquivo_saldo = file("../saldo.txt");
            foreach($arquivo_saldo as $saldo_kiwi)
            
            $bin_key = substr($key_kiwi, 0,6);
            $dia_atual = date('d');
            $mes_atual = date('m');
            $ano_atual = date('Y');
            
            
            if($rank_kiwi == 'Premier'){
            $rank_preco = '100,00';
            }
            elseif($rank_kiwi == 'Diamond'){
            $rank_preco = '150,00';
            }
            if($rank_kiwi == 'Platina'){
            $rank_preco = '200,00';
            }
            elseif($rank_kiwi == 'TotalXanarchy'){
            $rank_preco = '350,00';
            }
            if($rank_kiwi == 'Administrador'){
            $rank_preco = '850,00';
            }
            elseif($rank_kiwi == 'Revendedor'){
            $rank_preco = '500,00';
            }
            
            
            ?>
            
            
            
            
            
            
            
            
            
            
            <!-- page title area end -->
            <div class="main-content-inner">
                <div class="row">
                    <div class="col-lg-12 mt-5">
                        <div class="card">
                            <div class="card-body">
                                <div class="invoice-area">
                                    <div class="invoice-head">
                                        <div class="row">
                                            <div class="iv-left col-6">
                                                <span>Total</span>
                                            </div>
                                            <div class="iv-right col-6 text-md-right">
                                                <span>#<?php echo $bin_key; ?></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row align-items-center">
                                        <div class="col-md-6">
                                            <div class="invoice-address">
                                                <h3>total da compra</h3>
                                                <h5>Dados e informações</h5>
                                                <p>USUARIO: <?php echo $usuario ?> </p>
                                                <p>SENHA: <?php echo $senha ?></p>
                                                <p>Empresa: Xanarchy</p>
                                                <p>Valor: <?php echo $rank_preco;    ?> </p>
                                            </div>
                                        </div>
                                        <div class="col-md-6 text-md-right">
                                            <ul class="invoice-date">
                                                <li>Data Atual: : <?php echo $dia_atual ?> | <?php echo $mes_atual ?> | <?php echo $ano_atual; ?></li>
                                                <li>Atualizacao : <?php echo $dia_atual ?> | <?php echo $mes_atual ?> | <?php echo $ano_atual; ?></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="invoice-table table-responsive mt-5">
                                        <table class="table table-bordered table-hover text-right">
                                            <thead>
                                                <tr class="text-capitalize">
                                                    <th class="text-center" style="width: 4%;">Key</th>
                                                    <th class="text-left" style="width: 45%; min-width: 130px;">Rank</th>
                                                    <th>Expira:</th>
                                                    <th style="min-width: 100px">Saldo</th>
                                                    <th>Cálculo</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="text-center"><?php echo $key_kiwi; ?></td>
                                                    <td class="text-left"><?php echo $rank_kiwi; ?></td>
                                                    <td><?php echo $expira_kiwi   ?></td>
                                                    <td><?php echo $saldo_kiwi ?></td>
                                                    <td>Automático</td>
                                                </tr>
                                                
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <td colspan="4">total do plano:</td>
                                                    <td>R$: <?php echo $rank_preco;    ?></td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                                <div class="invoice-buttons text-right">
                                    <a href="tabela.php" class="invoice-btn">Voltar a tabela</a>
                                    <a href="index.php" class="invoice-btn">Voltar ao painel</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- main content area end -->
        <!-- footer area start-->
        <footer>
            <div class="footer-area">
                <p>© Copyright 2018. All right reserved. Template by <a href="https://t.me/FlashReversoOFC">FlashReverso♨️💔</a></p></p>
            </div>
        </footer>
        <!-- footer area end-->
    </div>
    <!-- page container area end -->
    <!-- offset area start -->
    
   
    <!-- offset area end -->
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>

    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="../../../external.html?link=https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
</body>


<!-- Mirrored from colorlib.com/polygon/srtdash/invoice.html by HTTrack Website Copier/3.x [XR&CO'2017], Sun, 04 Nov 2018 17:03:28 GMT -->
</html>