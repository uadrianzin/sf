﻿<?php

error_reporting(0);
set_time_limit(0);
session_start();


if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){
echo '<script language= "JavaScript">location.href="/"</script><br>';
  die();
}

$array_usuarios = file("../usuarios.txt");
$total_usuarios_registrados = count($array_usuarios);

$continuar = false;
for($i=0;$i<count($array_usuarios);$i++){
  $explode = explode("|" , $array_usuarios[$i]);
  if($_SESSION['usuario'] == $explode[0]){







date_default_timezone_set('America/Sao_Paulo');
$data_atual = date('Y-m-d H:i');
$usuario = $_SESSION['usuario'];
$senha = $_SESSION['senha'];
$rank = $_SESSION['rank'];
$nome = $_SESSION['nome'];
$key = $_SESSION['key'];
$saldo = $_SESSION['saldo'];
$expira = $_SESSION['expira'];
$ip = $_SERVER['REMOTE_ADDR'];


    $_SESSION['rank'] = $explode[2];
    $_SESSION['nome'] = $explode[3];
    $_SESSION['key'] = $explode[4];
    $_SESSION['saldo'] = $explode[5];
    $_SESSION['expira'] = $explode[6];
    $continuar = true;
  }
}

if(!$continuar){
echo '<script language= "JavaScript">location.href="/"</script><br>';
die();
}

        



$totalconsultaveis = count( file( '../../total_ccs.txt' ) );



$linhas = count(file("../../total_ccs.txt"));
 

if($data_atual >= $expira){
$filename = '../usuarios.txt';
$lines = file($filename); 
$output = '';
foreach ($lines as $line) {
if (!strstr($line, $key)) {
$output .= $line;
} 
}
file_put_contents($filename, $output);
echo '<meta http-equiv="refresh" content="0;url=401.html">';
exit;

}

?>

<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from colorlib.com/polygon/srtdash/register4.html by HTTrack Website Copier/3.x [XR&CO'2017], Sun, 04 Nov 2018 17:03:28 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Cadastro - FLASH</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <!-- amchart css -->
    <link rel="stylesheet" href="../../../www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <!-- others css -->
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- modernizr css -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/jquery.mobile-1.3.2.min.js"></script>
<script src="js/jquery.mask.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/script.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js"></script>

<!-- mascara -->
<script type="text/javascript">
$(document).ready(function(){
		 $("input.key").mask("9999");
		 $("input.saldo").mask("999.99");
	   });
</script>

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- login area start -->
    <div class="login-area login-bg">
        <div class="container-fluid p-0">
            <div class="row no-gutters">
                <div class="col-xl-4 offset-xl-8 col-lg-6 offset-lg-6">
                    <div class="login-box-s2 ptb--100">
                        
                        
                        <form id="login-form" method="post">
                        <form>
                        
                        
                        
                            <div class="login-form-head">
                                <h4>CENTRAL FLASH</h4>
                                <p>Olá, ativar cod </p>
                            </div>
                            <div class="login-form-body">
                                <div class="form-gp">
                                    <label for="exampleInputName1">Cod</label>
                                    <input type="text" id="exampleInputName1" name="nome">
                                    <i class="ti-user"></i>
                                   </div>
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                <div class="submit-btn-area">
                                    <button id="form_submit" type="submit">Ativar<i class="ti-arrow-right"></i></button>
                                    <div class="login-other row mt-4">
                                
                                
                                
                                
                                
                                
                           
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                        
                        
                        
                        
                        
                        
                        
                             
                             
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- login area end -->

    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>

    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="../../../external.html?link=https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
</body>



<?php
                             
                             
                             
                             
                             if(isset($_POST['usuario'])){
                             $usuario = trim(htmlspecialchars($_POST['usuario']));
                             $senha = trim(htmlspecialchars($_POST['senha']));
                             $nome = trim(htmlspecialchars($_POST['nome']));                             
                             $key = trim(htmlspecialchars($_POST['cod']));     
                                                     date_default_timezone_set('America/Sao_Paulo');
                                                     $data_atual = date('Y-m-d H:i');
                             $senha2 = $_POST['senha1'];
                             
                             
                             
                             
                             
                             
                             $arquivo_saldo = file("saldo.txt");
                             foreach($arquivo_saldo as $saldo)
                             
                             
                             
                             $arquivo_rank = file("rank.txt");
                             foreach($arquivo_rank as $rank)
                          
                             
                             
                             
                             
                             $arquivo_data = file("expira.txt");
                             foreach($arquivo_data as $expira)
                            
                           
                             
                             
                             
                             $arquivo = file("resgatar.txt");
                             foreach($arquivo as $cod_original)
                             if($cod = $cod_original){
                             echo 'cod utilizado com sucesso!!!';
                             unlink("resgatar.txt");
                             }else{
                             echo 'cod inválido!!';
                             exit;
                             }
                             
                             $fp = fopen("usuarios.txt" , "a+");
                             $escreve =  fwrite($fp, ''.$cod.'|'.$saldo.'|'.$expira.'|' . PHP_EOL . '');
                             fclose($fp);
                             $pularlinha = PHP_EOL;
                             $lines = file( 'painel/tabela.php', FILE_IGNORE_NEW_LINES ); $target = 149; $lines[ $target - 1 ] = ''.$pularlinha.'<tr><th scope="row">'.$cod.'</td><td>'.$saldo.'</td></tr>'.$pularlinha.''; file_put_contents( 'painel/tabela.php', implode( PHP_EOL, $lines ) );
                             fclose($fp);
                             unlink("expira.txt");
                             unlink("rank.txt");
                             unlink("saldo.txt");
                             echo '<meta http-equiv="refresh" content="2;url=index.php">';
                             
                             
                             
                             
                             
                             
                             
                             
                             
                             
                             
                             
                             ////
                             
                             
                             }
                             
                             
                             ?>





<!-- Mirrored from colorlib.com/polygon/srtdash/register4.html by HTTrack Website Copier/3.x [XR&CO'2017], Sun, 04 Nov 2018 17:03:28 GMT -->
</html>