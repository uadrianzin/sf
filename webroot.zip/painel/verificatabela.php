<?php 
error_reporting(0);
set_time_limit(0);
session_start();


if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){
echo '<script language= "JavaScript">location.href="/"</script><br>';
  die();
}

$array_usuarios = file("../usuarios.txt");
$total_usuarios_registrados = count($array_usuarios);

$continuar = false;
for($i=0;$i<count($array_usuarios);$i++){
  $explode = explode("|" , $array_usuarios[$i]);
  if($_SESSION['usuario'] == $explode[0]){







date_default_timezone_set('America/Sao_Paulo');
$data_atual = date('Y-m-d H:i');
$usuario = $_SESSION['usuario'];
$senha = $_SESSION['senha'];
$rank = $_SESSION['rank'];
$nome = $_SESSION['nome'];
$key = $_SESSION['key'];
$saldo = $_SESSION['saldo'];
$expira = $_SESSION['expira'];
$ip = $_SERVER['REMOTE_ADDR'];


    $_SESSION['rank'] = $explode[2];
    $_SESSION['nome'] = $explode[3];
    $_SESSION['key'] = $explode[4];
    $_SESSION['saldo'] = $explode[5];
    $_SESSION['expira'] = $explode[6];
    $continuar = true;
  }
}

if(!$continuar){
echo '<script language= "JavaScript">location.href="/"</script><br>';
die();
}

        



$totalconsultaveis = count( file( '../../total_ccs.txt' ) );



$linhas = count(file("../../total_ccs.txt"));
 

if($data_atual >= $expira){
$filename = 'tabela.php';
$lines = file($filename); 
$output = '';
foreach ($lines as $line) {
if (!strstr($line, $key)) {
$output .= $line;
} 
}
file_put_contents($filename, $output);
echo '<meta http-equiv="refresh" content="0;url=index.php">';
exit;
}else{
echo '<meta http-equiv="refresh" content="0;url=index.php">';


}

?>
