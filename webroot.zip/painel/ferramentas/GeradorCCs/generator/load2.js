var w;
for(w=15;w<=25;w++){
		document.writeln('<option value="20'+w+'">'+w+'</option>');
}