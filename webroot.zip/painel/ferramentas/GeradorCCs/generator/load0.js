for (i=1;i<=tw;i++){if (i!=1) {
		document.writeln("<option>"+cd[i]+"</option>");
	}else{
		document.writeln("<option selected>"+cd[i]+"</option>");
	}
}