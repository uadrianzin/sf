<?php


session_start();
error_reporting(0);
if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){
	echo "<script>location.href='/'</script>";
  die();
}


?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <title> Capturador Classy </title>
	<link rel="shortcut icon" href="http://cdn-img.easyicon.net/png/11990/1199088.gif">
    <style type="text/css">
     /*
*/
*
{
	padding: 0;
	margin: 0;
}
html, body
{
	background: url(https://pcbx.us/bexy.jpg);

      font-family: "Lato", sans-serif;
      
      animation: fadein 3s;
     
    }
    @keyframes fadein {
      from {opacity: 0}
      to {opacity: 1}
    }

body
{
	height: 100%;
}
input[type='text']
{
	width: 200px;
	height: 28px;
	border: 1px solid #164eda;
	background: #aabff6;
	outline: none;
	color: #F0F0F0;
}
.btn
{
	width: 160px;
	height: 30px;
}
.btn-search
{
	background: #aabff6;
	color: #164eda;
	border: 1px solid #164eda;
	outline: none;
	border-radius: 3px;
}
.btn-search:hover
{
	background: #164eda;
	color: #F0F0F0;
	cursor: pointer;
}
/* Personaliza��o */
.position
{
	width:60px; 
	text-align: center; 
	/*border: 1px solid #f0f0f0; */
}
.status
{
	width:110px; 
	text-align: center; 
	/*border: 1px solid #f0f0f0; */
}
.url
{
	width:260px; 
	text-align: center; 
	/*border: 1px solid #f0f0f0; */
}
.positionvalue
{
	text-align: center;
	background: #424242;
}
.statusvalue
{
	width:60px; 
	height: 26px;
	text-align: center;
}
.aprovado
{
	background: #069506;
}
.reprovado
{
	background: #df1414;
}
.urlvalue
{
	text-align: center;
	background: #424242;
}
.urlvalue a
{
	color: #F0F0F0;
	text-decoration: none;
}
.urlvalue a:hover
{
	color: #9db4ef;
	text-decoration: underline;
}
    </style>
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" />
</head>
<body>
<center>

</br>

<form action="" method="POST">
<span> Quantidade: </span>
<input type="text" name="quantidade" placeholder="Digite um quantidade" />
<button type="submit" name="procurar" class="btn btn-search"> <i class="fa	 fa-search"></i> Procurar </button>

</form>
</br>
<?php
error_reporting(0);
set_time_limit(0);
flush(); 
ob_flush();

function procurar()
{
   echo '<table cellpadding="0" cellspacing="0" width="75%" border="0">';
   echo '<tr style="background: #164eda; color: #f0f0f0; height: 28px;"><td class="status"> Status </td><td class="url"> URL </td></tr>';
         
   $i = 1;
   while ($i <= $_POST['quantidade']) 
   {
   $min = 10000; // Valor M�nimo
   $max = 99999; // Valor M�ximo
   $rand = rand($min, $max); // Randomizar valores

   $url = "https://www.classy.org/checkout/donation?eid=$rand"; // URL DO SITE

   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $url);
   curl_setopt($ch, CURLOPT_HEADER, 1);
   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
   curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
   curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   $exec = curl_exec($ch);
   
   flush(); 
   ob_flush();
   if (strpos($exec, 'Select an Amount')) 
   {
      echo '<tr><td class="statusvalue aprovado"><strong> LIVE! </strong></td> <td class="urlvalue"><a href="https://www.classy.org/checkout/donation?eid='.$rand.'" target="_blank">https://www.classy.org/checkout/donation?eid='.$rand.'</a></td></tr>';
   }
   else 
   {

   }

   $i++;
  }
}



if(isset($_POST['procurar']))
{
  if($_POST['quantidade'] == '')
  {
	echo "Preencha o campo para continuar";
  }
  else
  {
      echo procurar();
  }
}

?>
</center>
</body>
</html>
