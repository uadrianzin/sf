<?php


session_start();
error_reporting(0);
if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){
	echo "<script>location.href='/'</script>";
  die();
}


?>





IMPOSIVEL AGORA