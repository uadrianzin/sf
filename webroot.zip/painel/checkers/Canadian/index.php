<?php 

error_reporting(0);

set_time_limit(0);

session_start();



if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){

echo '<script language= "JavaScript">location.href="/"</script><br>';

  die();

}



$array_usuarios = file("../../../../jeaotop.txt");

$total_usuarios_registrados = count($array_usuarios);



$continuar = false;

for($i=0;$i<count($array_usuarios);$i++){

  $explode = explode("|" , $array_usuarios[$i]);

  if($_SESSION['usuario'] == $explode[0]){



    $_SESSION['senha'] = $explode[1];

    $_SESSION['rank'] = $explode[2];

    $_SESSION['creditos'] = $explode[3];

    $_SESSION['foto'] = $explode[4];

    $continuar = true;

  }

}



if(!$continuar){

echo '<script language= "JavaScript">location.href="/"</script><br>';

die();

}



?>
<?php

error_reporting(0);
set_time_limit(0);
session_start();

$usuario = $_SESSION['usuario'];
$senha = $_SESSION['senha'];
$rank = $_SESSION['rank'];
$creditos = $_SESSION['creditos'];
$foto = $_SESSION['foto'];

if($rank  !== "VIP Lendário" and $rank !== "Administrador" and $rank !== "VIP Supremo" and $rank !== "VIP Demon" and $rank !== "VIP Divinity"){
  echo "<center><h3>Você não tem permissão para entrar nessa área.</h3></center>";
die();
}

$arquivo_usuarios = "../../jeaotop.txt";

?>
<!DOCTYPE html>
<html>
<head>
	<title>
        FlashReverso - Canadian CHK
    </title>
   
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="shortcut icon" href="../!BB_LULU_FASE_DE_TESTE.21/fav.ico" type="image/x-icon">
  <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">


<style type="text/css">
html
{
    outline: none;
    font-family: 'Quicksand', sans-serif;

}
::-webkit-scrollbar {
  width: 2px;
  height: 2px;
}
::-webkit-scrollbar-button {
  width: 0px;
  height: 0px;
}
::-webkit-scrollbar-thumb {
  background: #0181de;
  border: 0px none #ffffff;
  border-radius: 50px;
}
::-webkit-scrollbar-thumb:hover {
  background: #0e57d1;
}
::-webkit-scrollbar-thumb:active {
  background: #2676ee;
}
::-webkit-scrollbar-track {
  background: #3b3b3b;
  border: 0px none #ffffff;
  border-radius: 50px;
}
::-webkit-scrollbar-track:hover {
  background: #000000;
}
::-webkit-scrollbar-track:active {
  background: #1f1f1f;
}
::-webkit-scrollbar-corner {
  background: transparent;
}

body{

    background:
    background-size: 100% 100%;
    background-repeat: repeat;
    font-family: Quicksand, sans-serif;
                background-color: #232323;


 }
  textarea
            {
                background-color: #292929;
                color: #fff;
               
               box-shadow: 0 0 0 0;
    border: 0 none;
    outline: 0;
            }
             .listt:focus {outline:0;}
 .listt
 {
      background-color: #292929;
                color: #fff;
                border-radius: 10px;
                box-shadow: 0 0 0 0;
                border: 0 none;
                outline: 0;
                border: none;
                resize: none;
                overflow: none;
                box-shadow: 0 0 0 0;
    border: 0 none;
    outline: 0;
            }
            textarea:focus, input:focus, select:focus {
    outline: 0;
}
input, textarea, select {
    outline: 0;
}
       .change{
            background-color: #1264e8;
          border-radius: 5px;
            border: none;
            width: 800px;
            height: 40px;
            color: #ffffff;
            }
            .change:hover {
            cursor: pointer;
            background-color: #1153bf;
            color: #fff;
            }

            .change:active {
            outline: none;
            border: none;
            }
            .panel panel-default
            {
                background-color: #292929;
                width: 10%;
            }
            

input {
  
  vertical-align: middle;
  vertical-align: center;
  
  
}
#VCL
{
    margin-top: -1px;
    margin-left: 5px;
}
#VCD
{
    margin-top: -1px;
    margin-left: 5px;
}




</style>


</head>
<body>
	<CENTER>
         <font size="6" color="#2175ff">Canadian - FlashReverso</font><br>
        <center><textarea name="lista" required="required" id="lista" class="form-control" rows="8" placeholder="4505539480039281|05|2022|653" title="4505539480039281|05|2022|653" style="width: 600px;"></textarea></center>
            <br>
<input type="button" class="btn btn-primary" style="width: 600px;" id="startc" value="TESTAR" onclick="startParams()">
            
<br><br>
                        
						  <i id="demo"><font color="white"><span class="label label-info">STATUS: </span>&nbsp;</font></i>&nbsp;<font color="white"> <span class="label label-info">TOTAL: </span>&nbsp;</font><span class="label label-info"><i id="testado" style="color:#fff;"> 0 </i></span>&nbsp;<font color="white"> <span class="label label-info">  CARREGADAS : </span>&nbsp;</font> <span class="label label-info"><i id="carregada" style="color:#fff;"> 0 </i></span>&nbsp;<font color="white"> <span class="label label-success">  APROVADAS: </span>&nbsp;</font>  <span class="label label-success"><i id="CLIVE" style="color:#fff;"> 0 </i></span>&nbsp;<font color="white">  <span class="label label-danger">REPROVADAS: </span>&nbsp;</font> <span class="label label-danger">   <i id="CDIE" style="color:white;"> 0 </i></span><br>
<br>
            
       <font color="white">EM FILA : </font> <i id="nCheckTM" style="color:red;"> N/A </i><br>
         
       <br>

      <font color="white"><span class="label label-warning"> PROGRESSO: </span>&nbsp;</font> <i id="progress_total" style="color:#fff;"><span class="label label-warning"> N/A </span></i>  | <font color="lime"><span class="label label-success">VER APROVADAS<input onclick="cvcl()" id="VCL" style="background-color: #000; border: 0;" type="Checkbox"> </span></font>&nbsp;<font color="#FFF"><span class="label label-danger">VER REPROVADAS<input onclick="cvcd()" id="VCD" type="Checkbox"></span></font>
                        
            
        <div id="pgstr"></div>
            <br>
                
                
                <br>
          
          
                  
<div class="container">
                    <div class="panel panel-default" style="width: 55%; background-color: #292929; border: 0;">
    <div class="panel-body"></div>
<span style="color: lime;">APROVADAS</span>
                      <br><br>
                            <i id="nLive" style="display:none;"></i><div id="emLIVE" style="display:none;">
                                      <div id="ALLLIVE" onclick="SelectAll('ALLLIVE');"></div></div><br>
                                       </div>
</div>
               <div class="container">
                    <div class="panel panel-default" style="width: 55%; background-color: #292929; border: 0;"> 
                    <br>    
<span style="color: red;">REPROVADAS</span>
                       <br><br>
                            <i id="nDie" style="display:none;"></i><div id="emDIE" style="display:none;">
                                      <div id="ALLDIE" onclick="SelectAll('ALLDIE');"></div></div><br>
                                  </div>
                     
         
          
            
            <script type="text/javascript">
                var cdie = document.getElementById('VCD');
                var clive = document.getElementById('VCL');
                
                // Functions
                function SelectAll(id)
                {
                    document.getElementById(id).focus();
                    document.getElementById(id).select();
                }
                
                function cvcd(){
                    if(cdie.checked == false){
                        document.getElementById("emDIE").style.display = "none";
                        document.getElementById("nDie").style.display = "none";
                    } else if(cdie.checked == true){
                        document.getElementById("emDIE").style.display = "block";
                        document.getElementById("nDie").style.display = "block";
                    } 
                }
                function cvcl(){
                    if(clive.checked == false){
                        document.getElementById("emLIVE").style.display = "none";
                        document.getElementById("nLive").style.display = "none";
                    } else if(clive.checked == true){
                        document.getElementById("emLIVE").style.display = "block";
                        document.getElementById("nLive").style.display = "block";
                    } 
                }
                function startchk(url, chard, pchk){
                    
                    var xmlhttp;
                    if (window.XMLHttpRequest)
                    {
                        xmlhttp=new XMLHttpRequest();
                    }
                    else
                    {
                        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    xmlhttp.onreadystatechange=function()
                    {
                        if (xmlhttp.readyState==4 && xmlhttp.status==200)
                        {
                            var xdata = xmlhttp.responseText;
                            var totaltestado = document.getElementById("testado");
                            var naosei = totaltestado.innerHTML = (eval(totaltestado.innerHTML) + 1);
                            var naosesi = (eval(document.getElementById("testado").innerHTML) + 1);
                            var countlive = (eval(document.getElementById("CLIVE").innerHTML) + 1);
                            var countlixo = (eval(document.getElementById("CDIE").innerHTML) + 1);
                            var resultado = Math.floor((naosei / chard) * 100);
                            var boaporcento = Math.floor((countlive / chard) * 100);
                            var lixoporcento = Math.floor((countlixo / chard) * 100);
                            document.getElementById("nCheckTM").innerHTML = "<font color='white'>" +  url + "</font>";
                            document.getElementById("progress_total").innerHTML = "<font style='color: red;'>" + resultado + "%</font>";
                            document.title = "[Progresso: " + resultado + "%" + "]";
                            if (xdata.match(/LIVE →/g)) {    
                                document.getElementById("CLIVE").innerHTML = countlive;
                                document.getElementById("ALLLIVE").innerHTML = document.getElementById("ALLLIVE").innerHTML +  xdata + " \n";
                             //   document.getElementById("progressbarTOTAL").style.width = boaporcento + "%";
                           //     document.getElementById("progressbarTOTAL").innerHTML = boaporcento + "%";
                                notifyMe();
                                
                            } else if (xdata.match(/DIE →/g)) {
                                document.getElementById("CDIE").innerHTML = countlixo;
                                document.getElementById("ALLDIE").innerHTML = document.getElementById("ALLDIE").innerHTML + xdata + "\n";
                            //    document.getElementById("progressbarTOTAL").style.width = lixoporcento + "%";
                              //  document.getElementById("progressbarTOTAL").innerHTML = lixoporcento + "%";
                                
                            }
                        }
                    }
                    xmlhttp.open("GET","api.php?lista=" + url + "" ,true);
                    xmlhttp.send();
                }
                
                function listToArray(fullString, separator) {
                    var fullArray = [];
                    
                    if (fullString !== undefined) {
                        if (fullString.indexOf(separator) == -1) {
                            fullAray.push(fullString);
                        } else {
                            fullArray = fullString.split(separator);
                        }
                    }
                    
                    return fullArray;
                }
                function count(mixed_var, mode) {
                    var key, cnt = 0;
                    if (mixed_var === null || typeof mixed_var === 'undefined') {
                        return 0;
                    } else if (mixed_var.constructor !== Array && mixed_var.constructor !== Object) {
                        return 1;
                    }
                    if (mode === 'COUNT_RECURSIVE') {
                        mode = 1;
                    }
                    if (mode != 1) {
                        mode = 0;
                    }
                    for (key in mixed_var) {
                        if (mixed_var.hasOwnProperty(key)) {
                            cnt++;
                            if (mode == 1 && mixed_var[key] && (mixed_var[key].constructor === Array || mixed_var[key].constructor ===
                                                                Object)) {
                                cnt += this.count(mixed_var[key], 1);
                            }
                        }
                    }
                    return cnt;
                }
                function pushcsB(c,p) {
                    document.getElementById(p).innerHTML = document.getElementById(p).innerHTML + c + "\n<br>" ;
                }
                function startParams() {
                    document.getElementById("pgstr").style.display = "block";
                    var textarea = document.getElementById("lista").value;
                    // var textareacount = textarea.split("\n");
                    var textareacount = textarea.split('\n');
                    var textareaMatch = count(textareacount, 'COUNT_RECURSIVE');
                    //Check
                    var myString = textarea;
                    var myArray = listToArray(myString, '\n');
                   
                    document.getElementById("demo").innerHTML = '';
                    document.getElementById("carregada").innerHTML = textareaMatch;   
                    for(var i=0;i<textareaMatch;i++){
                        
                        var cclst = myArray[i];
                        var cemail = cclst.split("|");
                        var csids = 'csid_' + i;
                        var ccids = 'ccid_' + i;
                        
                        var output = document.getElementById("lista").value;
                        output = output.replace(cclst, "");
                        output = output.replace("\n", "");
                        document.getElementById("lista").innerHTML = output;
                        startchk(cclst, textareaMatch, i);
                        
                    }
                    document.getElementById("demo").innerHTML = '<span class="label label-info"><font color="white">STATUS : </font><span class="label label-info"></i></span><i style="color:#fff;"> INICIADO!   </i></span>';
                }
            </script>
        </center>
    
</body></html>