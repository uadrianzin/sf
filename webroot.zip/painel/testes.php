<?php



$random = substr(str_shuffle(str_repeat("0123456789", 16)), 0, 16);

echo $random;




?>