﻿<?php

error_reporting(0);
set_time_limit(0);
session_start();

if(!file_exists("usuarios.txt")){
  $fopen = fopen("usuarios.txt" , "a+");
  fclose($fopen);
}
if(isset($_SESSION['usuario']) and isset($_SESSION['senha'])){
  session_destroy();
  session_start();
}

?>

<!doctype html>
<html class="no-js" lang="en">



<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Cadastro - FLASH</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <!-- amchart css -->
    <link rel="stylesheet" href="../../../www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <!-- others css -->
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- modernizr css -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/jquery.mobile-1.3.2.min.js"></script>
<script src="js/jquery.mask.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/script.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js"></script>

<!-- mascara -->
<script type="text/javascript">
$(document).ready(function(){
		 $("input.key").mask("9999");
		 $("input.saldo").mask("999.99");
	   });
</script>

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- login area start -->
    <div class="login-area login-bg">
        <div class="container-fluid p-0">
            <div class="row no-gutters">
                <div class="col-xl-4 offset-xl-8 col-lg-6 offset-lg-6">
                    <div class="login-box-s2 ptb--100">
                        
                        
                        <form id="login-form" method="post">
                        <form>
                        
                        
                        
                            <div class="login-form-head">
                                <h4>CENTRAL FLASH</h4>
                                <p>Olá, gerar new cod </p>
                            </div>
                            <div class="login-form-body">
                                <div class="form-gp">
                                    <label for="exampleInputName1">Cod</label>
                                    <input type="text" id="exampleInputName1" name="nome">
                                    <i class="ti-user"></i>
                                   </div>
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                <div class="submit-btn-area">
                                    <button id="form_submit" type="submit">Gerar<i class="ti-arrow-right"></i></button>
                                    <div class="login-other row mt-4">
                                
                                
                                
                                
                                
                                
                           
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                        
                        
                        
                        
                        
                        
                        
                             
                             
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- login area end -->

    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>

    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="../../../external.html?link=https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
</body>



<?php
                             
                             
                             
                             
                             if(isset($_POST['usuario'])){
                             $usuario = trim(htmlspecialchars($_POST['usuario']));
                             $senha = trim(htmlspecialchars($_POST['senha']));
                             $nome = trim(htmlspecialchars($_POST['nome']));                             
                             $key = trim(htmlspecialchars($_POST['key']));     
                                                     date_default_timezone_set('America/Sao_Paulo');
                                                     $data_atual = date('Y-m-d H:i');
                             $senha2 = $_POST['senha1'];
                             
                             
                             
                             
                             
                             
                             $arquivo_saldo = file("saldo.txt");
                             foreach($arquivo_saldo as $saldo)
                             
                             
                             
                             $arquivo_rank = file("rank.txt");
                             foreach($arquivo_rank as $rank)
                          
                             
                             
                             
                             
                             $arquivo_data = file("expira.txt");
                             foreach($arquivo_data as $expira)
                            
                           
                             
                             
                             
                             $arquivo = file("keys.txt");
                             foreach($arquivo as $key_original)
                             if($key = $key_original){
                             echo 'key utilizada com sucesso!!!';
                             unlink("keys.txt");
                             }else{
                             echo 'key inválida!!!';
                             exit;
                             }
                             
                             
                             
                             
                             if($senha !== $senha2){
                             echo "<script>swal('erro' , 'Senha de confirmação incorreta' , 'error');</script>";
                             }else{
                             if(strpos($usuario , '|') !== false or strpos($senha , '|') !== false){
                             echo "<script>swal('erro' , 'Usuario ou Senha Contem um caracter não permitido' , 'error');</script>";
                             }else{
                             
                             
                             
                             
                             
                             $continuar = true;
                             for($i=0;$i<count($array); $i++)
                             {
                             $explode = explode("|" , $array[$i]);
                             if($explode[0] == $usuario){
                             $continuar = false;
                             }
                             }
                             
                             
                             
                             
                             if(!$continuar){
                             echo "<script>swal('erro' , 'Usuario Ja existe' , 'error');</script>";
                             }else{
                             $fp = fopen("usuarios.txt" , "a+");
                             $escreve =  fwrite($fp, ''.$usuario.'|'.$senha.'|'.$rank.'|'.$nome.'|'.$key.'|'.$saldo.'|'.$expira.'|' . PHP_EOL . '');
                             fclose($fp);
                             $pularlinha = PHP_EOL;
                             $lines = file( 'painel/tabela.php', FILE_IGNORE_NEW_LINES ); $target = 149; $lines[ $target - 1 ] = ''.$pularlinha.'<tr><th scope="row">'.$usuario.'</th><td>'.$senha.'</td><td>'.$rank.'</td><td>'.$nome.'</td><td>'.$key.'</td><td>'.$saldo.'</td><td>'.$data_atual.'</td></tr>'.$pularlinha.''; file_put_contents( 'painel/tabela.php', implode( PHP_EOL, $lines ) );
                             fclose($fp);
                             unlink("expira.txt");
                             unlink("rank.txt");
                             unlink("saldo.txt");
                             echo '<meta http-equiv="refresh" content="2;url=index.php">';
                             }
                             
                             }
                             
                             
                             
                             ////
                             
                             
                             }
                             }
                             
                             ?>





</html>